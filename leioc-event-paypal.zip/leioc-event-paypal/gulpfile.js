const {src, dest, task, watch, series, parallel} = require( 'gulp' );

const rename = require( 'gulp-rename' );
const sass = require( 'gulp-sass' );
const uglify = require( 'gulp-uglify' );
const notify = require( 'gulp-notify' );
const autoprefixer = require( 'gulp-autoprefixer' );
const sourcemaps = require( 'gulp-sourcemaps' );
const browserify = require( 'browserify' );
const babelify = require( 'babelify' );
const source = require( 'vinyl-source-stream' );
const buffer = require( 'vinyl-buffer' );
const browserSync = require( 'browser-sync' ).create();


const styleSRC = 'src/scss/plugin-style.scss';
const formSRC = 'src/scss/leioc-form-style.scss';
const tableSRC = 'src/scss/leioc-table-style.scss';
const styleDIST = './assets/css/';
const styleWatch = 'src/scss/**/*.scss';

const jsSRC = 'plugin.js';
const jsFormSRC = 'entry-form.js';
const jsTableSRC = 'entry-table.js';
const jsFolder = 'src/js/';
const jsDIST = './assets/js/';
const jsWatch = 'src/js/**/*.js';

const jsFiles = [jsSRC, jsFormSRC, jsTableSRC];

const htmlWatch = '**/*.html';
const phpWatch = '**/*.php';

function browser_Sync(){
    browserSync.init({
        open: false,
        injectChanges: true,
        proxy: 'http://www.newleioc.dev.cc/'
    });

};

function reload(done){
    browserSync.reload;

    done();
}

function css (done){
    src( [styleSRC, formSRC, tableSRC] )
        .pipe( sourcemaps.init() )
        .pipe( sass({
            errorLogToConsole: true,
            outputStyle: 'compressed'
        }) )
        .on( 'error', console.error.bind( console ) )
        .pipe( autoprefixer({
            cascade: false
        }) )
        .pipe( rename( { suffix: '.min' } ) )
        .pipe( sourcemaps.write( './' ) )
        .pipe( dest( styleDIST ) )
        .pipe( browserSync.stream() );

    done();
};

function js (done){
    jsFiles.map( function( entry ){
        return browserify({
            entries: [jsFolder + entry]
        })
        .transform( babelify, {presets: ['@babel/env']} )
        .bundle()
        .pipe( source( entry) )
        .pipe( rename({ extname: '.min.js' } ) )
        .pipe( buffer() )
        .pipe( sourcemaps.init({ loadMaps: true }))
        .pipe( uglify() )
        .pipe( sourcemaps.write( './' ) )
        .pipe( dest( jsDIST ) )
        .pipe( browserSync.stream() );
    });

    done();
};

function watch_files(){
    watch( styleWatch, series(css, reload) );
    watch( jsWatch, series(js, reload) );
    watch( htmlWatch, reload );
    watch( phpWatch, reload );
    src(jsDIST + 'plugin.min.js')
		.pipe( notify({ message: 'Gulp is Watching, Happy Coding!' }) );
};


task('css', css);
task('js', js);

task('default', parallel('css', 'js') );

task('watch', parallel(browser_Sync, watch_files ) );