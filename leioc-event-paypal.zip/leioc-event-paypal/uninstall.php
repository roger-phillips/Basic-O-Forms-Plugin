<?php

 /**
  *
  *This file unistalls the LEIOC Events plugin
  *
  *@package leioc-events-plugin 
  */

// Exit if accessed directly.
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

//Check leioc_paypal_delete_data is set before deleting data
$delete_option = get_option( 'leioc_paypal_delete_data');

if( isset($delete_option['delete']) ){

  $timestamp = isset($option['timestamp']) ? $option['timestamp'] : date('Y-m-d H:i:s' );
	$current = date('Y-m-d H:i:s', strtotime('-5 minutes'));

  if( intval( $delete_option['delete'] ) == 1 && strtotime( $current ) <= strtotime($timestamp) ){

    $option_name = 'leioc_paypal_ent_form';
    delete_option($option_name);
    // for site options in Multisite
    delete_site_option($option_name);

    $option_name = 'leioc_paypal_invoice_email';
    delete_option($option_name);
    // for site options in Multisite
    delete_site_option($option_name);

    //drops database tables
    global $wpdb;
    $tableArray = [
        $wpdb->prefix.'leioc_paypal_entries',
        $wpdb->prefix.'leioc_paypal_events',
    ];

    foreach($tableArray as $table){
      $wpdb->query("DROP TABLE IF EXISTS $table");
    }
    $option_name = 'leioc_paypal_event_db_version';
    delete_option($option_name);
    // for site options in Multisite
    delete_site_option($option_name);

    $option_name = 'leioc_paypal_delete_data';
    delete_option($option_name);
    // for site options in Multisite
    delete_site_option($option_name);
  };
 
};

