<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Pages;

use \LEIOCPaypal\Api\SettingsApi;
use \LEIOCPaypal\Base\BaseController;
use \LEIOCPaypal\Api\Callbacks\AdminCallbacks;
use \LEIOCPaypal\Api\Callbacks\SettingsCallbacks;

/**
* 
*/
class SettingsController extends BaseController
{
    public $settings;

	public $callbacks;

	public $settings_callbacks;

	public $subpages = array();

	public function register()
	{

		$this->settings = new SettingsApi();

		$this->callbacks = new AdminCallbacks();

		$this->settings_callbacks = new SettingsCallbacks();

		$this->setSettings();

		$this->setSections();

		$this->setFields();

		$this->setSubpages();

		$this->settings->addSubPages( $this->subpages )->register();
    }

    public function setSubpages()
	{
		$this->subpages = array(
			array(
				'parent_slug' => 'leioc_admin_dashboard', 
				'page_title' => 'Orienteering Settings', 
				'menu_title' => 'Settings', 
				'capability' => 'manage_options', 
				'menu_slug' => 'leioc_entry_form_settings', 
				'callback' => array( $this->callbacks, 'adminSettings' )
			)
		);
	}

	public function setSettings()
	{
		$args = array(
			array(
				'option_group' => 'leioc_plugin_about_settings',
				'option_name' => 'leioc_paypal_delete_data',
				'callback' => array( $this->settings_callbacks, 'formSanitize' )
			)
		);

		$this->settings->setSettings( $args );
	}

	public function setSections()
	{
		$args = array(
			array(
				'id' => 'leioc_settings_index',
				'title' => 'Settings Manager',
				'callback' => array( $this->settings_callbacks, 'formSectionManger' ),
				'page' => 'leioc_settings'
			)
		);

		$this->settings->setSections( $args );
	}

	public function setFields()
	{	
		$this->reset_option();

		$args = array(
			array(
				'id' => 'delete',
				'title' => 'Delete data on plugin delete',
				'callback' => array( $this->settings_callbacks, 'deleteformcheckboxField' ),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'delete',
					'class' => 'leioc-ui-toggle',
					'option_name' => 'leioc_paypal_delete_data',
					'note'          => esc_attr__( 'Selection remains active for 5 minutes.' ),
				)
			),
			array(
				'id' => 'phone',
				'title' => 'Competitor phone number',
				'callback' => array( $this->settings_callbacks, 'formcheckboxField' ),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'phone',
					'class' => 'leioc-ui-toggle',
					'option_name' => 'leioc_paypal_delete_data',
					'note'          => esc_attr__( 'Select if you wish to collect a contact phone number.' ),
				)
			),
			array(
				'id' => 'phone_note',
				'title' => 'Phone information note',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'phone_note',
					'placeholder' => 'e.g. Please enter a mobile phone number if possible',
					'option_name' => 'leioc_paypal_delete_data',
					'note'          => esc_attr__( 'Add information note for entry phone number.' ),
				)
			),
			array(
				'id' => 'terms',
				'title' => 'Select Terms and Conditions',
				'callback' => array( $this->settings_callbacks, 'formcheckboxField' ),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'terms',
					'class' => 'leioc-ui-toggle',
					'option_name' => 'leioc_paypal_delete_data',
					'note'          => esc_attr__( 'Add terms and conditions checkbox.' ),
				)
			),
			array(
				'id' => 'terms_text',
				'title' => 'Terms and conditions text',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'terms_text',
					'placeholder' => 'e.g. I agree to the terms and conditions of entry',
					'option_name' => 'leioc_paypal_delete_data',
					'note'          => esc_attr__( 'Add terms and conditions text.' ),
				)
			),
			array(
				'id' => 'terms_note',
				'title' => 'Terms and conditions note',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'terms_note',
					'placeholder' => 'e.g. Terms and conditions.',
					'option_name' => 'leioc_paypal_delete_data',
					'note'          => esc_attr__( 'Add note for terms and conditions URL link.' ),
				)
			),
			array(
				'id' => 'terms_url',
				'title' => 'Terms and conditions media URL',
				'callback' => array( $this->settings_callbacks, 'textField' ),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'terms_url',
					'placeholder' => 'e.g. http://www.leioc.org.uk',
					'option_name' => 'leioc_paypal_delete_data',
					'type' => 'url',
					'note'          => esc_attr__( 'Add url for terms and conditions media.' ),
				)
			),
			array(
				'id' => 'leioc_media_uploader',
				'title' => '',
				'callback' => array($this->settings_callbacks, 'formbutton'),
				'page' => 'leioc_settings',
				'section' => 'leioc_settings_index',
				'args' => array(
					'label_for' => 'leioc_media_uploader',
					'text'		=> 'Upload Media',
					'class'		=> '',
				)
			),
		);

		$this->settings->setFields( $args );
	}

	public function reset_option()
	{
		//Resets delete data option to false after 5 minutes if Settings page is opened
		$option = get_option( 'leioc_paypal_delete_data' );
		$delete = isset($option['delete']) ? $option['delete'] : '';
		$timestamp = isset($option['timestamp']) ? $option['timestamp'] : date('Y-m-d H:i:s' );
		$current = date('Y-m-d H:i:s', strtotime($this->max_delete_time));

		if( $delete == 1 && strtotime( $current ) > strtotime($timestamp) ){
			$option = get_option( 'leioc_paypal_delete_data' );
			$option =  isset($option) ? $option : [];

			$option['delete'] = 0;
			$option['timestamp'] = date('Y-m-d H:i:s');

			update_option( 'leioc_paypal_delete_data',  $option );
		}

		return;
	}
}