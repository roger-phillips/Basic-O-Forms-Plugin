<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Pages;

use \LEIOCPaypal\Api\SettingsApi;
use \LEIOCPaypal\Base\BaseController;
use \LEIOCPaypal\Api\Callbacks\AdminCallbacks;
use \LEIOCPaypal\Api\Callbacks\EntriesCallbacks;

/**
* 
*/
class EntriesController extends BaseController
{
    public $settings;

	public $callbacks;

	public $ent_callbacks;

	public $subpages = array();

	public function register()
	{

		$this->settings = new SettingsApi();

		$this->callbacks = new AdminCallbacks();

		$this->ent_callbacks = new EntriesCallbacks();

		$this->setSettings();

		$this->setSections();

		$this->setFields();

		$this->setSubpages();

		$this->settings->addSubPages( $this->subpages )->register();
		
    }
    
    public function setSubpages()
	{
		$this->subpages = array(
			array(
				'parent_slug' => 'leioc_admin_dashboard', 
				'page_title' => 'Entries Dashboard', 
				'menu_title' => 'Entries', 
				'capability' => 'read', 
				'menu_slug' => 'leioc_entries', 
				'callback' => array( $this->callbacks, 'adminEntries' )
			)
		);
	}

	public function setSettings()
	{
		$args = array(
			array(
				'option_group' => 'leioc_plugin_entries_settings',
				'option_name' => 'leioc_plugin_entries',
				'callback' => array( $this->ent_callbacks, 'entSanitize' )
			)
		);

		$this->settings->setSettings( $args );
	}


	public function setSections()
	{
		$args = array(
			array(
				'id' => 'leioc_entries_index',
				'title' => 'Entires Manager',
				'callback' => array( $this->ent_callbacks, 'entSectionManager' ),
				'page' => 'leioc_entries'
			)
		);

		$this->settings->setSections( $args );
	}

	public function setFields()
	{
		$IDS = $this->get_event_ids();
		
		$args = array(
			array(
				'id' => 'entries_event_id',
				'title' => 'Select Event',
				'callback' => array( $this->ent_callbacks, 'optionSelect' ),
				'page' => 'leioc_entries',
				'section' => 'leioc_entries_index',
				'args' => array(
					'label_for' => 'entries_event_id',
					'event_ids' => $IDS,
				)
			),
		);

		$this->settings->setFields( $args );
	}

	public function get_event_ids()
	{
		global $wpdb;

		$link = isset( $_REQUEST['id']) ? sprintf('form_id = %d', $_REQUEST['id']):'form_date >= now()';
        $sql =  "SELECT id, form_title, form_date, form_id FROM {$this->eventTable} WHERE form_trash=1 AND {$link} ORDER BY form_date DESC";
		return $wpdb->get_results( $sql , ARRAY_A );
	}
	
}