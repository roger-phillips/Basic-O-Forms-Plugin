<?php
/**
* @package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Pages;

use \LEIOCPaypal\Api\SettingsApi;
use \LEIOCPaypal\Base\BaseController;
use \LEIOCPaypal\Api\Callbacks\AdminCallbacks;
use \LEIOCPaypal\Api\Callbacks\MangerCallbacks;

class Dashboard extends BaseController
{
    public $settings;

    public $callbacks;

    public $callbacks_mngr;

    public $pages = array();

	public function register()
	{
        $this->settings = new SettingsApi();

        $this->callbacks = new AdminCallbacks();

        $this->callbacks_mngr = new MangerCallbacks();

        $this->setPages();

        $this->setSettings();

        $this->setSections();

        $this->setFields();

        $this->settings->addPages( $this->pages )->withSubPage( 'Events' )->register();
    }

    public function leioc_dashboard_form_submit()
	{
		if (! DOING_AJAX || ! check_ajax_referer('leioc-dashboard-form-nonce', 'nonce') ) {
			return $this->return_json('error');
        }

        global $wpdb;
		$table_name = $this->eventTable;
		$now = date("Y-m-d H:i:s");

		//Sanitize data
		$id = sanitize_text_field( trim($_POST['event_id']) );

        $formID = sanitize_text_field( trim($_POST['event_form_id']) );
		$title = sanitize_text_field( trim($_POST['event_form_title']) );
		$date = sanitize_text_field( trim($_POST['event_form_date']) );
		$open = sanitize_text_field( trim($_POST['event_form_open'] != NULL ? $_POST['event_form_open']: $now ) );
		$close = sanitize_text_field( trim(($_POST['event_form_close'] != NULL ? $_POST['event_form_close'] : $_POST['event_form_date'])) );
		$max = sanitize_text_field( trim($_POST['event_form_max']) );
		$publish = isset($_POST['event_form_publish']) ? true : false;

		$courses = sanitize_text_field( trim( $this->clean_str($_POST['event_form_courses']) ) );
		$starts = sanitize_text_field( trim( $this->clean_str($_POST['event_form_starts']) ) );
		$show = isset($_POST['event_form_starts_show']) ? true : false;

		//Saves only allowed HTML tags
		$info = wp_kses( trim($_POST['event_form_info']), $this->allowed_html );

		$subject = wp_kses( trim($_POST['event_form_subject']), $this->allowed_html );
		$message = wp_kses( trim($_POST['event_form_message']), $this->allowed_html );
		$from = sanitize_text_field( isset($_POST['event_form_from']) ? $_POST['event_form_from'] : 'Orienteering Club' );
		$default = explode( 'www.', site_url() );
		$reply = sanitize_text_field( (isset($_POST['event_form_reply']) ? $_POST['event_form_reply'] : 'reply@' . $default[1]) );
		$attach = sanitize_text_field( isset($_POST['event_form_attach']) ? $_POST['event_form_attach'] : '' );

		//Event Fee Info
		$fee_publish = isset($_POST['event_form_fee_publish']) ? true : false;
		$fee_details = sanitize_text_field( trim( isset($_POST['event_form_fee_details']) ? $this->clean_str($_POST['event_form_fee_details']) : '' ) );

		$deleted = sanitize_text_field( isset($_POST['event_form_trash']) ? ($_POST['event_form_trash'] != '' ? $_POST['event_form_trash'] : 1): 1 );

		//Check if form_id exists and if id is blank
		if( $id == NULL){
			$sql = $wpdb->prepare("SELECT form_id FROM {$table_name} WHERE form_id = %d", $formID );
			$check = $wpdb->get_col( $sql );
			if(count($check) >= 1){
				$msg = 'Event ID already exists, please choose another Event ID.';
				return $this->return_json('error', $msg);
			}
		}
		
		$details = maybe_serialize(
			array(
				'form_courses' => $courses,
				'form_starts' => $starts,
				'form_starts_show' => $show,
				'form_info' => $info,
			)
		);

		$email = maybe_serialize( 
			array(
				'form_subject' => $subject,
				'form_message' => $message,
				'form_from' => $from,
				'form_reply' => $reply,
				'form_attach' => $attach,
			)
		);

        $args = array(
            'form_id' => $formID,
            'form_title' => $title,
            'form_open' => $open,
            'form_date' => $date,
            'form_close' => $close,
            'form_max' => $max,
			'form_details' => $details,
			'form_publish' => $publish,
			'form_email' => $email,
			'form_fee_details' => $fee_details,
			'form_fee_publish' => $fee_publish,
			'form_trash' => $deleted,
        );

		$sql = $wpdb->prepare( "SELECT id FROM $table_name WHERE id = %d", $id);
		$check = $wpdb->get_col( $sql );
        
		if(count($check) >= 1){
			$update = $wpdb->update($table_name, $args, array( 'id' => $id ));
			return $this->return_json('success', $title .' updated in the database.');
		} else {
			$form = $wpdb->insert($table_name, $args);
			if ($form) {
				return $this->return_json( 'success', $title .' added to the database.');
			}
		}

		return $this->return_json('error');
    }

    public function return_json($status, $data = null)
	{
		$return = array(
            'status' => $status,
			'data' => $data,
		);
		wp_send_json($return);

		wp_die();
	}

	public function clean_str( $str )
	{
		return str_replace('\\','', preg_replace('/,+/', ',', preg_replace('/;/', ',', $str) ) );
	}

	public function setPages()
	{
        $img = file_get_contents($this->plugin_url.'assets/images/icon-dash.svg');
	
        $this->pages = array(
            array(
                'page_title' => 'LEIOC Payments Plugin' , 
                'menu_title' => 'Basic O Forms' ,
                'capability' => 'read' , 
                'menu_slug'  => 'leioc_admin_dashboard', 
                'callback'   =>  array( $this->callbacks, 'adminDashboard'),
                'icon_url'   => 'data:image/svg+xml;base64,' . base64_encode($img), 
                'position'   =>  110,
            )
        );
    }

    public function setSettings()
	{
		$args = array(
			array(
				'option_group' => 'leioc_paypal_ent_form_settings',
				'option_name' => 'leioc_paypal_ent_form',
				'callback' => array($this->callbacks_mngr, 'formSanitize'),
			)
		);

		$this->settings->setSettings( $args );
	}

	public function setSections()
	{
		$args = array(
			array(
				'id' => 'leioc_paypal_form_index',
				'title' => 'Entry Form Settings Manager',
				'callback' => array($this->callbacks_mngr, 'formSectionManger'),
				'page' => 'leioc_paypal_form_settings'
            ),
            array(
				'id' => 'leioc_paypal_default_index',
				'title' => 'Default Form Settings Manager',
				'callback' => array($this->callbacks_mngr, 'defaultSectionManger'),
				'page' => 'leioc_paypal_default_form_settings'
            ),
		);

		$this->settings->setSections( $args );
	}

	public function setFields()
	{
		$args = array(
            array(
				'id' => 'event_id',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_id',
					'placeholder' => '',
					'class' => 'leioc-hidden',
                    'array' => 'settings',
                    'type' => 'hidden',
				)
			),
            array(
				'id' => 'event_form_trash',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_trash',
					'placeholder' => '',
					'class' => 'leioc-hidden',
                    'array' => 'settings',
                    'type' => 'hidden',
				)
			),
            array(
				'id' => 'event_form_id',
				'title' => 'Unique Event ID',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_id',
					'placeholder' => 'eg. 1234',
                    'array' => 'settings',
					'type' => 'number',
					'err'  => esc_attr__('An Unique Event Id is required'),
				)
			),
			array(
				'id' => 'event_form_title',
				'title' => 'Event Title',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_title',
					'placeholder' => 'eg. Entry Form',
					'array' => 'settings',
					'err'  => esc_attr__('An Event Title is required'),
				)
			),
			array(
				'id' => 'event_form_date',
				'title' => 'Event Date',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_date',
					'placeholder' => 'eg. Event Date',
                    'array' => 'settings',
					'type' => 'date',
					'err'  => esc_attr__('An Event date is required'),
				)
            ),
            array(
				'id' => 'event_form_open',
				'title' => 'Entries Open',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_open',
					'placeholder' => 'eg. Open Date',
                    'array' => 'settings',
					'type' => 'datetime-local',
					'err'  => esc_attr__('An Event Open date is required'),
				)
			),
			array(
				'id' => 'event_form_close',
				'title' => 'Entries Close',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_close',
					'placeholder' => 'eg. Closure Date',
                    'array' => 'settings',
					'type' => 'datetime-local',
					'err'  => esc_attr__('An Event Close date is required'),
				)
			),
			array(
				'id' => 'event_form_max',
				'title' => 'Max Number of Entries',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_max',
					'placeholder' => 'eg. 60',
                    'array' => 'settings',
					'type' => 'number',
					'note' => esc_attr__('Use 0 if no maximum number required.'),
					'err'  => esc_attr__('A number is required'),
				)
			),
			array(
				'id' => 'event_form_courses',
				'title' => 'Courses Available',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_courses',
					'placeholder' => 'eg. Long, Medium, Short',
                    'array' => 'settings',
					'type' => 'text',
					'note' => esc_attr__('Separate courses with a comma.'),
					'err'  => esc_attr__('Courses are required'),
				)
			),
			array(
				'id' => 'event_form_starts_show',
				'title' => 'Show Start Times',
				'callback' => array($this->callbacks_mngr, 'formcheckboxField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_starts_show',
					'class' => 'leioc-ui-toggle',
					'array' => 'settings',
				)
			),
			array(
				'id' => 'event_form_starts',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_starts',
					'placeholder' => 'eg. 10:30, 10:32, 10:34',
					'array' => 'settings',
					'class' => 'leioc-hidden',
					'type' => 'hidden',
					'err'  => esc_attr__('Start Times are required'),
				)
			),
			array(
				'id' => 'event_form_start_builder',
				'title' => 'Available Start Times',
				'callback' => array($this->callbacks_mngr, 'formbutton'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_start_builder',
					'text'		=> 'Open Start Builder',
					'class'		=> 'leioc-modal-open',
					'url'		=> 'leioc-start-times-builder',
					'err'  => esc_attr__('Start Times are required'),
				)
			),
			array(
				'id' => 'event_form_publish',
				'title' => 'Publish',
				'callback' => array($this->callbacks_mngr, 'formcheckboxField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_publish',
					'class' => 'leioc-ui-toggle',
                    'array' => 'settings',
				)
			),
			array(
				'id' => 'event_form_info',
				'title' => 'Event Information',
				'callback' => array($this->callbacks_mngr, 'form_textArea'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_info',
					'placeholder' => 'Information to appear on entry form.',
					'array' => 'settings',
					'note' => esc_attr__('Event information will appear as a header on the entry form.'),
                    'type' => 'text',
				)
			),
			array(
				'id' => 'event_form_subject',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_subject',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_message',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_message',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_from',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_from',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_reply',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_reply',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_attach',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_attach',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_email_builder',
				'title' => 'Email Settings',
				'callback' => array($this->callbacks_mngr, 'formbutton'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_email_builder',
					'text'		=> 'Open Email Settings',
					'class'		=> 'leioc-modal-open',
					'url'		=> 'leioc-email-builder',
					'err'  		=> esc_attr__('Check Email Settings'),
				)
			),
			array(
				'id' => 'event_form_fee_publish',
				'title' => 'Use Fee',
				'callback' => array($this->callbacks_mngr, 'formcheckboxField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_fee_publish',
					'class' => 'leioc-ui-toggle',
                    'array' => 'settings',
				)
			),
			array(
				'id' => 'event_form_fee',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_fee',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_fee_si',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_fee_si',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_fee_details',
				'title' => '',
				'callback' => array($this->callbacks_mngr, 'formtextField'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_fee_details',
					'class' => 'leioc-hidden',
					'placeholder' => '',
					'array' => 'settings',
					'type' => 'hidden',
				)
			),
			array(
				'id' => 'event_form_fee_builder',
				'title' => 'Fee Settings',
				'callback' => array($this->callbacks_mngr, 'formbutton'),
				'page' => 'leioc_paypal_form_settings',
				'section' => 'leioc_paypal_form_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'event_form_fee_builder',
					'text'		=> 'Open Fee Settings',
					'class'		=> 'leioc-modal-open',
					'url'		=> 'leioc-paypal-fee-builder',
					'err'  		=> esc_attr__('Check Fee Settings'),
				)
			),
			array(
				'id' => 'default_event_form_title',
				'title' => 'Default Form Title',
				'callback' => array($this->callbacks_mngr, 'textField'),
				'page' => 'leioc_paypal_default_form_settings',
				'section' => 'leioc_paypal_default_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'default_event_form_title',
					'placeholder' => 'eg. Entry Form',
                    'array' => 'settings',
                    'type' => 'text',
				)
			),
			array(
				'id' => 'default_event_form_max',
				'title' => 'Default Max Number',
				'callback' => array($this->callbacks_mngr, 'textField'),
				'page' => 'leioc_paypal_default_form_settings',
				'section' => 'leioc_paypal_default_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'default_event_form_max',
					'placeholder' => 'eg. 60',
                    'array' => 'settings',
                    'type' => 'number',
					'note' => esc_attr__('Use 0 if no maximum number required.'),
				)
			),
			array(
				'id' => 'default_event_form_courses',
				'title' => 'Default Courses',
				'callback' => array($this->callbacks_mngr, 'textField'),
				'page' => 'leioc_paypal_default_form_settings',
				'section' => 'leioc_paypal_default_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'default_event_form_courses',
					'placeholder' => 'eg. Long, Medium, Short',
                    'array' => 'settings',
                    'type' => 'text',
					'note' => esc_attr__('Separate courses with a comma.'),
				)
			),
			array(
				'id' => 'default_event_form_reply',
				'title' => 'Default Email Reply Address',
				'callback' => array($this->callbacks_mngr, 'textField'),
				'page' => 'leioc_paypal_default_form_settings',
				'section' => 'leioc_paypal_default_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'default_event_form_reply',
					'placeholder' => 'e.g. reply@site.co.uk',
					'array' => 'settings',
					'type' => 'email',
				)
			),
			array(
				'id' => 'default_event_form_from',
				'title' => 'Default Email From Setting',
				'callback' => array($this->callbacks_mngr, 'textField'),
				'page' => 'leioc_paypal_default_form_settings',
				'section' => 'leioc_paypal_default_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'default_event_form_from',
					'placeholder' => 'e.g. Joe Bloggs',
					'array' => 'settings',
					'type' => 'text',
				)
			),
			array(
				'id' => 'default_event_form_fee',
				'title' => 'Default Event Fees',
				'callback' => array($this->callbacks_mngr, 'textField'),
				'page' => 'leioc_paypal_default_form_settings',
				'section' => 'leioc_paypal_default_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'default_event_form_fee',
					'placeholder' => 'Senior: £5.00, Junior: £1.00',
					'array' => 'settings',
					'note' => esc_attr__('Add a fee type and price, seperated by colon(:). Use a comma when starting a new fee type. e.g. Senior: 5.00, Junior: 3.50'),
					'type' => 'text',
				)
			),
			array(
				'id' => 'default_event_form_fee_si',
				'title' => 'Default SI Dibber Hire Fee',
				'callback' => array($this->callbacks_mngr, 'textField'),
				'page' => 'leioc_paypal_default_form_settings',
				'section' => 'leioc_paypal_default_index',
				'args' => array(
					'option_name' => 'leioc_paypal_ent_form',
					'label_for' => 'default_event_form_fee_si',
					'placeholder' => '£1.00',
					'array' => 'settings',
					'type' => 'text',
				)
			),
		);

		$this->settings->setFields( $args );
	}
}
