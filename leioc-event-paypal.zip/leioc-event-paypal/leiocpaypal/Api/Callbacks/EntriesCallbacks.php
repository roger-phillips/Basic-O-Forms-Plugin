<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Api\Callbacks;

/**
* 
*/
class EntriesCallbacks
{
    public function entSantize(){
        return;
    }

    public function entSectionManager()
	{
		echo 'Choose the event you wish to manage.';
    }

    public function optionSelect( $args ){

        $IDS = $args['event_ids'];

        $form_id= isset( $_REQUEST['id']) ?  $_REQUEST['id'] : '';

        $options = '';

        foreach($IDS as $key => $value){
            $date = date( "d/m/Y", strtotime($value['form_date']) );
            $name = $value['form_title'];
            $selected = $form_id == $value['form_id'] ? 'selected' : '';
            $options .= '<option value="' . $value['id']. '" data-name="' . str_replace(" ", "_", ($name . ' '.$date) ) . '" ' . $selected . '>' . $date . ' - ' . $name . '</option>';
        }
        
        if(count($IDS) == 0){
            $options = '<option>No Events Listed</option>';
		}

        echo '<select id="' . $args['label_for'] . '" name="' . $args['label_for'] . '">' . $options . '</select>';
    }
}