<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Api\Callbacks;

/**
* 
*/
class EntriesCallbacks
{
    public function entSantize(){
        return;
    }

    public function entSectionManager()
	{
		echo 'Choose the event you wish to manage.';
    }

    public function optionSelect( $args ){

        $IDS = $args['event_ids'];

        $options = '';

        foreach($IDS as $key => $value){
            $date = date( "d/m/Y", strtotime($value['form_date']) );
            $name = $value['form_title'];
            $options .= '<option value="' . $value['id']. '" data-name="' . str_replace(" ", "_", ($name . ' '.$date) ) . '">' . $name . ' - ' . $date . '</option>';
        }
        
        if(count($IDS) == 0){
            $options = '<option>No Events Listed</option>';
		}

        echo '<select id="' . $args['label_for'] . '" name="' . $args['label_for'] . '">' . $options . '</select>';
    }
}