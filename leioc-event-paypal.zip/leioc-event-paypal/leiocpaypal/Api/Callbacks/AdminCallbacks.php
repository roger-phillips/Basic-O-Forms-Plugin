<?php
/**
* @package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Api\Callbacks;

use \LEIOCPaypal\Base\BaseController;


class AdminCallbacks extends BaseController
{
    public function adminDashboard(){
        return require_once( "$this->plugin_path/templates/admin-page.php" );
    }

    public function adminEntries()
	{
		return require_once( "$this->plugin_path/templates/entries-page.php" );
	}

    public function adminAbout()
	{
		return require_once( "$this->plugin_path/templates/settings-page.php" );
	}
}