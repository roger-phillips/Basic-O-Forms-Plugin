<?php
/**
* @package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Api\Callbacks;

use \LEIOCPaypal\Base\BaseController;


class SettingsCallbacks extends BaseController
{

	public function formSanitize( $input )
	{
		$date = array('timestamp'=> date('Y-m-d H:i:s') );
      	$output = get_option('leioc_paypal_delete_data');

		$input['phone'] = isset($input['phone']) ? $input['phone'] : 0;

      	$output = sanitize_option($output, array_merge($input, $date) );
		
		return $output;
	}

	public function formSectionManger()
	{
    	echo 'Settings for Basic Orienteering Plugin.';
  	}

	public function deleteformcheckboxField( $args )
	{
		$name = $args['label_for'];
		$classes = $args['class'];
		$option_name = $args['option_name'];
		$option = get_option( $option_name);


		$delete = intval( isset($option['delete']) ? $option['delete'] : 0 );
		$timestamp = isset($option['timestamp']) ? $option['timestamp'] : date('Y-m-d H:i:s', strtotime('-30 minutes') );
		$current = date('Y-m-d H:i:s', strtotime($this->max_delete_time) );

		//Resets delete option to 0 after 5 minutes - this does not alter the database
		if(strtotime( $current ) > strtotime($timestamp) && $delete != 0 ){
			$delete = 0;
		};

		$note = isset($args['note']) ? '<span class="leioc-note">' . esc_html($args['note']) . '</span>' :'';
		$checked = isset($option[$name]) ? ( $delete == 1 ? true : false ): false;

		echo '<div class="' . $classes . '"><input type="checkbox" id="' . $name . '" name="' . $option_name . '['. $name . ']" value="1" class="" ' . ( $checked ? 'checked' : '') . '><label for="' . $name . '"><div></div></label></div>' . $note;
	}

	public function formcheckboxField( $args )
	{
		$name = $args['label_for'];
		$classes = $args['class'];
		$option_name = $args['option_name'];
		$option = get_option( $option_name);

		$note = isset($args['note']) ? '<span class="leioc-note">' . esc_html($args['note']) . '</span>' :'';
		$checked = isset($option[$name]) ? ( intval($option[$name]) == 1 ? true : false ) : false;

		echo '<div class="' . $classes . '"><input type="checkbox" id="' . $name . '" name="' . $option_name . '['. $name . ']" value="1" class="" ' . ( $checked ? 'checked' : '') . '><label for="' . $name . '"><div></div></label></div>' . $note;
	}

	public function textField( $args )
	{
		$name = $args['label_for'];
      	$option_name = $args['option_name'];
      
      	$input = get_option( $option_name );
		$value =  isset($input[$name]) ? $input[$name] : '';
      
      	$type = isset($args['type']) ? $args['type']: 'text';
		$note = isset($args['note']) ? '<p class="leioc-note">' . esc_html($args['note']) . '</p>' : '';

		echo '<input type="'. $type .'" class="regular-text" id="' . $name . '" name="' . $option_name . '[' . $name . ']" value="' . $value . '" placeholder="' . $args['placeholder'] . '">' . $note;
	}
}