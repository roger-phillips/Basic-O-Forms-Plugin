<?php
/**
* @package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Api\Callbacks;

use \LEIOCPaypal\Base\BaseController;


class MangerCallbacks extends BaseController
{

	public function formSanitize( $input )
	{
      	$output = get_option('leioc_paypal_ent_form');
 
      	$output['settings'] = sanitize_option($output, $input);
		
		return $output;
	}

	public function defaultSectionManger()
	{
    	echo 'Default settings for entry forms.<br><div class="leioc-note" style="padding-left:0"> These settings can be overidden when creating an entry form.</div>';
	}

	public function formSectionManger()
	{
    	echo 'Settings for entry form.';
  	}

	public function formtextField( $args )
	{
		$name = $args['label_for'];
      	$option_name = $args['option_name'];
	  
		if( isset($_POST["edit_post"][0]) ) 
		{
			$search = 'event_' . $name;
			$data = $this->get_event_data( trim($_POST["edit_post"][0]));
			$value = isset($data[$search ]) ? esc_attr($data[$search ]) : '';
		} else {
			$input = get_option( $option_name );
			$value = isset($input[$args['array']]['default_'.$name]) ? esc_attr($input[$args['array']]['default_'.$name]) : '' ;
		}
      
		$type = isset($args['type']) ? $args['type']: 'text';
		  
		$err =  isset($args['err']) ? '<span class="field-msg error" data-error="invalid">' . esc_html($args['err']) . '</span>' : '';

		$msg = isset($args['note']) ? '<p class="leioc-note">' . esc_html($args['note']) . '</p>' : '';

		echo '<input type="'. $type .'" class="regular-text" id="' . $name . '" name="' . $name . '" value="' . $value . '" placeholder="' . $args['placeholder'] . '">' . $msg . $err;
	}

	public function formcheckboxField( $args )
	{
		$name = $args['label_for'];
		$classes = $args['class'];
		$option_name = $args['option_name'];
		$checked = false;

		if ( isset($_POST["edit_post"][0]) ) 
		{
			$search = 'event_' . $name;
			$data = $this->get_event_data( trim($_POST["edit_post"][0]) );
			$checked = isset($data[$search]) ? ( $data[$search] == 1 ? true : false ): false;
		}

		echo '<div class="' . $classes . '"><input type="checkbox" id="' . $name . '" name="' . $name . '" value="1" class="" ' . ( $checked ? 'checked' : '') . '><label for="' . $name . '"><div></div></label></div>';
	}

	public function formbutton( $args )
	{
		$name = $args['label_for'];
		$text = $args['text'];
		$class = $args['class'];
		$url = $args['url'];

		$err =  isset($args['err']) ? '<span class="field-msg error" data-error="invalid">' . esc_html($args['err']) . '</span>' : '';

		echo '<button type="button" class="' . $class . ' button button-secondary" id="' . $name . '" data-url="' . $url . '">' . $text . '</button>' . $err;
	}

	public function form_textArea( $args )
	{
		$id = $args['label_for'];

		$msg = isset($args['note']) ? '<p class="leioc-note">' . esc_html($args['note']) . '</p>' : '';

		echo '<textarea class="regular-text" style="min-height: 5rem;" id="' . $id . '" name="' . $id . '"></textarea>' . $msg;
	}

	public function get_event_data($id)
	{
		global $wpdb;
		$data = $wpdb->get_row("SELECT * FROM {$this->eventTable} WHERE id='{$id}'", ARRAY_A);

		$data['form_date'] = date('Y-m-d',strtotime($data['form_date']));
		$data['form_open'] = date('Y-m-d\TH:i',strtotime($data['form_open']));
		$data['form_close'] = date('Y-m-d\TH:i',strtotime($data['form_close']));

		$form_details = maybe_unserialize( $data['form_details'] );

		$settings = array_merge($data, $form_details);

		return $settings;
	}
   
	//Defualt Settings Field
	public function textField( $args )
	{
		$name = $args['label_for'];
      	$option_name = $args['option_name'];
      
      	$input = get_option( $option_name );
		$value = isset($input[$args['array']][$name]) ? esc_attr__($input[$args['array']][$name]) : '' ;
      
      	$type = isset($args['type']) ? $args['type']: 'text';

		$msg = isset($args['note']) ? '<p class="leioc-note">' . esc_html__($args['note']) . '</p>' : '';

		echo '<input type="'. $type .'" class="regular-text" id="' . $name . '" name="' . $option_name . '[' . $name . ']" value="' . $value . '" placeholder="' . $args['placeholder'] . '">' . $msg;
	}
}