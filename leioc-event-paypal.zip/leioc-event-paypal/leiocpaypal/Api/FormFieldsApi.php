<?php
/**
* @package leioc-event-paypal
* Builds Basic O Forms user forms
*/

namespace LEIOCPaypal\Api;

class FormFieldsApi
{
    /**
     * field params
     * 
     *  array(//Rows
     *           '* field name *' => array(
     *                              'type' => 'text', ** Set as select for option group
     *                              'label' => 'BOF Number',
     *                              'pattern' => '(^[0-9]*$|IND)',
     *                              'required' => 'yes',
     *                              'note' => 'Enter IND, if you do not have a BOF number.',
     *                              'error' => 'A BOF number is required',
     *                              'args' => array(
     *                                          'hide' => Null, **hides field if not Null
     *                               ),
     *              ),
     *  ), 
     * 
     */
    private $id_tag = 'leioc-o-form-';

    private $age_class = array(10, 12, 14, 16, 18, 20, 21, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90);

    public function formfields( $args )
    {

        $form = $this->nav();

        foreach($args as $k => $rows){
            $row = '';
            foreach($rows as $key => $field){

                if( isset($field['args']['hide']) ) continue;
                $label = $this->label( array( 
                    'name' => $key,
                    'label' => $field['label'],
                    'required' => isset($field['required']) ? $field['required'] : '',
                    )
                );
                $inputfield = strtolower($field['type']) == 'select' ? $this->select( $field, $key):$this->input( $field, $key );
                if( isset($field['note']) ) $inputfield .= $this->note($field['note']);
                if( isset($field['error']) ) $inputfield .= $this->error($field['error']);
                $input = sprintf('%s<div>%s</div>', $label, $inputfield);
                $row .= $this->group( $input );
            };

            $active = $k == 0 ? 'active' : '';
            $form .= sprintf('<section class="leioc-o-form-slide %s" id="form-%s"><div class="leioc-form-row">%s</div></section>', $active, $k, $row);
        };

        return sprintf('<form class="leioc-entry-form">%s</form>', $form);
    }

    private function nav()
    {
        return sprintf('<nav><button type="button" id="prev">Back</button><button type="button" id="leioc-next">Next</button></nav>');
    }

    private function group( $arg )
    {
        return sprintf('<div class="leioc-form-group">%s</div>', $arg);
    }

    private function label( $args )
    {
        $required = isset($args['required']) ? 'class="required"': '';
        return sprintf('<label for="%s" %s>%s</label>', esc_attr($this->id_tag . $args['name']), $required, esc_attr($args['label']) );
    }

    private function input( $args, $name, $disabled = null)
    {
        $type = isset($args['type']) ? $args['type'] : 'text';
        $placeholder = isset($args['placeholder']) ? 'placeholder="' . esc_attr($args['placeholder']) . '"' : '';
        $pattern = isset($args['pattern']) ? 'pattern="'. $args['pattern'] . '"' : '';
        $required = isset($args['required']) ? 'required' : '';

        return sprintf('<input type="%s" id="%s" name="%s" %s aria-label="%s" aria-describedby="%s" %s %s %s>', esc_attr($type), esc_attr($this->id_tag . $name), esc_attr($name), $placeholder, esc_attr($name), esc_attr($name), $pattern, $required, $disabled);
    }

    private function select( $args, $name, $disabled = null)
    {
        $options = '<option value=""> -- Select an Option -- </option>';
        $list = isset($args['options']) ? $args['options'] : [];
        foreach($list as $key => $option){
           $options .= sprintf('<option value="%s">%s</option>', $key, $option);
        };
        return sprintf('<select id="%s" name="%s">%s</select>', esc_attr($this->id_tag . $name), esc_attr($name), $options);
    }

    private function note( $arg )
    {
        return sprintf('<div class="leioc-form-text">%s</div>', esc_attr($arg) );
    }

    private function error( $arg )
    {
        return sprintf('<span class="field-msg error">%s</span>', esc_attr($arg) );
    }
}