<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use LEIOCPaypal\Pages\Dashboard;
use LEIOCPaypal\Base\FormController;
use LEIOCPaypal\Base\EventWPListTable;
use LEIOCPaypal\Base\EntriesWPListTable;

/**
* 
*/
class AjaxController
{

    public function register()
	{
        //AJAX for user entry form
        add_action( 'wp_ajax_leioc_entry_form_submit', array( $this, 'leioc_entry_form_submit' ) );
        add_action( 'wp_ajax_nopriv_leioc_entry_form_submit', array( $this, 'leioc_entry_form_submit' ) );

        //Adds Event Dashboard Form Ajax
        add_action( 'wp_ajax_leioc_dashboard_form_submit', array( $this, 'leioc_dashboard_form_submit' ) );
        
        //Adds Dashboard Admin Entry Form AJAX
        add_action( 'wp_ajax_leioc_admin_entry_submit', array( $this, 'admin_entry_form_submit' ) );

        //Admin Events WP_List
        add_action('wp_ajax_admin_event_wp_list', array( $this, 'admin_events_wp_list') );

        //Admin Entries WP_List
        add_action('wp_ajax_admin_entries_wp_list', array( $this, 'admin_entries_wp_list') );
   
    }

    //Adds User Entry Form
    public function leioc_entry_form_submit(){
        $form = new FormController;
        $form->set_global();

        return $form->leioc_entry_form_submit();
    }

    public function leioc_dashboard_form_submit(){
        $form = new Dashboard;

        return $form->leioc_dashboard_form_submit();
    }

    //Adds Admin Entry Form
    public function admin_entry_form_submit(){
        $form = new FormController;

        return $form->leioc_admin_entry_submit();
    }

    //Entries WP_List_Table AJAX response
	public function admin_events_wp_list() {
		$wp_list_table = new EventWPListTable;
		
		return $wp_list_table->ajax_response();
	}

    //Entries WP_List_Table AJAX response
	public function admin_entries_wp_list() {
		$wp_list_table = new EntriesWPListTable;
		
		return $wp_list_table->ajax_response();
	}

}