<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use LEIOCPaypal\Pages\Dashboard;
use LEIOCPaypal\Base\FormController;
use LEIOCPaypal\Base\EventWPListTable;
use LEIOCPaypal\Base\EntriesWPListTable;
use LEIOCPaypal\Base\PaymentsWPListTable;
use LEIOCPaypal\Base\InvoicesWPListTable;

/**
* 
*/
class AjaxController
{

    public function register()
	{
        //AJAX for user entry form
        add_action( 'wp_ajax_leioc_entry_form_submit', array( $this, 'leioc_entry_form_submit' ) );
        add_action( 'wp_ajax_nopriv_leioc_entry_form_submit', array( $this, 'leioc_entry_form_submit' ) );

        //Adds Event Dashboard Form Ajax
        add_action( 'wp_ajax_leioc_dashboard_form_submit', array( $this, 'leioc_dashboard_form_submit' ) );
        
        //Adds Dashboard Admin Entry Form AJAX
        add_action( 'wp_ajax_leioc_admin_entry_submit', array( $this, 'admin_entry_form_submit' ) );

        //Admin Events WP_List
        add_action('wp_ajax_admin_event_wp_list', array( $this, 'admin_events_wp_list') );

        //Admin Entries WP_List
        add_action('wp_ajax_admin_entries_wp_list', array( $this, 'admin_entries_wp_list') );
   
        //Admin Payment Entries WP_List
        add_action('wp_ajax_leioc_admin_payments_events_wp_list', array( $this, 'admin_payments_events_wp_list') );
   
        //Admin Payment Invoices WP_List
        add_action('wp_ajax_leioc_admin_payments_invoices_events_wp_list', array( $this, 'admin_payments_invoices_events_wp_list') );

        //Admin Payment Email Invoices Settings
        add_action('wp_ajax_leioc_email_invoices_settings', array( $this, 'leioc_email_invoices_settings') );

        //Admin Payment Email Mail Merge
        add_action('wp_ajax_leioc_invoices_mail_merge', array( $this, 'leioc_invoices_mail_merge') );
    }

    //Adds User Entry Form
    public function leioc_entry_form_submit(){
        $form = new FormController;
        $form->set_global();
        return $form->leioc_entry_form_submit();
    }

    public function leioc_dashboard_form_submit(){
        $form = new Dashboard;
        return $form->leioc_dashboard_form_submit();
    }

    //Adds Admin Entry Form
    public function admin_entry_form_submit(){
        $form = new FormController;
        return $form->leioc_admin_entry_submit();
    }

    //Entries WP_List_Table AJAX response
	public function admin_events_wp_list() {
		$wp_list_table = new EventWPListTable;
		return $wp_list_table->ajax_response();
	}

    //Entries WP_List_Table AJAX response
	public function admin_entries_wp_list() {
		$wp_list_table = new EntriesWPListTable;
		return $wp_list_table->ajax_response();
	}

    //Payment Entries WP_List_Table AJAX response
	public function admin_payments_events_wp_list() {
		$wp_list_table = new PaymentsWPListTable;
		return $wp_list_table->ajax_response();
	}

    //Payment Invoices WP_List_Table AJAX response
	public function admin_payments_invoices_events_wp_list() {
		$wp_list_table = new InvoicesWPListTable;
		return $wp_list_table->ajax_response();
	}

    //Payment Email Invoices Settings AJAX response
	public function leioc_email_invoices_settings() {
		$wp_list_table = new PaymentsWPListTable;
		return $wp_list_table->ajax_response();
	}

    //Payment Invoices Email Mail merge AJAX response
	public function leioc_invoices_mail_merge() {
		$wp_list_table = new InvoicesWPListTable;
		return $wp_list_table->ajax_response();
	}

}