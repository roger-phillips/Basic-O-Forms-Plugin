<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

class BaseController
{
    public $plugin_path;

    public $plugin_url;

    public $plugin;

    public $managers = array();

    public $eventTable;

    public $entriesTable;

    public $allowed_html;

    public $max_delete_time = '-5 minutes';

    public $templates = [];

    public function __construct()
    {
        global $wpdb;

        $this->plugin_path = plugin_dir_path( dirname( __FILE__ , 2) );
        $this->plugin_url = plugin_dir_url( dirname( __FILE__ , 2) );
        $this->plugin = plugin_basename( dirname( __FILE__ , 3) ) . '/leioc-event-paypal.php';
        

        $this->eventTable = $wpdb->prefix . 'leioc_paypal_events';
        $this->entriesTable = $wpdb->prefix . 'leioc_paypal_entries';

        $this->allowed_html = array(
                                'a'     => array(
                                            'href' => [],
                                        ),
                                'b'     => [],
                                'i'     => [],
                                'br'     => [],
                                'strong' => [],
                                'p' => [],
                            );

        $this->set_templates();
    }

    private function set_templates()
    {
        $basicForm = array('basic-event' => array(
                        array(//Rows
                            'name' => array(
                                'type' => 'text',
                                'label' => 'Name',
                                'required' => 'yes',
                                'error' => 'Your Name is Required',
                            ),
                            'age' => array(
                                'type' => 'select',
                                'label' => 'Age Class',
                                'required' => 'yes',
                                'error' => 'Please select an Age Class',
                            ),
                        ), 
                        array(//Rows
                            'bof' => array(
                                'type' => 'text',
                                'label' => 'BOF Number',
                                'pattern' => '(^[0-9]*$|IND)',
                                'required' => 'yes',
                                'note' => 'Enter IND, if you do not have a BOF number.',
                                'error' => 'A BOF number is required',
                            ),
                            'club' => array(
                                'type' => 'text',
                                'label' => 'Club',
                                'required' => 'yes',
                                'note' => 'Enter IND, if you do not have a club.',
                                'error' => 'A club is required',
                            ),
                        ), 
                        array(//Rows
                            'si' => array(
                                'type' => 'text',
                                'label' => 'Si Number',
                                'pattern' => '(^[0-9]*$|HIRE)',
                                'required' => 'yes',
                                'note' => 'Enter HIRE, if you wish to hire a dibber.',
                                'error' => 'A Si Dibber number is required',
                            ),
                            'course' => array(
                                'type' => 'select',
                                'label' => 'Course',
                                'options' => array('Long'=>'Long'),
                                'required' => 'yes',
                                'error' => 'Please select a course',
                            ),
                            'start' => array(
                                'type' => 'select',
                                'label' => 'Start Time',
                                'required' => 'yes',
                                'error' => 'Please select a Start Time',
                                'args' => array(
                                        'hide' => Null,
                                ),
                            ),
                        ),
                        array(//Rows
                            'fee' => array(
                                'type' => 'select',
                                'label' => 'Fee',
                                'required' => 'yes',
                                'error' => 'Please select an fee category',
                                'args' => array(
                                    'hide' => Null,
                                ),
                            ),
                            'si-hire' => array(
                                'type' => 'select',
                                'label' => 'Si Hire Fee',
                                'required' => 'yes',
                                'error' => 'Please select an Si Hire charge',
                                'args' => array(
                                    'hide' => Null,
                                ),
                            ),
                        ), 
                    ),
                );

        $this->templates = $basicForm;
    }

}