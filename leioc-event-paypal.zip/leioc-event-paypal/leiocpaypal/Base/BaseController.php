<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

class BaseController
{
    public $plugin_path;

    public $plugin_url;

    public $plugin;

    public $managers = array();

    public $eventTable;

    public $entriesTable;

    public $allowed_html;

    public $max_delete_time = '-5 minutes';

    public function __construct()
    {
        global $wpdb;

        $this->plugin_path = plugin_dir_path( dirname( __FILE__ , 2) );
        $this->plugin_url = plugin_dir_url( dirname( __FILE__ , 2) );
        $this->plugin = plugin_basename( dirname( __FILE__ , 3) ) . '/leioc-event-paypal.php';
        

        $this->eventTable = $wpdb->prefix . 'leioc_paypal_events';
        $this->entriesTable = $wpdb->prefix . 'leioc_paypal_entries';

        $this->allowed_html = array(
                                'a'     => array(
                                            'href' => [],
                                        ),
                                'b'     => [],
                                'i'     => [],
                                'br'     => [],
                                'strong' => [],
                                'p' => [],
                            );
    }

}