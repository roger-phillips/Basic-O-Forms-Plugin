<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use \LEIOCPaypal\Base\BaseController;

/**
* Controller for the entries form and Admin entries form
*/
class FormController extends BaseController
{
    public $settings;

	public $callbacks;

	public $tableCols = array(
		'name' => 'Name',
		'club' => 'Club',
		'age_class' => 'Age Class',
		'si_num' => 'Si Number',
		'start_time' => 'Start Time',
	);

	private $wpdb;

	public $now;

	public $event_id;

	public $use_phone = 1;

	public function register()
	{
		$this->set_global();

		add_shortcode( 'leioc-entry-form', array( $this, 'entry_form' ) );
		add_shortcode( 'leioc-entry-table', array( $this, 'entry_table' ) );

		add_filter( 'do_shortcode_tag',  array($this, 'shortcode_wpautop_fix' ), 10, 2 );
    }

	//Removes unwanted <p> tags
	public function shortcode_wpautop_fix( $output, $tag){
		if ('leioc-entry-form' !== $tag && 'leioc-entry-table' !== $tag ) {
			return $output;
		}
		$output = preg_replace(
			"#<p>(\s|&nbsp;|</?\s?br\s?/?>)*</?p>#",
				"",
			$output
		);
		return $output;
	}
	
	public function set_global()
	{
		global $wpdb;
		$this->wpdb = $wpdb;

		$this->now = strtotime(date("Y-m-d H:i:s"));
	}

    public function entry_form($attr)
	{
		ob_start();

		$args = shortcode_atts( array(
			'id' => '',
			'title' => '',
        ), $attr );

		$this->event_id = $this->get_id_from_formID( $args['id'] );

		$event = $this->get_publish($this->event_id);
		//Checks if event is published
		if($event == false){
			return ob_get_clean();
		}

		$event['form_title'] = esc_html( trim($args['title'] != '' ? $args['title'] : $event['form_title']) );

		//Checks if event is open or closed
		$closed = $this->get_open($event);
		$closed = $closed != '' ? $closed : $this->get_closed($event);
		//Checks if maximum number of entries reached
		$closed = $closed != '' ? $closed : $this->get_event_numbers($event);

		$title = $event['form_title'];
		$date = $this->event_date( $event['form_date'] );

		$form_details = $event['form_details'];

		$info = isset($form_details['form_info']) ? $this->get_info($form_details['form_info']) : '';
		//Get Courses and Age Classes
		$course = $this->get_courses( $form_details['form_courses'] );
		$ageClass = $this->get_ageClass();

		$start_array = $this->decode_starts( $form_details['form_starts'] );
		$show = ( isset($form_details['form_starts_show']) ? ( $start_array['type'] == 0 ? false : $form_details['form_starts_show'] ) : true );

		if($show == true){
			$starts = $this->get_starts( $start_array );
			if( $this->get_starts( $start_array, true, true ) <=0 ) $disabled = true;
		}

		$phone_note = esc_html( $this->get_phone_note() );
		$use_phone = esc_html( $this->use_phone );
		$eventID = esc_html( $this->event_id );

		//Set Event Fees & Si
		if( $event['form_fee_publish'] == 1 ){
			$fees = $this->get_fees( $event['form_fee_details'] );
		}
		
		echo '<link rel="stylesheet" href="'.$this->plugin_url.'assets/css/leioc-form-style.min.css" type="text/css" media="all" />';
		echo '<form class="leioc-entry-form" action="#" method="post" data-url="' . admin_url('admin-ajax.php') . '">';
		require_once( $this->plugin_path.'templates/entry-form.php' );
		echo '</form>';
		echo '<script src="'.$this->plugin_url.'assets/js/entry-form.min.js"></script>';

		return ob_get_clean();
	}

	public function entry_table($attr)
	{
		ob_start();

		$args = shortcode_atts( array(
			'id' => '',
			'title' => '',
			), $attr );
		
		$this->event_id = $this->get_id_from_formID( $args['id'] );
		
		$event = $this->get_publish($this->event_id);
		//Checks if event is published
		if($event == false){
			return ob_get_clean();
		}

		$event['form_title'] = esc_html( trim($args['title'] != '' ? $args['title'] : $event['form_title']) );

		$title = $event['form_title'];
		$date = $this->event_date( $event['form_date'] );
		$link = 'Enter ' . $title;

		//Checks if event is open or closed
		$closed = $this->get_open($event);
		$closed = $closed != '' ? $closed : $this->get_closed($event);
		//Checks if maximum number of entries reached
		$closed = $closed != '' ? $closed : $this->get_event_numbers($event);

		//Sets info for entry form
		$form_details = $event['form_details'];

		$info = isset($form_details['form_info']) ? $this->get_info($form_details['form_info']) : '';
		$course = $this->get_courses( $form_details['form_courses'] );
		$ageClass = $this->get_ageClass();

		$start_array = $this->decode_starts( $form_details['form_starts'] );
		$show = ( isset($form_details['form_starts_show']) ? ( $start_array['type'] == 0 ? false : $form_details['form_starts_show'] ) : true );

		if($show == true){
			$starts = $this->get_starts( $start_array );
			if( $this->get_starts( $start_array, true, true ) <=0 ) $disabled = true;
		}

		//Removes start times if not set
		$this->set_headers( $form_details['form_starts_show'] );

		$tableRows = $this->get_rows();
		$headers = $this->get_headers();
		$modal = true;
		$count = $this->get_event_numbers( $event, false );

		$phone_note = esc_html( $this->get_phone_note() );
		$use_phone = esc_html( $this->use_phone );
		$eventID = esc_html($this->event_id);

		//Set Event Fees & Si
		if( $event['form_fee_publish'] == 1 ){
			$fees = $this->get_fees( $event['form_fee_details'] );
		}

		echo '<link rel="stylesheet" href="'.$this->plugin_url.'assets/css/leioc-table-style.min.css" type="text/css" media="all" />';
		require_once($this->plugin_path.'templates/entry-table.php');
		echo '<script src="'.$this->plugin_url.'assets/js/entry-table.min.js"></script>';
		return ob_get_clean();
	}

	public function get_admin_form($eventID = NULL)
	{
		ob_start();
		
		$this->set_global();

		if( isset( $_REQUEST['id']) && !isset($eventID) ) $eventID = $this->get_id_from_formID( $_REQUEST['id'] );

		if($eventID == null)
            //Check if form_id exists
            $eventID = $this->wpdb->get_var( "SELECT id FROM {$this->eventTable} WHERE form_trash=1 AND form_date >= now() ORDER BY form_date DESC" );
		
		$event = $this->get_publish( esc_html($eventID) , 0);
		//Checks if event is published
		if($event == false)
			return  wp_kses('<p><b>This event is not published</b> - Use event dashboard to publish events.</p>', $this->allowed_html );

		$form_details = $event['form_details'];
		$course = $this->get_courses( $form_details['form_courses'] );
		$ageClass = $this->get_ageClass();

		$phone_note = esc_html( $this->get_phone_note() );
		$use_phone = esc_html( $this->use_phone );
		$title = esc_html( $event['form_title'] );
		$date = $this->event_date( $event['form_date'] );

		//Set Event Fees & Si
		if( $event['form_fee_publish'] == 1 ){
			$fees = $this->get_fees( $event['form_fee_details'] );
		}

		$admin = true;

		require_once($this->plugin_path.'templates/entry-form.php');

		return ob_get_clean();
	}

	public function event_date( $date )
	{
		return date( 'l jS F Y' ,strtotime( esc_html($date) ) );
	}

	public function get_info( $str )
	{
		return nl2br( wp_kses( $str, $this->allowed_html ) );
	}

	public function decode_starts( $args )
	{	
		return json_decode( str_replace('\\','',stripslashes( $args ) ), true );
	}

	public function str_to_arr( $str )
	{
		return explode(',', esc_html( preg_replace('/,+/', ',', preg_replace('/;/', ',', $str) ) ) );
	}

	public function remove_spaces( $str )
	{
		return str_replace(' ', '', $str );
	}

	public function get_starts( $start_array, $show = true, $count = false)
	{
		$id = $this->event_id;
		$times = $start_array['times'];
		$type = $start_array['type'];

		if($times == NULL || $type == 0 || $show == false ) return;
		
		$sql = $this->wpdb->prepare( "SELECT ent_start FROM {$this->entriesTable} WHERE event_id = %d AND ent_trash=1", $id);
		$check = $this->wpdb->get_col( $sql );

		$starts = $this->str_to_arr($times);

		$options = '<option>-- Select a Start --</option>';

		$start_slots = count($starts);

		foreach($starts as $start){

			$disabled = '';
			$time = trim( str_replace('.',':',$start ) );

			if($type == 1 ) {
				if( in_array($time.':00', $check) ){
					$disabled = 'disabled';
					$start_slots -= 1;
				};
			}

			$options .= sprintf('<option value="%s" %s>%s</option>', $time, $disabled, $time);
		}

		if( $count == true ) return $start_slots;

		return $options;
	}

	public function get_courses($courseList)
	{
		if($courseList == NULL) return;

		$courses = $this->str_to_arr($courseList);

		$options = '<option>-- Select a Course --</option>';
		foreach($courses as $course){
			$options .= sprintf('<option>%s</option>', esc_attr( trim($course) ) );
		}

		return $options;
	}

	public function get_ageClass()
	{
		$args = array(10, 12, 14, 16, 18, 20, 21, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 85, 90
		);

		$men = '';
		$women = '';
		foreach($args as $value){
			$men .= '<option>M' . $value . '</option>';
			$women .= '<option>W' . $value . '</option>';
		}

		return '<option>-- Select an Age Class --</option>' . $men . $women;
	}
	public function get_fees( $fee_details )
	{
		$fee_details = $this->decode_fees( $fee_details );

		if( !isset($fee_details['type']) ) return;

		$type =  $fee_details['type'];
		if( $type == 0 || empty($type) ) return;

		$fees = $fee_details['fee'];
		$options = '<option>-- Select a Fee Category --</option>';
		foreach($fees as $key => $value){
			$fee = esc_attr( $value );
			$name = esc_attr( $key ) ;
			$options .= sprintf('<option value="%s">%s</option>', $name, $name . ' - £' . $fee);
		}

		$si =  esc_attr( $fee_details['si'] );
		$optionssi = '<option>-- Select a Hire Charge --</option>';
		$optionssi .= sprintf('<option value="Yes">Si Dibber Hire - £%s</option>', $si );
		$optionssi .= '<option value="No">No Dibber Required</option>';

		$fee_details['fee'] = ( !empty($fee_details['fee']) ? $options : '' );
		$fee_details['si'] = ( !empty($fee_details['si']) ? $optionssi : '' );

		return $fee_details;
	}

	public function fee_value( $fee_details, $fee = '', $si = '' )
	{
		$fee_details = $this->decode_fees( $fee_details, true );
		$fee = esc_attr( $this->remove_spaces( $fee ) );

		if( !isset($fee_details['type']) ) return;

		$type =  $fee_details['type'];
		if( $type == 0 || empty($type) ) return;

		if( $fee != '' ){
			$fee = md5( $fee );
			$fee = isset($fee_details['fee'][$fee]) ? $fee_details['fee'][$fee] : '';
		}
		$si = (strtolower($si) === 'yes' ? (isset($fee_details['si']) ? $fee_details['si'] : '' )  : '' );

		$arr = array(
			'total' => $fee + $si,
			'fee' => $fee,
			'si' => $si,
		);
		
		return $arr;
	}

	public function decode_fees( $str, $md5 = null )
	{
		$arr = $this->decode_starts( $str );
		$fees = !empty($arr['fee']) ? $this->str_to_arr($arr['fee']) : [];

		$options = [];
		foreach($fees as $fee){
			$arr2 = explode(':', trim($fee) );
			if( !isset($arr2[1]) ) continue;

			$key = esc_attr( $arr2[0] );
			$value = esc_attr( $this->get_float( trim($arr2[1]) ) );

			if( $md5 == true ) $key = md5($this->remove_spaces($key) );
			$options[$key] = $value;
		}

		$arr['si'] = isset($arr['si']) ? $arr['si'] : '';
		$arr['fee'] = $options;
		$arr['si'] =  esc_attr(  $this->get_float( trim($arr['si']) ) );

		return $arr;
	}

	public function get_float($str)
	{
		preg_match("/([0-9\.,-]+)/", trim($str), $match);

        return isset($match[0]) ? $match[0] : '';
	}

	public function get_id_from_formID( $id )
	{
		return $this->wpdb->get_var( $this->wpdb->prepare( "SELECT id FROM {$this->eventTable} WHERE form_id=%d", $id) );
	}

	public function get_publish($id, $pub = 1)
	{
		$wpdb = $this->wpdb;
		$pub = ( $pub == 1 ? 'AND form_publish = 1 AND form_trash=1' : '' );

		//Check if form_id exists
        $sql = $wpdb->prepare( "SELECT * FROM {$this->eventTable} WHERE id = %d $pub ", $id );
        $event = $wpdb->get_results( $sql , ARRAY_A );
        if(count($event) == 0){
            return false;
		}

		//Converts to single array
		$array = reset($event);
		$array['form_details'] = maybe_unserialize( $array['form_details'] );

		return $array;
	}

	public function get_open($array)
	{
		if( strtotime($array['form_open']) >= $this->now ){
			return $array['form_title'] . ' is due to open for entries on ' . esc_html( date( 'l jS M Y @ g:ia', strtotime($array['form_open']) ) );
		}
		return;
	}

	public function get_closed($array)
	{
		$now = $this->now;
		if( strtotime($array['form_close']) <= $now || strtotime($array['form_date'] . ' +1 day' ) <= $now ){
			return $array['form_title'] . ' is now closed for entries';
		}

		return;
	}

	public function get_event_numbers($array, $max = true)
	{
		$form_max = trim($array['form_max']);
		//Checks if no limit to entries
		if($form_max == 0 && $max == true) return;

		$wpdb = $this->wpdb;
		$sql = $wpdb->prepare("SELECT COUNT(*) FROM {$this->entriesTable} WHERE event_id = %d AND ent_trash=1" , $array['id']);
		$num = $wpdb->get_var($sql);
		//Returns event numbers
		if( $max == false ) return $num;

		if($num >= $form_max) return 'Sorry, the maximum number of entries for ' . esc_html( $array['form_title'] ) . ' has been reached.';

		return;
	}

	public function get_phone_note()
	{
		$option = get_option( 'leioc_paypal_delete_data' );
		$this->use_phone = intval( isset($option['phone']) ? $option['phone'] : 1 );

		$phone_note = 'Please enter a mobile phone number if possible.';
		$phone_note = isset($option['phone_note']) ? ($option['phone_note'] != '' ? $option['phone_note'] : $phone_note) : $phone_note;

		return $phone_note;
	}

	public function set_headers( $show )
	{
		if(array_key_exists('start_time',$this->tableCols) && $show == false ) {
			$array = $this->tableCols;
			unset( $array['start_time'] );
			$this->tableCols = $array;
		}
		return;
	}

	public function get_headers()
	{
		$head = '<tr>';
		foreach($this->tableCols as $header){
			$head .= '<th>' . esc_html( $header ). '</th>';
		}
		return $head .= '</tr>';
	}

	public function get_rows()
	{
		//Fields to Display on Form Table
		$titles = $this->tableCols;
		$id = $this->event_id;

		$wpdb = $this->wpdb;
		$entries = $this->entriesTable;
		//Entries
		$sql = $wpdb->prepare( "SELECT ent_details FROM $entries WHERE event_id = %d AND ent_trash=1 ORDER BY ent_course", $id );
		$rows = $wpdb->get_results($sql , ARRAY_A);

		//Course Count
		$sql = $wpdb->prepare( "SELECT ent_course, COUNT(*) AS num FROM $entries WHERE event_id = %d AND ent_trash=1 GROUP BY ent_course ", $id);
		$counts = $wpdb->get_results($sql , ARRAY_A);

		$row = '<tbody>';
		foreach($rows as $key => $entry){
			$rows[$key] = maybe_unserialize( reset($entry) );

			$colspan =  count($titles) > 1 ? 'colspan="' . count($titles) . '"' : '';
			$row .= '<tr>';

			$course = esc_html( $rows[$key]['course'] );
			$num_key = array_search( $course, array_column($counts, 'ent_course') );
			$num = $counts[$num_key]['num'];

			$course_title = '<td class="leioc-course"' . $colspan . '>' . $course . ' ('. $num . ')' . '</td></tr><tr>';

			if($key == 0){
				$row.= $course_title;
			} else {
				$row.= ($course != $rows[$key-1]['course'] ? '</tbody><tbody>' . $course_title : '');
			}

			foreach($titles as $col => $value){
				$cell =  esc_html( $rows[$key][$col] );
				if($col == 'start_time') $cell = $this->convert_starts( $cell );

				array_key_exists($col, $rows[$key]) ? $row .= '<td>' . $cell . '</td>' : $row .='<td></td>';
			}

			$row .= '</tr>';
		}
		
		return '</tbody>' . $row;
	}

	public function convert_starts( $str )
	{
		$expr = '/(?<=\s|^)[a-z]/i';
		preg_match_all($expr, $str, $matches);
		$result = strtolower( implode('', $matches[0]) );
		if( $result == '') return $str;

		$result = 'tba(' . $result .')';

		return $result;
	}

	public function csv_bulk_entries()
	{
		$tmp = $_FILES['csv_file']['tmp_name'];

		if( !isset($tmp) ) return $this->return_json('error');

		$file = fopen($tmp, 'r');
		// Headers
		$headers = fgetcsv($file);

		//Changes headers to match entry form fields
		foreach($headers as $key => $value){		
			if( $value === 'si_num') $headers[$key] = 'si';
			if( $value === 'age_class') $headers[$key] = 'age';
			if( $value === 'bof_num') $headers[$key] = 'bof';
			if( $value === 'fee_total') $headers[$key] = 'total';
		}

		// Rows
		$data = [];
		while (($row = fgetcsv($file)) !== false)
		{
			$item = [];
			foreach ($row as $key => $value)
					$item[$headers[$key]] = $value ?: null;
			$item['admin_entry'] = true;
			$data[] = $item;
		}
		// Close file
		fclose($file);

		$array = $this->serialize_args( $data );

		$wpdb = $this->wpdb;
		foreach($array as $row){
			$args = array();

			//Skips row if form validation fails
			if( $row == false ) continue;
			//Changes from user friendly setting to corrct value
			$row['event_id'] = $this->get_id_from_formID( $row['event_id'] );

			foreach($row as $key => $value){
				$args[$key] = $value; 
			}

			$wpdb->update($this->entriesTable, $args, array( 'id' => $row['id'] ) );
		}

		return $this->return_json('success');

		return $this->return_json('error');
	}

	public function serialize_args($array)
	{
		$option = get_option( 'leioc_paypal_delete_data' );
		$term_set = $option['terms'];

		foreach($array as $key => $value){
			//Validate form entry or return false in not a valid entry
			$event_id = sanitize_text_field( trim($value['event_id'] ) );

			$email = sanitize_email( trim($value['email']) );
			if( $this->check_valid($email) == false ) {
				$array[$key] = false;
				continue;
			}

			$start = sanitize_text_field( trim($value['start_time']) );
			if( $this->allowed_time( array( 'id'=> sanitize_text_field( trim($value['id']) ), 'time' => $start) )== false ) {
				$array[$key] = false;
				continue;
			};
			//Coverts Delete option from CSV upload
			$deleted = sanitize_text_field( (isset($value['deleted_from_event']) ? ( strtolower( trim($value['deleted_from_event']) ) === 'no' ? 1 : 0) : 1 ) );

			$phone = (isset($value['phone']) ? sanitize_text_field( trim($value['phone']) ) : '');
			if( isset($value['phone']) ) {
				if( $this->check_valid($phone) == false ) {
					$array[$key] = false;
					continue;
				};
			};

			//ent_details list
			$name = sanitize_text_field( trim($value['name']) );
			if( $this->check_valid($name) == false ) {
				$array[$key] = false;
				continue;
			};

			$age = sanitize_text_field( trim($value['age']) );
			if( $this->check_valid($age) == false ) {
				$array[$key] = false;
				continue;
			};

			$bof = sanitize_text_field( trim( strtoupper($value['bof']) ) );
			if( $this->check_valid($bof) == false ) {
				$array[$key] = false;
				continue;
			};

			$si = sanitize_text_field( trim( strtoupper($value['si']) ) );
			if( $this->check_valid($si) == false ) {
				$array[$key] = false;
				continue;
			};

			$course = sanitize_text_field( trim($value['course']) );
			if( $this->check_valid($course) == false ) {
				$array[$key] = false;
				continue;
			};

			$club = sanitize_text_field( trim( strtoupper($value['club']) ) );
			if( $this->check_valid($club) == false ) {
				$array[$key] = false;
				continue;
			};

			//Fee Details
			$fee = sanitize_text_field( trim($value['fee']) );
			if( isset($value['fee']) ){
				if( $this->check_valid($fee) == false ) {
					$array[$key] = false;
					continue;
				};
			}
			$fee_charge = sanitize_text_field( trim($value['fee_charge']) );

			$si_hire = sanitize_text_field( trim($value['si_hire']) );
			if( isset($value['si_hire']) ){
				if( $this->check_valid($si_hire) == false ) {
					$array[$key] = false;
					continue;
				};
			}

			$hire_charge = sanitize_text_field( trim($value['hire_charge']) );

			$ent_fee = trim($value['total']);

			//Terms only validated if not Admin or set in dashboard
			$terms = (isset($value['terms_checked']) ? sanitize_text_field( trim($value['terms_checked']) ) : '' );
			if( isset($term_set) && !isset($value['admin_entry']) ){
				if( $this->check_valid($terms) == false ) {
					$array[$key] = false;
					continue;
				};
			}

			$user_details = array(
				'email' => $email,
				'phone' => $phone,
				'terms_checked' => $terms,
			);

			$ent_details = array(
				'name' => $name,
				'age_class' => $age,
				'bof_num' => $bof,
				'si_num' => $si,
				'course' => $course,
				'club' => $club,
				'start_time' => $start,
			);

			$fee_details = array(
				'fee' => $fee,
				'fee_charge' => $fee_charge,
				'si_hire' => $si_hire,
				'hire_charge' => $hire_charge,
			);

			//database fields
			$args = array(
				'id' => sanitize_text_field( trim($value['id'] ) ),
				'event_id' => $event_id, 
				'leioc_user_id' => $email,
				'leioc_user_details' => maybe_serialize($user_details),
				'ent_details' => maybe_serialize($ent_details),
				'ent_course' => $course,
				'ent_start' => $start,
				'ent_fee_details' => maybe_serialize( $fee_details ),
				'ent_fee' => $ent_fee,
				'payment_id' => '',
				'ent_trash' => $deleted,
			);

			$array[$key] = $args;
		}

		return $array;
	}

	//Adds Entries to Database
	public function leioc_entry_form_submit()
	{
		if (! DOING_AJAX || ! check_ajax_referer('leioc-entry-form-nonce', 'nonce') ) {
			return $this->return_json('error');
		}

		if ( isset($_FILES['csv_file']) ) return $this->csv_bulk_entries();

		$email = isset($_POST['send_email']) ? sanitize_text_field( trim($_POST['send_email']) ) : true;

		$id = sanitize_text_field( trim($_POST['id']) );
		$this->event_id = sanitize_text_field( trim($_POST['event_id']) );

		//Allows Admin edits even id event is not published
		$pub = isset($_POST['admin_entry']) ? 0 : 1;
		$event = $this->get_publish($this->event_id, $pub);
		//Sends email if admin email send is checked
		$email = isset($_POST['admin_entry']) ? ( isset($_POST['admin-email-send']) ?: false ) : $email;

		//Checks if event is published
		if($event == false) return $this->return_json('error');
		//Checks event numbers
		$closed = $this->get_event_numbers($event);
		if($closed != '') return $this->return_json('error-max');

		//Checks if time is allowed and valid
		$check_time = $this->allowed_time( array('id'=>$id,'time' => sanitize_text_field($_POST['start_time']) ) );
		if( $check_time == false ) return $this->return_json('error-time',  $check_time );

		//Calculates Total fee due for entry
		$fee_details = (  $event['form_fee_publish'] == 1 ? $this->fee_value( $event['form_fee_details'], sanitize_text_field( trim($_POST['fee']) ), sanitize_text_field( trim($_POST['si_hire']) ) ) : '' );

		//Saves current fees to database
		$_POST['total'] = isset($fee_details) ? $fee_details['total'] : '';
		$_POST['fee_charge'] = isset($fee_details) ? $fee_details['fee'] : '';
		$_POST['hire_charge'] = isset($fee_details) ? $fee_details['si'] : '';

		$args = $this->serialize_args( array( $_POST ) );

		//Allows edits or inserts into database
		$args = $args[0];
		//Checks form validation is correct
		if($args == false) return $this->return_json('error');

		$wpdb = $this->wpdb;
		if( $id === ''){
			$entryID = $wpdb->insert($this->entriesTable, $args);
		} else {
			//Returns false if no changes are made to database
			$entryID = $wpdb->update($this->entriesTable, $args, array( 'id' => $id ) );
		}
		
		$this->set_headers( $event['form_details']['form_starts_show'] );
		
		if ($entryID) {
			$email == true ? $this->send_email( $args, $event ) : '';
			$data = array(
				'header' => $this->get_headers(),
				'body' => $this->get_rows(),
				'start' => $this->get_starts( $this->decode_starts( $event['form_details']['form_starts'] ), $event['form_details']['form_starts_show'] ),
				'count' => $this->get_event_numbers( $event, false),
				);
			return $this->return_json('success', $data);
		}

		return $this->return_json('error');
	}

	public function send_email($args, $event)
	{
		$form_email = maybe_unserialize( $event['form_email'] );
		
		//Checks if Email settings are valid
		if( !isset( $form_email) ) return;

		$subject = esc_attr( $form_email['form_subject'] );
		$msg = $form_email['form_message'];
		//Checks if subject or message are empty
		if( empty($subject) || empty($msg) ) return;

		$body = $this->replace_merge_tags( $msg, $args );

		$to = sanitize_email( $_POST['email'] );
		$subject = esc_attr( $form_email['form_subject'] );
		$message = $body .'<br>';

		$frm = isset($form_email['form_from']) ? $form_email['form_from'] : 'Orienteering Club';
		$default = explode( 'www.', site_url() );
		$reply = isset($form_email['form_reply']) ? esc_attr($form_email['form_reply']) : 'reply@' . $default[1];
		$from = 'From: ' .  $frm . ' <'. $reply . '>' . "\r\n";

		
		$attachments = '';
		if(isset($form_email['form_attach']) ){
			//Setting if no attachment set
			if( !empty($form_email['form_attach']) ){
				$dir = $_SERVER['DOCUMENT_ROOT'].'/wp-content';
				$url = $form_email['form_attach'];
				$file_location = explode('wp-content',$url);
				$attachments = array( $dir . $file_location[1] );
			}
		};

		//Sets header to HTML format
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$headers[] = $from;

		wp_mail( $to, $subject, $message, $headers, $attachments);
	}

	public function replace_merge_tags( $message, $args)
	{
		$body = $this->get_info( $message );
		$form_detail = maybe_unserialize( $args['ent_details'] );
		$fees = maybe_unserialize( $args['ent_fee_details'] );

		$form_detail['fee'] = $fees['fee'];
		$form_detail['si_hire'] = $fees['si_hire'];
		$form_detail['total'] = $args['ent_fee'];

		//Ent Details Fields only
		$fields = array(
			'name' => 'Name',
			'age_class' => 'Age Class',
			'bof_num' => 'BOF Number',
			'si_num' => 'Si Number',
			'course' => 'Course',
			'club' => 'Club',
			'start_time' => 'Start Time',
			'fee' => 'Fee Category',
			'si_hire' => 'Si Dibber Hire',
			'total' => 'Total Due',
		);

		$form_detail['all_answers'] = '';
		foreach($form_detail as $key => $value){
			if( $value == '' ) continue;
			$value = ($key === 'total' ? '&#163;'.$value : $value);
			$form_detail['all_answers'] .= $fields[$key] . ': ' . $value . '<br>';
		}
		//Removes last line break
		$form_detail['all_answers'] = preg_replace('/\<br\>$/', '', $form_detail['all_answers']);

		// Break it up into the search and replace arrays
		$search = array();
		$replace = array();
		foreach ($form_detail as $index => $value)
		{
			$search[] = "*|" . $index . "|*"; // Wrapping the text in "*|...|*"
			$replace[] = ( $index === 'total'  && !empty($value) ? '&#163;'.$value : $value);
		}

		return str_replace($search, $replace, $body);
	}

	public function set_merge_tags()
	{
		//Ent Details Fields only
		$fields = array(
					'name' => 'Name',
					'age_class' => 'Age Class',
					'bof_num' => 'BOF Number',
					'si_num' => 'Si Number',
					'course' => 'Course',
					'club' => 'Club',
					'start_time' => 'Start Time',
					'fee' => 'Fee Category',
					'si_hire' => 'Si Dibber Hire',
					'total' => 'Total Due',
					'all_answers' => 'All Answers',
				);

		$option = '<option value="">-- Select Merge Tag --</option>';
		foreach($fields as $key => $value ){
			$option .= sprintf('<option value="*|%s|*">%s</option>', $key, $value);
		}
		
		return $option;
	}

	public function return_json($status, $data = null)
	{
		$return = array(
			'status' => $status,
			'data' => $data,
		);
		wp_send_json($return);

		wp_die();
	}

	//Gets Enrty form for ADMIN side
	public function leioc_admin_entry_submit(){

		if (! DOING_AJAX || ! check_ajax_referer('leioc-entries-wp-nonce', 'nonce') ) {
			return $this->return_json('error');
		}

		$eventID = sanitize_text_field($_POST['entries_event_id']);
		$event = $this->get_admin_form($eventID);

		if ($event) {
			return $this->return_json('success', $event);
		}

		return $this->return_json('error');
	}

	/**
	 * @param $args array event id and time.
	 * @return true if allowed
	 */
	public function allowed_time( $args )
	{
		//Retuns false if not allowed 
		$id = $this->event_id;
		
		//Allows admin to enter blank times
		if( isset($_POST['admin_entry']) && $args['time'] == '' ) return true;

		$wpdb = $this->wpdb;
		//Check Start Times Type
		$event = $wpdb->prepare( "SELECT form_details FROM {$this->eventTable} WHERE id = %s", $id);
		$form_details = maybe_unserialize( $wpdb->get_var( $event ) );
		$starts = $this->decode_starts( $form_details['form_starts'] );

		//No Times set in event database
		if( $starts['type'] == 0 ) return true;

		if( !$this->check_valid($args['time']) ) return false;

		if( $starts['type'] == 2 ) return true;

		//Match database settings
		$time = $args['time'].':00';

		//Check if Entry ID and time are in database if Admin
		$sql = $wpdb->prepare( "SELECT ent_start FROM {$this->entriesTable} WHERE event_id = %d AND id=%d AND ent_trash=1", $id, $args['id']);
		$update_time = $wpdb->get_col( $sql );
		if( isset($_POST['admin_entry']) && $update_time[0] == $time ) return true;

		$sql = $wpdb->prepare( "SELECT ent_start FROM {$this->entriesTable} WHERE event_id = %d AND ent_trash=1", $id );
		$array = $wpdb->get_col( $sql );

		//Checks if time is already in entries database
		if( in_array($time, $array) ){
			return false;
		} else{
			return true;
		}

		return true;
	}
	/**
	 * @param $arg to check if valid input in form
	 * @return true if valid
	 */
	public function check_valid( $arg )
	{
		//Returns false if not valid
		if( preg_match('/-- select/i', $arg) || empty($arg) ) return false;

		return true;
	}
}