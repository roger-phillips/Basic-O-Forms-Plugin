<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use WP_List_Table;
use LEIOCPaypal\Base\BaseController;
use LEIOCPaypal\Base\EmailController;

/**
* 
*/
class InvoicesWPListTable extends WP_List_Table
{
    private $wpdb;

    public $entries;

    public $events;

    public $entries_data;
    
    public $per_page = 10;

    public $page_name;

    public $count;

    public $all_count;

    public $pub_count;

    public $draft_count;

    public $status = 1;

    public $update_bulk;

    public $base;

    private $tags = array( 
        'name' => 'Name',
        'email' => 'Email',
        'invoice' => 'Invoice Table',
    );


    public function __construct() {

		parent::__construct( 
            array(
                'singular' => 'Entry', //singular name of the listed records
                'plural'   => 'Enties', //plural name of the listed records
                'ajax'     => true, //should this table support ajax?
            )
        );

        global $wpdb;
        $this->wpdb = $wpdb;

        $this->base = new BaseController;
        $this->entries = $this->base->entriesTable;
        $this->events = $this->base->eventTable;

        $this->page_name = isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];
    }
    
    public function get_data( $id = null )
    {
        $orderby = isset($_REQUEST['orderby'] ) ? $_REQUEST['orderby'] : 'event_id';
        $order = isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
        $this->status = isset($_REQUEST['status']) ? $_REQUEST['status'] : 1;

        $san_orderby = sanitize_sql_orderby($orderby . ' ' . $order);

        $wild = '%';
        $find = isset($_POST['s']) ? trim($_POST['s']) : '';
        $like = $wild . $this->wpdb->esc_like( $find ) . $wild;
        
        $where_id = (!empty($id) ? 'event_id in ('. $id .')' : 'event_id=""');
        $args = array($this->status, $like );

        $sql  = $this->wpdb->prepare( "SELECT * FROM $this->entries WHERE {$where_id} AND ent_trash=%d AND ent_details LIKE %s ORDER BY $san_orderby", $args);
        
        $this->count = $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->entries WHERE {$where_id} AND ent_trash=%d AND ent_details LIKE %s", $args) );

        $this->all_count = $this->count_table($id, $this->status );
        $this->pub_count = $this->count_table($id, 1 );
        $this->draft_count = $this->count_table($id, 0 );

        //Sets table table 1 page only
        $this->per_page = $this->all_count + 1;

        $this->entries_data = $this->unserialize( $this->wpdb->get_results( $sql , ARRAY_A ) );
    }

    public function count_table($id, $status)
    {
        if( empty($id) ) return 0;

        return $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->entries WHERE event_id in ({$id}) AND ent_trash=%d", $status) );
    }

    public function unserialize($array){

        foreach($array as $num => $entry){

            $user = maybe_unserialize( $entry['leioc_user_details'] );
            foreach($user as $key => $value){
                $leioc[$key] = $value;   
            }
            $details = maybe_unserialize( $entry['ent_details'] );
            $details = !empty($details) ? $details : [];
            foreach($details as $key => $value){
                $entry[$key] = $value;   
            }
            $fees = maybe_unserialize( $entry['ent_fee_details'] );
            $fees = (!empty($fees) ? $fees : [] );
            foreach($fees as $key => $value){
                $entry[$key] = $value;
            }
            $array[$num] = array_merge($entry, $leioc);

            $array[$num]['unique_id'] = $this->get_check_str( $array[$num]['name'] . $array[$num]['age_class'] . $array[$num]['bof_num'] );

            //Removes dulicates from array
            unset($array[$num]['leioc_user_details']);
            unset($array[$num]['ent_details']);
            unset($array[$num]['ent_fee_details']);
        }

        return $array;
    }

    public function get_check_str( $str )
    {
        return str_replace(' ', '',  strtolower( $str ) );
    }

    public function esc_stripslashes( $arg )
    {
        $str = str_replace('\\','',stripslashes( $arg ) );
        return wp_kses( $str, $this->base->allowed_html );
    }

    public function get_columns()
    {   
        //First column after cb used on small screen
        $columns = array(
            'cb'         => '<input type="checkbox"/>',
            'name'  => 'Name',
            'club' => 'Club',
            'age_class' => 'Age Class',
            'fee' => 'Fee Type',
            'fee_charge' => 'Fee',
            'si_hire' => 'Si Hire',
            'hire_charge' => 'Hire Fee',
            'ent_fee' => 'Total Due',
            'unique_id' => 'Unique ID',
            'id'         => 'ID',
            'event' => 'Event',
            'event_id'  => 'Event ID',
        );
        return $columns;
    }

    public function column_cb($item)
    {
        return sprintf('<input type="checkbox" name="post_cb[]" value="%d" />',$item['id']);
    }

    public function prepare_items()
    {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $this->set_pagination_args(
            array(
                'total_items' => $this->count,
                'orderby'   => ! empty( $_REQUEST['orderby'] ) && '' != $_REQUEST['orderby'] ? $_REQUEST['orderby'] : 'event_id',
                'order'     => ! empty( $_REQUEST['order'] ) && '' != $_REQUEST['order'] ? $_REQUEST['order'] : 'asc',
                'status'     => ! empty( $_REQUEST['status'] ) && '' != $_REQUEST['status'] ? $_REQUEST['status'] : 1,
            )
        );

        $this->_column_headers = array($columns, $hidden);
        $this->items = $this->entries_data;
    }

    public function get_hidden_columns()
    {
        return array('id','event_id','unique_id');
    }

    public function get_sortable_columns()
    {
        return array( 
        );
    }

    public function column_default( $item, $column_name )
    {
        switch( $column_name ) { 
            case 'id':
            case 'name':
            case 'club':
            case 'age_class':
            case 'si_num':
            case 'fee':
            case 'si_hire':
            case 'ent_course':
            case 'event_id':
            case 'unique_id':
                return $item[ $column_name ];
            case 'fee_charge':   
            case 'hire_charge':
            case 'ent_fee':
                return $this->currency( $item[$column_name] );
            case 'event':
                return $this->get_event_name_from_id( $item['event_id'] );
            default:
                return 'no value';
        }
    }

    public function currency( $number )
    {
        return '&pound;' . number_format( (!empty($number) ? $this->trim_esc($number) : 0 ) , 2, '.', '' );
    }

    public function get_entry($id)
    {
        $sql = $this->wpdb->prepare("SELECT * FROM {$this->entries} WHERE id = %d", $id);
        $entry = array_pop( $this->unserialize( $this->wpdb->get_results($sql, ARRAY_A ) ) );

        return $entry;
    }

    public function get_all($id)
    {
        $sql = $this->wpdb->prepare("SELECT * FROM {$this->entries} WHERE event_id = %d", $id);
        $entries = $this->unserialize( $this->wpdb->get_results($sql, ARRAY_A ) );

        return $entries;
    }

    public function set_sub_menu()
    {
        return '<ul class="subsubsub"></ul>';
    }

    public function get_event_name_from_id($id)
    {
        return $this->wpdb->get_var( $this->wpdb->prepare( "SELECT form_title FROM {$this->events} WHERE id=%d", $id) );
    }

    public function show_table()
    {   
        $this->get_data();

        echo '<form id="leioc-invoices-list" method="post" name="leioc-invoices-list" data-url="' . admin_url('admin-ajax.php') . '" action="' . $this->page_name . '">';
        echo '<div class="leioc-msg"><span class="field-msg js-database-submission">Accessing database, please wait&hellip;</span><span class="field-msg error js-database-error">There was a problem connecting with the database, please try again!</span></div>';
        echo $this->set_sub_menu();
        
        $this->prepare_items();
        $this->search_box('Search Entries','leioc_search_entries_id');
        $this->display();
        
        echo '</form>';
    }

    public function get_info( $str )
	{
		return nl2br( wp_kses( $str, $this->allowed_html ) );
	}

    public function mail_merge( $args, $ids = null )
    {
        $options = get_option('leioc_paypal_invoice_email');
        $email = $this->esc_stripslashes( isset($options['email-message']) ? $options['email-message']: '');

        if( empty($email) ) return;
        $data = $this->get_fee_data( explode(',', $args['entries-list']) );

        //Group by unique id or user_id(currently email address) Unique Id = name+age_clas+bof_num
        $data = $this->group_by_arr( $data, ($args['group-by'] == 'person' ? 'unique_id':'leioc_user_id') );

        //Build Event Table and allowed mail_merge tags
        foreach($data as $key => $value){
            $fields = $this->tags;
            foreach($fields as $field => $name){
                $data[$key][$field] = ( $field == 'invoice' ? $this->fee_body( $this->group_by_arr( $value, 'form_title') ) : reset($value)[$field]);
            }
            if( isset($ids) ) {
                $ids = [];
                foreach($value as $row){
                    array_push( $ids, $row['id']);
                }
                $data[$key]['id'] = $ids;
            };  
        }

        $arr = [];
        foreach($data as $key => $merge){
            // Break it up into the search and replace arrays
            $search = array();
            $replace = array();
            foreach ($merge as $index => $value)
            {
            	$search[] = "*|" . $index . "|*"; // Wrapping the text in "*|...|*"
            	$replace[] = ($index == 'invoice' ? sprintf( '<table>%s</table>', $value) : $this->trim_esc( $value ) );
            }

            $merged = array( 
                'body' => nl2br( str_replace($search, $replace, $email) ),
                'email' =>  reset( $merge )['email'],
                'id' => $merge['id'],
            );
            array_push( $arr, $merged);
        }

        return $arr;
    }

    private function trim_esc( $str )
    {
        return esc_attr( preg_replace('/\s+/', ' ', $str ) );
    }

    private function fee_body( $arr )
    {
        $str = '';
        $fee = 0;
        $cssheader = 'style="border-bottom: 1px solid black; text-align:left; padding-top:0.75rem;"';
        $cssfee = 'style="border-bottom: 1px solid black; text-align:left; padding-top:0.75rem;"';
        $csstotal = 'style="border-bottom: 1px solid black; text-align:left; vertical-align: bottom; height: 2.5rem;"';
        foreach($arr as $key => $entry){
            $date = date('jS F Y', strtotime($entry[array_key_first($entry)]['form_date'] ) );
            $str .=  sprintf('<thead><tr><th colspan="4" %s>%s - %s</th></thead><tbody>', $cssheader, $this->trim_esc($key), $date );
            $total = 0;
            foreach($entry as $value){
                $arr2 = array(
                    $this->trim_esc( $value['name']) , 
                    'Fee Type: ' . $this->trim_esc( $value['fee'] ) . ' - ' . $this->currency( $value['fee_charge'] ), 
                    'Si Hire: ' . $this->trim_esc( $value['si_hire'] ) . ' - ' .$this->currency( $value['hire_charge'] ), 
                    'Fee: ' . $this->currency( $value['ent_fee'])
                );
                $in_str_arr = array_fill( 0, count( $arr2 ), '<td>%s</td>' );
                $in_str = join( '', $in_str_arr );
                $str .= vsprintf( '<tr>' . $in_str . '</tr>',  $arr2 );

                $total = $total + $value['ent_fee'];
            }
            $str .= sprintf('<tr><td></td><td></td><td %s>Event Fee Total: %s<td></tr>', $cssfee,$this->currency( $total) );
            $fee = $fee + $total;
        }
        $str .= sprintf('<tr><td></td><td></td><td %s>Total Due: %s</td></tr>', $csstotal, $this->currency($fee) );
        return $str .= '</tbody>';
    }

    private function group_by_arr( $old_arr, $criteria )
    {
        $arr = array();
        foreach ($old_arr as $key => $item) {
            $arr[$item[$criteria]][$key] = $item;
        }
        ksort($arr, SORT_NUMERIC);
        return $arr;
    }

    private function get_fee_data( $ids )
    {
        if( empty($ids) ) return [];
        $in_str_arr = array_fill( 0, count( $ids ), '%s' );
        $in_str = join( ',', $in_str_arr );
        $sql = $this->wpdb->prepare( "SELECT * FROM {$this->entries} AS e JOIN (SELECT form_title, id AS e_id, form_date FROM {$this->events} ) AS t ON e.event_id = t.e_id WHERE e.id IN ({$in_str})", $ids );
        return $this->unserialize( $this->wpdb->get_results( $sql , ARRAY_A ) );
    }

    public function set_tags()
    {
        $fields = $this->tags;
        $option = '<option value="">-- Select Merge Tag --</option>';
		foreach($fields as $key => $value ){
			$option .= sprintf('<option value="*|%s|*">%s</option>', $key, $value);
		}
		return $option;
    }

    public function mail_merge_preview( $args )
    {
        $merged = isset($args['email']) ? $this->mail_merge( $args, 'Yes' ) : $this->mail_merge( $args );
        $msg = array(
            'body' => '<b>' . esc_attr( 'Check invoices selection and email message settings.' ) . '</b>',
            'count' => 0,
        );
        if( empty($merged )) return $this->return_json ('success', [$msg] );

        //Sends Email if set
        if( isset($args['email']) ){
            $this->send_mail_merge( $merged );
            return;
        }
        //Convert merged to display in preview
        return $this->return_json ('success', $merged);

        return $this->return_json ('error');
    }

    public function send_mail_merge( $merged )
    {
        $options = get_option('leioc_paypal_invoice_email');
        $frm = isset($options['from']) ? $options['from']: '';
        $reply = isset($options['reply']) ? $options['reply']: '';
        $subject = isset($options['subject']) ? $options['subject']: '';

        $email = new EmailController;

        $from = array(
            'from' => $frm,
            'reply' => $reply,
        );

        $sent = array(
            'sent' => 0,
            'fail' => '',
        );

        //Sends Emails and records message to database - payment_id
        foreach( $merged as $row ){
            $args = array(
                'to' => $row['email'],
                'subject' => $subject,
                'body' => $row['body'],
            );

            $success = $email->send_email( $args, $from );
            if($success == false ){
                $sent['fail'] = $sent['fail'] . $args['to'] . ', ';
            } else {
                $sent['sent'] = $sent['sent'] + 1;
                foreach($row['id'] as $id){
                    $this->save_email_database( $id, $row['body'] );
                }
            }
        };

        return $this->return_json ('success', array_merge($merged, $sent) );

        return $this->return_json ('error');
    }

    private function save_email_database( $id, $msg)
    {
        $msgs = maybe_unserialize( $this->wpdb->get_results( $this->wpdb->prepare("SELECT payment_id FROM {$this->entries} WHERE id=%d", $id ), ARRAY_A ) );

        $timestamp = date('Y-m-d H:i:s');
        $new_msg = array( 
            $timestamp => array(
                'msg' => $msg,
                'timestamp' => $timestamp,
                ),
            );
        $args = array(
            'payment_id' => maybe_serialize( array_merge( $new_msg, $msgs ) ),
        );

        //Returns false if no changes are made to database
	    $this->wpdb->update($this->entries, $args , array( 'id' => $id ) );
        return;
    }
    
    public function ajax_response()
    {
        if (! DOING_AJAX || ! check_ajax_referer('leioc-invoice-entries-wp-nonce', 'nonce') ) {
			return $this->return_json('error');
        }

        //Mail Merge
        if( $_REQUEST['action'] == 'leioc_invoices_mail_merge' ) return $this->mail_merge_preview( $_POST );

        $id = sanitize_text_field($_POST['invoice_event_id']);

        if( isset( $_REQUEST['action3'] ) ) $_REQUEST['action'] = $_REQUEST['action3'];

        get_pagenum_link(  $this->get_pagenum(), +1 );

        $this->get_data($id);
        $this->prepare_items();

        extract( $this->_args );
        extract( $this->_pagination_args, EXTR_SKIP );
       
        ob_start();
        if ( ! empty( $_REQUEST['no_placeholder'] ) )
            $this->display_rows();
        else
            $this->display_rows_or_placeholder();
        $rows = ob_get_clean();

        ob_start();
        $this->print_column_headers();
        $headers = ob_get_clean();

        ob_start();
        $this->pagination('top');
        $pagination_top = ob_get_clean();
    
        ob_start();
        $this->pagination('bottom');
        $pagination_bottom = ob_get_clean();

        ob_start();
        $this->search_box('Search Entries','leioc_search_entries_id');
        $search = ob_get_clean();

        ob_start();
        $this->bulk_actions('top');
        $bulk_actions_top = ob_get_clean();

        ob_start();
        $this->bulk_actions('bottom');
        $bulk_actions_bottom = ob_get_clean();

        $response = array( 'rows' => $rows );
        $response['pagination']['top'] = $pagination_top;
        $response['pagination']['bottom'] = $pagination_bottom;
        $response['column_headers'] = $headers;
        $response['count'] = esc_attr( $this->all_count );
        $response['one_page']  = esc_attr( $this->per_page > $this->all_count ? ($this->all_count == 0 ? 'one-page no-pages' : 'one-page' ) : '' );
        $response['sub_menu'] = $this->set_sub_menu();

        if ( isset( $total_items ) )
        $response['total_items_i18n'] = sprintf( _n( '1 item', '%s items', $total_items ), number_format_i18n( $total_items ) );
 
        if ( isset( $total_pages ) ) {
            $response['total_pages'] = $total_pages;
            $response['total_pages_i18n'] = number_format_i18n( $total_pages );
        }

        if ( isset( $search) ) $response['search'] = $search;
            
        if ( isset( $bulk_actions_top) ) $response['bulk_actions_top'] = $bulk_actions_top;
        if ( isset( $bulk_actions_bottom) ) $response['bulk_actions_bottom'] = $bulk_actions_bottom;
        
        if( isset($response) ) return $this->return_json('success', $response);

	    return $this->return_json('error');
    }

    public function return_json($status, $data = null)
	{
		$return = array(
			'status' => $status,
			'data' => $data,
		);
		wp_send_json($return);

		wp_die();
    }

    //Only needed with AJAX
    function display() {
 
        wp_nonce_field( 'leioc-invoice-entries-wp-nonce', 'nonce' );
        echo '<input id="order" type="hidden" name="order" value="' . $this->_pagination_args['order'] . '" />';
        echo '<input id="orderby" type="hidden" name="orderby" value="' . $this->_pagination_args['orderby'] . '" />';
        echo '<input id="status" type="hidden" name="status" value="' . $this->_pagination_args['status'] . '" />';
        echo '<input type="hidden" name="ajax_action" value="leioc_admin_payments_invoices_events_wp_list">';
        echo '<input type="hidden" name="invoice_event_id" value="1">';

        parent::display();
    }

    //Only needed with AJAX. Changes $_GET to $_REQUEST['order] and orderby
    public function print_column_headers( $with_id = true ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();
     
        $request_uri =  isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];

        $current_url = set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $request_uri );
        $current_url = remove_query_arg( 'paged', $current_url );
     
        if ( isset( $_REQUEST['orderby'] ) ) {
            $current_orderby = $_REQUEST['orderby'];
        } else {
            $current_orderby = '';
        }
     
        if ( isset( $_REQUEST['order'] ) && 'desc' === $_REQUEST['order'] ) {
            $current_order = 'desc';
        } else {
            $current_order = 'asc';
        }
     
        if ( ! empty( $columns['cb'] ) ) {
            static $cb_counter = 1;
            $columns['cb']     = '<label class="screen-reader-text" for="cb-select-all-' . $cb_counter . '">' . __( 'Select All' ) . '</label>'
                . '<input id="cb-select-all-' . $cb_counter . '" type="checkbox" />';
            $cb_counter++;
        }
     
        foreach ( $columns as $column_key => $column_display_name ) {
            $class = array( 'manage-column', "column-$column_key" );
     
            if ( in_array( $column_key, $hidden, true ) ) {
                $class[] = 'hidden';
            }
     
            if ( 'cb' === $column_key ) {
                $class[] = 'check-column';
            } elseif ( in_array( $column_key, array( 'posts', 'comments', 'links' ), true ) ) {
                $class[] = 'num';
            }
     
            if ( $column_key === $primary ) {
                $class[] = 'column-primary';
            }
     
            if ( isset( $sortable[ $column_key ] ) ) {
                list( $orderby, $desc_first ) = $sortable[ $column_key ];
     
                if ( $current_orderby === $orderby ) {
                    $order = 'asc' === $current_order ? 'desc' : 'asc';
     
                    $class[] = 'sorted';
                    $class[] = $current_order;
                } else {
                    $order = strtolower( $desc_first );
     
                    if ( ! in_array( $order, array( 'desc', 'asc' ), true ) ) {
                        $order = $desc_first ? 'desc' : 'asc';
                    }
     
                    $class[] = 'sortable';
                    $class[] = 'desc' === $order ? 'asc' : 'desc';
                }
     
                $column_display_name = sprintf(
                    '<a href="%s"><span>%s</span><span class="sorting-indicator"></span></a>',
                    esc_url( add_query_arg( compact( 'orderby', 'order' ), $current_url ) ),
                    $column_display_name
                );
            }
     
            $tag   = ( 'cb' === $column_key ) ? 'td' : 'th';
            $scope = ( 'th' === $tag ) ? 'scope="col"' : '';
            $id    = $with_id ? "id='$column_key'" : '';
     
            if ( ! empty( $class ) ) {
                $class = "class='" . implode( ' ', $class ) . "'";
            }
     
            echo "<$tag $scope $id $class>$column_display_name</$tag>";
        }
    }

    public function search_box( $text, $input_id ) {
        if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) {
            return;
        }
 
        $input_id = $input_id . '-search-input';
 
        if ( ! empty( $_REQUEST['post_mime_type'] ) ) {
            echo '<input type="hidden" name="post_mime_type" value="' . esc_attr( $_REQUEST['post_mime_type'] ) . '" />';
        }
        if ( ! empty( $_REQUEST['detached'] ) ) {
            echo '<input type="hidden" name="detached" value="' . esc_attr( $_REQUEST['detached'] ) . '" />';
        }
        ?>
        <p class="search-box">
            <label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo $text; ?>:</label>
            <input type="search" id="<?php echo esc_attr( $input_id ); ?>" name="s" value="<?php _admin_search_query(); ?>" />
                <?php submit_button( $text, '', '', false, array( 'id' => 'search-submit' ) ); ?>
        </p>
                <?php
    }
    
}
