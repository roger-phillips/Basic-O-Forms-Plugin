<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

class Activate
{

    public static function activate()
    {
        flush_rewrite_rules();

        $default = array();

        if ( ! get_option( 'leioc_paypal_ent_form' ) ) {
			update_option( 'leioc_paypal_ent_form', $default );
		}
        //Resets Delete Data Option to false on activation
		update_option( 'leioc_paypal_delete_data', array( 'delete'=> 0, 'timestamp'=> date('Y-m-d H:i:s'), 'phone' => 1) );
    }
}