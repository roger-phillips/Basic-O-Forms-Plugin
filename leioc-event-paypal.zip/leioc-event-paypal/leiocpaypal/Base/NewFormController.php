<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use \LEIOCPaypal\Base\BaseController;
use \LEIOCPaypal\Api\FormFieldsApi;

/**
* Controller for the entries form and Admin entries form
*/
class NewFormController extends BaseController
{
    private $user_details = [
        array(//Rows
            'email' => array(
                'type' => 'email',
                'label' => 'Email Address',
                'placeholder' => 'name@example.com',
                'pattern' => '[a-zA-Z0-9.!#$%&amp;’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+',
                'required' => 'yes',
                'note' => 'A valid email address is required to enter this event.',
                'error' => 'The email address is not valid',
            ),
            'phone' => array(
                'type' => 'tel',
                'label' => 'Phone',
                'placeholder' => 'e.g. 0123456789',
                'pattern' => '^[0-9]*$',
                'required' => 'yes',
                'note' => 'Please enter a mobile phone number if possible.',
                'error' => 'The phone number is not valid',
            ),
        ), 
    ];

    

    public function register()
	{
		$this->set_global();
		add_shortcode( 'leioc-entry-new-table', array( $this, 'entry_table' ) );
    }

    private function set_global()
	{
		global $wpdb;
		$this->wpdb = $wpdb;

		$this->now = strtotime(date("Y-m-d H:i:s"));
	}

    public function entry_table($attr)
	{
		ob_start();

		$args = shortcode_atts( array(
			'id' => '',
			'title' => '',
			), $attr );

        $form = new FormFieldsApi;

        $template = $this->templates['basic-event'];
        $formfields = array_merge( $this->user_details, $template);
        //https://jsfiddle.net/nz2hL6vn/1/

        echo '<div class="leioc-entry-form-wrapper">';
        echo $form->formfields( $formfields ) ;
        echo '</div>';

        return ob_get_clean();
    }
}