<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

/**
* 
*/
class dbTableController
{
    public static function register()
    {
        global $wpdb;
        global $db_version;
    
        $db_version = '1.0';
            
        $charset_collate = $wpdb->get_charset_collate();
    
        $entries = $wpdb->prefix . 'leioc_paypal_entries';
        $events = $wpdb->prefix . 'leioc_paypal_events';
    
        $sql = "CREATE TABLE $events (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
            form_id int(6) NOT NULL UNIQUE,
            form_title varchar(300) DEFAULT '' NOT NULL,
            form_open datetime NULL,
            form_date datetime NOT NULL,
            form_close datetime NOT NULL,
            form_max int(5) NOT NULL,
            form_details MEDIUMTEXT DEFAULT '' NOT NULL,
            form_publish int(1) NULL,
            form_email MEDIUMTEXT DEFAULT '' NOT NULL,
            form_fee_details MEDIUMTEXT DEFAULT '' NOT NULL,
            form_fee_publish int(1) NOT NULL,
            form_trash int(1) NOT NULL,
            PRIMARY KEY  (id)
        ) $charset_collate";

        $sql2 = "CREATE TABLE $entries (
            id mediumint(10) NOT NULL AUTO_INCREMENT,
            time TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
            event_id int(6) NOT NULL,
            leioc_user_id varchar(100) NOT NULL,
            leioc_user_details varchar(800) NOT NULL ,
            ent_details LONGTEXT DEFAULT '' NOT NULL,
            ent_course varchar(100) NOT NULL,
            ent_start time NULL,
            ent_fee_details MEDIUMTEXT DEFAULT '' NOT Null,
            ent_fee decimal(19,2) NOT NULL,
            payment_id varchar(100) DEFAULT '' NOT NULL,
            ent_trash int(1) NOT NULL,
            PRIMARY KEY (id)
        ) $charset_collate;";
            
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        
        dbDelta( $sql );
        dbDelta( $sql2 );
    
        add_option( 'leioc_paypal_event_db_version', $db_version );
    }

}