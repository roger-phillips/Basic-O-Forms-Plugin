<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use \LEIOCPaypal\Base\BaseController;

/**
* Controller for the sending Emails from plugin
*/
class EmailController extends BaseController
{

    public function send_email( $msg , $from = null, $bcc = null)
    {
        $to = sanitize_email( $msg['to'] );
		$subject = esc_attr__( $msg['subject'] );
		$message = $msg['body'] .'<br>';

        //Checks if subject or message are empty
		if( empty($subject) || empty($message) || empty($to) ) return false;

        //Sets generic email reply address based on website URL
        $frm = esc_attr__( isset($from['from']) ? $from['from'] : 'Orienteering Club' );
		$default = explode( 'www.', site_url() );
		$reply = isset($from['reply']) ? esc_attr__($from['reply']) : 'reply@' . $default[1];
		$from_email = 'From: ' .  $frm . ' <'. $reply . '>' . "\r\n";

        //Sets header to HTML format
		$headers[] = 'Content-Type: text/html; charset=UTF-8';
		$headers[] = $from_email;

		if( isset($bcc) ) $headers[] = 'Bcc: ' . $bcc;

		return wp_mail( $to, $subject, $message, $headers);
    }
}