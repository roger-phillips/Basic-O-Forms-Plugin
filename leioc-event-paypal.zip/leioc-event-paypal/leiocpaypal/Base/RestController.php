<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

/**
* 
*/
class RestController
{
    public function register()
	{
        add_action( 'rest_api_init', function() {
            register_rest_route( 'basic-o-form/v1', '/entry_form', array(
                'methods' => 'GET',
                'callback' =>  array( $this, 'entry_func'),
                'permission_callback' => '__return_true',
            ) );
        });
    }

    public function entry_func()
    {
        return 'This is now working and awesome!';
    }
}