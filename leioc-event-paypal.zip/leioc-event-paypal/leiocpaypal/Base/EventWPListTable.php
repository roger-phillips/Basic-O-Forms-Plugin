<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use WP_List_Table;
use \LEIOCPaypal\Base\BaseController;

/**
* 
*/
class EventWPListTable extends WP_List_Table
{
    private $wpdb;
    
    public $events;

    public $entries;

    public $event_data;

    public $per_page = 20;

    public $page_name = 'leioc_admin_dashboard';

    public $entries_page_name = 'leioc_entries';

    public $count;

    public $all_count;

    public $pub_count;

    public $draft_count;

    public $status = 1;

    public $update_bulk;

    public $base;
  

    public function __construct() {

		parent::__construct( 
            array(
                'singular' => 'Event', //singular name of the listed records
                'plural'   => 'Events', //plural name of the listed records
                'ajax'     =>  true, //should this table support ajax?
            )
        );

        global $wpdb;
        $this->wpdb = $wpdb;

        $this->base = new BaseController;

        $this->events = $this->base->eventTable;

        $this->entries = $this->base->entriesTable;

        $this->page_name = isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];
    }
    
    public function get_data()
    {
        $this->process_bulk_action(); //Also checks nounce

        if( isset($_POST['publish']) ){
            $arr = $_POST['publish'];
            foreach($arr as $value){
                if($value != ''){
                    $args = explode( ',', $value);
                    $this->set_publish( [ $args[1] ], intval($args[0]) );
                    break;
                }
            }    
        }

        $orderby = isset($_REQUEST['orderby'] ) ? $_REQUEST['orderby'] : 'form_date';
        $order = isset($_REQUEST['order']) ? $_REQUEST['order'] : 'desc';
        $this->status = isset($_REQUEST['status']) ? $_REQUEST['status'] : 1;

        $san_orderby = sanitize_sql_orderby($orderby . ' ' . $order);

        $page_num = isset( $this->update_bulk ) ? $this->update_bulk : $this->get_pagenum() ;
        $offset = ( $page_num * $this->per_page ) - $this->per_page;

        $wild = '%';
        $find = isset($_POST['s']) ? trim($_POST['s']) : '';
        $like = $wild . $this->wpdb->esc_like( $find ) . $wild;

        $sql  = $this->wpdb->prepare( "SELECT * FROM $this->events WHERE form_title LIKE %s AND form_trash=%d ORDER BY $san_orderby LIMIT $offset, $this->per_page", $like, $this->status );

        $this->count = $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->events WHERE form_title LIKE %s AND form_trash=%d", $like, $this->status) );

        $this->all_count = $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->events WHERE form_trash=%d", $this->status) );

        $this->pub_count = $this->wpdb->get_var( "SELECT count(*) FROM $this->events WHERE form_trash=1" );

        $this->draft_count = $this->wpdb->get_var( "SELECT count(*) FROM $this->events WHERE form_trash=0" );

        $this->event_data = $this->wpdb->get_results( $sql , ARRAY_A );
    }

    public function unserialize($array)
    {
        foreach($array as $num => $entry){
            $user = maybe_unserialize( $entry['form_details'] );
            foreach($user as $key => $value){
                $leioc[$key] = $value;   
            }
            $array[$num] = array_merge($entry, $leioc);

            $details = maybe_unserialize( $entry['form_email'] );
            foreach($details as $key => $value){
                $email[$key] = maybe_unserialize($value);   
            }
            $array[$num] = array_merge($array[$num], $email);
           
            //Removes dulicates from array
            unset($array[$num]['form_details']);
            unset($array[$num]['form_email']);
        }

        return $array;
    }
    
    public function get_columns()
    {
        $columns = array(
            'cb'         => '<input type="checkbox"/>',
            'form_date'  => 'Event Date',
            'form_title' => 'Event',
            'form_open'  => 'Entries Open',
            'form_close' => 'Entries Close',
            'form_id'    => 'Event Id',
            'form_publish' => 'Show on Page',
            'action'     => 'Action',
            'id'         => 'ID',
        );
        return $columns;
    }

    public function column_cb($item)
    {
        return sprintf('<input type="checkbox" name="post_cb[]" value="%s" />',$item['id']);
    }
      
    public function prepare_items()
    {

        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $this->set_pagination_args(
            array(
                'total_items' => $this->count,
                'per_page' => $this->per_page,
                'total_pages'   => ceil( $this->count / $this->per_page ),
                'orderby'   => ! empty( $_REQUEST['orderby'] ) && '' != $_REQUEST['orderby'] ? $_REQUEST['orderby'] : 'form_date',
                'order'     => ! empty( $_REQUEST['order'] ) && '' != $_REQUEST['order'] ? $_REQUEST['order'] : 'desc',
                'status'     => ! empty( $_REQUEST['status'] ) && '' != $_REQUEST['status'] ? $_REQUEST['status'] : 1,
            )
        );

        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->items = $this->event_data;
    }

    public function get_bulk_actions()
    {
        if( $this->status == 1) {
            $actions = array(
                'show' => 'Show on Page',
                'stop' => 'Hide on Page',
                'draft' => 'Move to Bin',
            );
        } else {
            $actions = array(
                'delete' => 'Delete',
                'publish' => 'Publish',
            );
        };

        return $actions;
    }

    public function get_hidden_columns()
    {
        return array('id');
    }

    public function get_sortable_columns()
    {
        return array(
            'form_date' => array('form_date', true),
            'form_title' => array('form_title', true),
        );
    }

    public function column_default( $item, $column_name )
    {
        switch( $column_name ) { 
            case 'id':
            case 'form_id':
            case 'form_title':
                return $item[ $column_name ];
            case 'form_publish':
                return $this->set_checkbox($item[ $column_name ], $item['id']);
            case 'form_open':
            case 'form_close':
                return date('H:i, D d-m-y', strtotime($item[$column_name]) );
            case 'form_date':
                return $this->column_entries( date('D dS M Y', strtotime($item[$column_name]) ), $item['form_id'] );
            case 'action':
                return $this->set_edit_btn($item['id']);
            default:
                return 'no value';
        }
    }

    public function set_checkbox($item, $id)
    {
        $checked = isset($item) ? ( $item == 1 ? 'checked' : '' ): '';

        return sprintf('<div class="leioc-ui-toggle-small"><input type="checkbox" class="publish" id="pub_%1$s"data-publish-id="%1$s" value="1" %2$s /><label for="pub_%1$s"><div></div></label></div><input type="hidden" id="publish_%1$s" name="publish[]"/>',$id, $checked);
    }

    public function set_edit_btn($id)
    {
        return sprintf('<button type="button" class="button button-primary button-small" style="display: inline-block" name="edit_event[]" value="%s" >EDIT</button>',$id);
    }

    public function process_bulk_action()
    {        
        $action = $this->current_action();

        $ids = isset($_POST['post_cb']) ? $_POST['post_cb'] : array();

        switch ( $action ) {

            case 'delete':
                if (!empty($ids)) {
                    $this->set_delete($ids);
                }
                return;
            case 'show':
                if (!empty($ids)) {
                    $this->set_publish($ids, 1);
                    return;
                }
            case 'stop':
                if (!empty($ids)) {
                    $this->set_publish($ids, 0);
                    return;
                }
            case 'draft':
                if (!empty($ids)) {
                    $this->set_draft($ids);
                }
                return;
            case 'publish':
                if (!empty($ids)) {
                    $this->set_draft($ids, 1);
                }
                return;
            default:
                // do nothing or something else
                return;
        }

        return;
    }

    public function set_draft($ids, $trash = 0)
    {
        foreach($ids as $id){
            $this->wpdb->update($this->events, array('form_trash'=> $trash), array('id'=>$id));
        }
        return;
    }

    public function set_delete($ids)
    {   
        $placeholders = implode( ', ', array_fill( 0, count( $ids), '%d' ) );

        $sql = $this->wpdb->prepare("DELETE FROM {$this->entries} WHERE event_id IN({$placeholders})", $ids);
        $this->wpdb->query($sql);
        
        $sql = $this->wpdb->prepare("DELETE FROM {$this->events} WHERE id IN({$placeholders})", $ids);
        $this->wpdb->query($sql);

        $this->update_bulk = 1;

        return;
    }

    public function set_publish($ids, $pub = 0)
    {
        foreach($ids as $id){
            $this->wpdb->update( $this->events, array( 'form_publish' => $pub), array( 'id' => $id ), array( '%d' ), array( '%d' ) );
        }

        return;
    }

    public function get_event($id)
    {
        $sql = $this->wpdb->prepare("SELECT * FROM {$this->events} WHERE id = %d", $id);
        return array_pop( $this->unserialize( $this->wpdb->get_results($sql, ARRAY_A ) ) );
    }

    public function set_sub_menu()
    {
        $status = $this->status;

        return sprintf('<ul class="subsubsub"><li class="publish"><a href="%s&status=1" %s>Published %s</a></li> | <li class="draft"><a href="%s&status=0" %s>Draft %s </a></li></ul>', $this->page_name, ($status == 1 ? 'class="current"' : '' ), $this->add_span( $this->pub_count ), $this->page_name, ($status == 0 ? 'class="current"' : '' ), $this->add_span( $this->draft_count ) );
    }

    public function add_span($count)
    {
        return sprintf('<span class="count">(%d)</span>', $count);
    }

    function column_entries($item, $id)
    {
        $actions = array(
                  'entries'      => sprintf('<a href="?page=%s&id=%s">Entries</a>',$this->entries_page_name,$id),
              );
      
        return sprintf('%1$s %2$s', $item, $this->row_actions($actions, true) );
      }

    public function show_table()
    {
        $this->get_data();

        echo '<form method="post" id="leioc_search_event" name="leioc_search_event" data-url="' . admin_url('admin-ajax.php') . '" action="' . $this->page_name . '">';
        echo '<div class="leioc-msg"><small class="field-msg js-database-submission">Accessing database, please wait&hellip;</small>
        <small class="field-msg error js-database-error">There was a problem connecting with the database, please try again!</small></div>';
        echo $this->set_sub_menu();
        
        $this->prepare_items();
        $this->search_box('Search Events','leioc_search_events_id');
        $this->display(); 

        echo '</form>';
    }

    public function ajax_response() {
  
        if (! DOING_AJAX || ! check_ajax_referer('leioc-event-wp-nonce', 'nonce') ) {
			return $this->return_json('error');
        }

        //Returns data for entry to admin edit
        if(isset($_POST['edit_event']) ) return $this->return_json('success', $this->get_event( $_POST['edit_event'] ) );

        if( isset( $_REQUEST['action3'] ) ) $_REQUEST['action'] = $_REQUEST['action3'];

        get_pagenum_link(  $this->get_pagenum(), +1 );

        $this->get_data();
        $this->prepare_items();

        extract( $this->_args );
        extract( $this->_pagination_args, EXTR_SKIP );
       
        ob_start();
        if ( ! empty( $_REQUEST['no_placeholder'] ) )
            $this->display_rows();
        else
            $this->display_rows_or_placeholder();
        $rows = ob_get_clean();

        ob_start();
        $this->print_column_headers();
        $headers = ob_get_clean();

        ob_start();
        $this->pagination('top');
        $pagination_top = ob_get_clean();
    
        ob_start();
        $this->pagination('bottom');
        $pagination_bottom = ob_get_clean();

        ob_start();
        $this->search_box('Search Events','leioc_search_events_id');
        $search = ob_get_clean();

        ob_start();
        $this->bulk_actions('top');
        $bulk_actions_top = ob_get_clean();

        ob_start();
        $this->bulk_actions('bottom');
        $bulk_actions_bottom = ob_get_clean();

        $response = array( 'rows' => $rows );
        $response['pagination']['top'] = $pagination_top;
        $response['pagination']['bottom'] = $pagination_bottom;
        $response['column_headers'] = $headers;
        $response['count'] = esc_attr( $this->all_count );
        $response['one_page']  = esc_attr( $this->per_page > $this->all_count ? ($this->all_count == 0 ? 'one-page no-pages' : 'one-page' ) : '' );
        $response['sub_menu'] = $this->set_sub_menu();

        if ( isset( $total_items ) )
        $response['total_items_i18n'] = sprintf( _n( '1 item', '%s items', $total_items ), number_format_i18n( $total_items ) );
 
        if ( isset( $total_pages ) ) {
            $response['total_pages'] = $total_pages;
            $response['total_pages_i18n'] = number_format_i18n( $total_pages );
        }

        if ( isset( $search) ) $response['search'] = $search;
            
        if ( isset( $bulk_actions_top) ) $response['bulk_actions_top'] = $bulk_actions_top;
        if ( isset( $bulk_actions_bottom) ) $response['bulk_actions_bottom'] = $bulk_actions_bottom;
        
        if( isset($response) ) return $this->return_json('success', $response);

	    return $this->return_json('error');
    }

    public function return_json($status, $data = null)
	{
		$return = array(
			'status' => $status,
			'data' => $data,
		);
		wp_send_json($return);

		wp_die();
    }

    //Only needed with AJAX
    function display() {
 
        wp_nonce_field( 'leioc-event-wp-nonce', 'nonce' );
        echo '<input id="order" type="hidden" name="order" value="' . $this->_pagination_args['order'] . '" />';
        echo '<input id="orderby" type="hidden" name="orderby" value="' . $this->_pagination_args['orderby'] . '" />';
        echo '<input id="status" type="hidden" name="status" value="' . $this->_pagination_args['status'] . '" />';
        echo '<input type="hidden" name="ajax_action" value="admin_event_wp_list">';

        parent::display();
    }

    //Only needed with AJAX. Changes $_GET to $_REQUEST['order] and orderby
    public function print_column_headers( $with_id = true ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();
     
        $request_uri =  isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];

        $current_url = set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $request_uri );
        $current_url = remove_query_arg( 'paged', $current_url );
     
        if ( isset( $_REQUEST['orderby'] ) ) {
            $current_orderby = $_REQUEST['orderby'];
        } else {
            $current_orderby = '';
        }
     
        if ( isset( $_REQUEST['order'] ) && 'desc' === $_REQUEST['order'] ) {
            $current_order = 'desc';
        } else {
            $current_order = 'asc';
        }
     
        if ( ! empty( $columns['cb'] ) ) {
            static $cb_counter = 1;
            $columns['cb']     = '<label class="screen-reader-text" for="cb-select-all-' . $cb_counter . '">' . __( 'Select All' ) . '</label>'
                . '<input id="cb-select-all-' . $cb_counter . '" type="checkbox" />';
            $cb_counter++;
        }
     
        foreach ( $columns as $column_key => $column_display_name ) {
            $class = array( 'manage-column', "column-$column_key" );
     
            if ( in_array( $column_key, $hidden, true ) ) {
                $class[] = 'hidden';
            }
     
            if ( 'cb' === $column_key ) {
                $class[] = 'check-column';
            } elseif ( in_array( $column_key, array( 'posts', 'comments', 'links' ), true ) ) {
                $class[] = 'num';
            }
     
            if ( $column_key === $primary ) {
                $class[] = 'column-primary';
            }
     
            if ( isset( $sortable[ $column_key ] ) ) {
                list( $orderby, $desc_first ) = $sortable[ $column_key ];
     
                if ( $current_orderby === $orderby ) {
                    $order = 'asc' === $current_order ? 'desc' : 'asc';
     
                    $class[] = 'sorted';
                    $class[] = $current_order;
                } else {
                    $order = strtolower( $desc_first );
     
                    if ( ! in_array( $order, array( 'desc', 'asc' ), true ) ) {
                        $order = $desc_first ? 'desc' : 'asc';
                    }
     
                    $class[] = 'sortable';
                    $class[] = 'desc' === $order ? 'asc' : 'desc';
                }
     
                $column_display_name = sprintf(
                    '<a href="%s"><span>%s</span><span class="sorting-indicator"></span></a>',
                    esc_url( add_query_arg( compact( 'orderby', 'order' ), $current_url ) ),
                    $column_display_name
                );
            }
     
            $tag   = ( 'cb' === $column_key ) ? 'td' : 'th';
            $scope = ( 'th' === $tag ) ? 'scope="col"' : '';
            $id    = $with_id ? "id='$column_key'" : '';
     
            if ( ! empty( $class ) ) {
                $class = "class='" . implode( ' ', $class ) . "'";
            }
     
            echo "<$tag $scope $id $class>$column_display_name</$tag>";
        }
    }

    public function search_box( $text, $input_id ) {
        if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) {
            return;
        }
 
        $input_id = $input_id . '-search-input';
 
        if ( ! empty( $_REQUEST['post_mime_type'] ) ) {
            echo '<input type="hidden" name="post_mime_type" value="' . esc_attr( $_REQUEST['post_mime_type'] ) . '" />';
        }
        if ( ! empty( $_REQUEST['detached'] ) ) {
            echo '<input type="hidden" name="detached" value="' . esc_attr( $_REQUEST['detached'] ) . '" />';
        }
        ?>
        <p class="search-box">
            <label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo $text; ?>:</label>
            <input type="search" id="<?php echo esc_attr( $input_id ); ?>" name="s" value="<?php _admin_search_query(); ?>" />
                <?php submit_button( $text, '', '', false, array( 'id' => 'search-submit' ) ); ?>
        </p>
                <?php
    }

}