<?php
/**
* @package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use \LEIOCPaypal\Base\BaseController;

class Enqueue extends BaseController
{
    public function register(){
        add_action( 'admin_enqueue_scripts', array($this,'enqueue'));
    }

    //CSS & Scripts Files
    public function enqueue(){
        //enqueue media uploader script
        wp_enqueue_media();
        //enqueue all our scripts
        wp_enqueue_style('leiocpaypalcss', $this->plugin_url . 'assets/css/plugin-style.min.css' );
        wp_enqueue_script('leiocpaypalscript', $this->plugin_url .'assets/js/plugin.min.js');
    }
}