<?php
/**
*@package leioc-event-paypal
*
*/

namespace LEIOCPaypal\Base;

use WP_List_Table;
use LEIOCPaypal\Base\BaseController;

/**
* 
*/
class EntriesWPListTable extends WP_List_Table
{
    private $wpdb;

    public $entries;

    public $events;

    public $entries_data;
    
    public $per_page = 40;

    public $page_name;

    public $count;

    public $all_count;

    public $pub_count;

    public $draft_count;

    public $status = 1;

    public $update_bulk;

    public $base;


    public function __construct() {

		parent::__construct( 
            array(
                'singular' => 'Entry', //singular name of the listed records
                'plural'   => 'Enties', //plural name of the listed records
                'ajax'     => true, //should this table support ajax?
            )
        );

        global $wpdb;
        $this->wpdb = $wpdb;

        $this->base = new BaseController;

        $this->entries = $this->base->entriesTable;

        $this->events = $this->base->eventTable;

        $this->page_name = isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];
    }
    
    public function get_data($id = null)
    {
        $this->process_bulk_action();

        if( isset( $_REQUEST['id']) && !isset($id) ) $id = $this->get_id_from_event_id( $_REQUEST['id'] );

        if($id == null)
            //Check if form_id exists
            $id = $this->wpdb->get_var( "SELECT id FROM {$this->events} WHERE form_date >= now() ORDER BY form_date DESC" );

        $orderby = isset($_REQUEST['orderby'] ) ? $_REQUEST['orderby'] : 'ent_course';
        $order = isset($_REQUEST['order']) ? $_REQUEST['order'] : 'asc';
        $this->status = isset($_REQUEST['status']) ? $_REQUEST['status'] : 1;

        $san_orderby = sanitize_sql_orderby($orderby . ' ' . $order);

        $page_num = isset( $this->update_bulk ) ? $this->update_bulk : $this->get_pagenum() ;
        $offset = ( $page_num * $this->per_page ) - $this->per_page;

        $wild = '%';
        $find = isset($_POST['s']) ? trim($_POST['s']) : '';
        $like = $wild . $this->wpdb->esc_like( $find ) . $wild;

        $sql  = $this->wpdb->prepare( "SELECT * FROM $this->entries WHERE event_id=%d AND ent_trash=%d AND ent_details LIKE %s ORDER BY $san_orderby LIMIT $offset, $this->per_page", $id, $this->status, $like);

        $this->count = $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->entries WHERE event_id=%d AND ent_trash=%d AND ent_details LIKE %s",$id, $this->status, $like) );

        $this->all_count = $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->entries WHERE event_id=%d AND ent_trash=%d",$id, $this->status) );

        $this->pub_count = $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->entries WHERE event_id=%d AND ent_trash=1",$id) );

        $this->draft_count = $this->wpdb->get_var( $this->wpdb->prepare("SELECT count(*) FROM $this->entries WHERE event_id=%d AND ent_trash=0",$id) );

        $this->entries_data = $this->unserialize( $this->wpdb->get_results( $sql , ARRAY_A ) );
    }

    public function unserialize($array){

        foreach($array as $num => $entry){

            $user = maybe_unserialize( $entry['leioc_user_details'] );
            foreach($user as $key => $value){
                $leioc[$key] = $value;   
            }
            $details = maybe_unserialize( $entry['ent_details'] );
            $details = !empty($details) ? $details : [];
            foreach($details as $key => $value){
                $entry[$key] = $value;   
            }
            $fees = maybe_unserialize( $entry['ent_fee_details'] );
            $fees = (!empty($fees) ? $fees : [] );
            foreach($fees as $key => $value){
                $entry[$key] = $value;
            }

            $array[$num] = array_merge($entry, $leioc);

            //Removes dulicates from array
            unset($array[$num]['leioc_user_details']);
            unset($array[$num]['ent_details']);
            unset($array[$num]['ent_fee_details']);
        }

        return $array;
    }

    public function get_columns()
    {   
        //First column after cb used on small screen
        $columns = array(
            'cb'         => '<input type="checkbox"/>',
            'name'  => 'Name',
            'club' => 'Club',
            'age_class' => 'Age Class',
            'si_num' => 'SI Num',
            'ent_course' => 'Course',
            'start_time' => 'Start Time',
            'action' => 'Action',
            'id'         => 'ID',
            'event_id'  => 'Event ID',
        );
        return $columns;
    }

    public function column_cb($item)
    {
        return sprintf('<input type="checkbox" name="post_cb[]" value="%d" />',$item['id']);
    }

    public function prepare_items()
    {
        $columns = $this->get_columns();
        $hidden = $this->get_hidden_columns();
        $sortable = $this->get_sortable_columns();

        $this->set_pagination_args(
            array(
                'total_items' => $this->count,
                'per_page' => $this->per_page,
                'total_pages'   => ceil( $this->count / $this->per_page ),
                'orderby'   => ! empty( $_REQUEST['orderby'] ) && '' != $_REQUEST['orderby'] ? $_REQUEST['orderby'] : 'ent_course',
                'order'     => ! empty( $_REQUEST['order'] ) && '' != $_REQUEST['order'] ? $_REQUEST['order'] : 'asc',
                'status'     => ! empty( $_REQUEST['status'] ) && '' != $_REQUEST['status'] ? $_REQUEST['status'] : 1,
            )
        );

        $this->_column_headers = array($columns, $hidden, $sortable);
        $this->items = $this->entries_data;
    }

    public function get_bulk_actions()
    {
        if( $this->status == 1) {
            $actions = array(
                'draft' => 'Move to Bin',
            );
        } else {
            $actions = array(
                'delete' => 'Delete',
                'publish' => 'Publish',
            );
        };

        return $actions;
    }

    public function get_hidden_columns()
    {
        return array('id','event_id');
    }

    public function get_sortable_columns()
    {
        return array( 
            'start_time' => array('ent_start', true),
            'ent_course' => array('ent_course', true),
        );
    }

    public function column_default( $item, $column_name )
    {
        switch( $column_name ) { 
            case 'id':
            case 'event_id':
            case 'name':
            case 'club':
            case 'age_class':
            case 'si_num':
            case 'ent_course':
                return $item[ $column_name ];
            case 'start_time':
                return $this->set_start_time( $item[$column_name] );
            case 'action':
                return $this->set_edit_btn( $item['id'] );
            default:
                return 'no value';
        }
    }

    public function set_start_time( $arg )
    {
        if( ! preg_match("/^(?:2[0-4]|[01][1-9]|10):([0-5][0-9])$/", $arg) ) return $arg;
        return date('H:i' , strtotime( $arg ) );
    }

    public function set_edit_btn($id)
    {
        return sprintf('<button type="button" class="edit button button-primary button-small" style="display: inline-block;" name="edit_post[]" value="%s" >EDIT</button>',$id);
    }

    public function process_bulk_action()
    {   

        $action = $this->current_action();
        
        $ids = isset($_POST['post_cb']) ? $_POST['post_cb'] : array();

        switch ( $action ) {

            case 'draft':
                if (!empty($ids)) {
                    $this->set_draft($ids);
                }
                return;
            case 'delete':
                if (!empty($ids)) {
                    $this->set_delete($ids);
                }
                return;
            case 'publish':
                if (!empty($ids)) {
                    $this->set_draft($ids, 1);
                }
                return;
            default:
                // do nothing or something else
                return;
        }

        return;
    }

    public function set_draft($ids, $trash = 0)
    {
        foreach($ids as $id){
            $this->wpdb->update($this->entries, array('ent_trash'=> $trash), array('id'=>$id));
        }
        return;
    }

    public function set_delete($ids)
    {
        $placeholders = implode( ', ', array_fill( 0, count( $ids), '%d' ) );
        $sql = $this->wpdb->prepare("DELETE FROM {$this->entries} WHERE id IN({$placeholders})", $ids);
        $this->wpdb->query($sql);

        $this->update_bulk = 1;

        return;
    }

    public function get_entry($id)
    {
        $sql = $this->wpdb->prepare("SELECT * FROM {$this->entries} WHERE id = %d", $id);
        $entry = array_pop( $this->unserialize( $this->wpdb->get_results($sql, ARRAY_A ) ) );

        return $entry;
    }

    public function get_all($id)
    {
        $sql = $this->wpdb->prepare("SELECT * FROM {$this->entries} WHERE event_id = %d", $id);
        $entries = $this->unserialize( $this->wpdb->get_results($sql, ARRAY_A ) );

        return $entries;
    }

    public function set_sub_menu()
    {
        $status = $this->status;

        $download = ($status == 1 && $this->all_count != 0 ? sprintf(' | <li class="download"><a href="#" id="exportCSV">Download All %s</a></li>', $this->add_span( $this->pub_count + $this->draft_count )) : '');

        return sprintf('<ul class="subsubsub"><li class="publish"><a href="%s&status=1" %s>Published %s</a></li> | <li class="draft"><a href="%s&status=0" %s>Draft %s </a></li>%s</ul>', $this->page_name, ($status == 1 ? 'class="current"' : '' ), $this->add_span( $this->pub_count ), $this->page_name, ($status == 0 ? 'class="current"' : '' ), $this->add_span( $this->draft_count ), $download );
    }

    public function add_span($count)
    {
        return sprintf('<span class="count">(%d)</span>', $count);
    }

    public function get_event_id_from_id($id)
    {
        return $this->wpdb->get_var( $this->wpdb->prepare( "SELECT form_id FROM {$this->events} WHERE id=%d", $id) );
    }

    public function get_id_from_event_id($id)
    {
        return $this->wpdb->get_var( $this->wpdb->prepare( "SELECT id FROM {$this->events} WHERE form_id=%d", $id) );
    }

    public function moveElement($arr , $from, $to )
    {
        $p1 = array_splice($arr, $from, 1);
        $p2 = array_splice($arr, 0, $to);
        $array = array_merge($p2,$p1,$arr);
        return $array;
    }

    public function export_CSV($id)
    {
        $data = $this->get_all($id);

        $option = get_option( 'leioc_paypal_delete_data');
		$use_phone = intval( isset($option['phone']) ? $option['phone'] : 1 );

        foreach($data as $num => $entry){

            //Converts ent_fee to user friendly name
            $data[$num]['fee_total'] = $data[$num]['ent_fee'];
            //Converts Deleted Column to user friendly
            $data[$num]['deleted_from_event'] = ($data[$num]['ent_trash'] == 1 ? 'No': 'Yes');
            //Convents id to event_id to make user friendly
            $data[$num]['event_id'] = $this->get_event_id_from_id( $data[$num]['event_id'] );
           
            //Removes Phone if Phone not collected
            if($use_phone != 1) unset($data[$num]['phone']);

            //Removes unwated data from array
            unset($data[$num]['leioc_user_id']);
            unset($data[$num]['ent_course']);
            unset($data[$num]['ent_start']);
            unset($data[$num]['payment_id']);
            unset($data[$num]['ent_trash']);
            unset($data[$num]['ent_fee']); 

            $keys = array_keys($data[$num]);

            //Moves Total Fees to after to Fees and Si Hire
            if( isset($data[$num]['fee_total']) ) $data[$num] = $this->moveElement($data[$num], array_search('fee_total', $keys), (array_search('si_hire', $keys) + 1) );
        };

        return $this->array_csv_download($data);
    }

    public function show_table()
    {   
        $this->get_data();

        echo '<form id="leioc-entries-list" method="post" name="leioc-entries-list" data-url="' . admin_url('admin-ajax.php') . '" action="' . $this->page_name . '">';
        echo '<div class="leioc-msg"><small class="field-msg js-database-submission">Accessing database, please wait&hellip;</small>
		<small class="field-msg error js-database-error">There was a problem connecting with the database, please try again!</small></div>';
        echo $this->set_sub_menu();
        
        $this->prepare_items();
        $this->search_box('Search Entries','leioc_search_entries_id');
        $this->display();
        
        echo '</form>';
    }

    public function ajax_response() {
  
        if (! DOING_AJAX || ! check_ajax_referer('leioc-entries-wp-nonce', 'nonce') ) {
			return $this->return_json('error');
        }

        //Returns data for entry to admin edit
        if(isset($_POST['edit_entry']) ) return $this->return_json('success', $this->get_entry($_POST['edit_entry']) );

        //Gets CSV download data
        if(isset($_POST['csv_entry']) )  {
            $this->export_CSV($_POST['csv_entry']);
            wp_die();
        }

        $id = sanitize_text_field($_POST['entries_event_id']);

        if( isset( $_REQUEST['action3'] ) ) $_REQUEST['action'] = $_REQUEST['action3'];

        get_pagenum_link(  $this->get_pagenum(), +1 );

        $this->get_data($id);
        $this->prepare_items();

        extract( $this->_args );
        extract( $this->_pagination_args, EXTR_SKIP );
       
        ob_start();
        if ( ! empty( $_REQUEST['no_placeholder'] ) )
            $this->display_rows();
        else
            $this->display_rows_or_placeholder();
        $rows = ob_get_clean();

        ob_start();
        $this->print_column_headers();
        $headers = ob_get_clean();

        ob_start();
        $this->pagination('top');
        $pagination_top = ob_get_clean();
    
        ob_start();
        $this->pagination('bottom');
        $pagination_bottom = ob_get_clean();

        ob_start();
        $this->search_box('Search Entries','leioc_search_entries_id');
        $search = ob_get_clean();

        ob_start();
        $this->bulk_actions('top');
        $bulk_actions_top = ob_get_clean();

        ob_start();
        $this->bulk_actions('bottom');
        $bulk_actions_bottom = ob_get_clean();

        $response = array( 'rows' => $rows );
        $response['pagination']['top'] = $pagination_top;
        $response['pagination']['bottom'] = $pagination_bottom;
        $response['column_headers'] = $headers;
        $response['count'] = esc_attr( $this->all_count );
        $response['one_page']  = esc_attr( $this->per_page > $this->all_count ? ($this->all_count == 0 ? 'one-page no-pages' : 'one-page' ) : '' );
        $response['sub_menu'] = $this->set_sub_menu();

        if ( isset( $total_items ) )
        $response['total_items_i18n'] = sprintf( _n( '1 item', '%s items', $total_items ), number_format_i18n( $total_items ) );
 
        if ( isset( $total_pages ) ) {
            $response['total_pages'] = $total_pages;
            $response['total_pages_i18n'] = number_format_i18n( $total_pages );
        }

        if ( isset( $search) ) $response['search'] = $search;
            
        if ( isset( $bulk_actions_top) ) $response['bulk_actions_top'] = $bulk_actions_top;
        if ( isset( $bulk_actions_bottom) ) $response['bulk_actions_bottom'] = $bulk_actions_bottom;
        
        if( isset($response) ) return $this->return_json('success', $response);

	    return $this->return_json('error');
    }

    public function return_json($status, $data = null)
	{
		$return = array(
			'status' => $status,
			'data' => $data,
		);
		wp_send_json($return);

		wp_die();
    }
    
    function array_csv_download( $array, $filename = "export.csv", $delimiter="," )
    {
        header( 'Content-Type: application/csv' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '";' );
        
        // clean output buffer
        ob_end_clean();
        
        $handle = fopen( 'php://output', 'w' );
        
        // use keys as column titles
        fputcsv( $handle, array_keys( $array['0'] ) );

        foreach ( $array as $value ) {
            fputcsv( $handle, $value , $delimiter );
        }

        fclose( $handle );

        // flush buffer
        ob_flush();

        // use exit to get rid of unexpected output afterward
        exit();
    }

    //Only needed with AJAX
    function display() {
 
        wp_nonce_field( 'leioc-entries-wp-nonce', 'nonce' );
        echo '<input id="order" type="hidden" name="order" value="' . $this->_pagination_args['order'] . '" />';
        echo '<input id="orderby" type="hidden" name="orderby" value="' . $this->_pagination_args['orderby'] . '" />';
        echo '<input id="status" type="hidden" name="status" value="' . $this->_pagination_args['status'] . '" />';
        echo '<input type="hidden" name="ajax_action" value="admin_entries_wp_list">';

        parent::display();
    }

    //Only needed with AJAX. Changes $_GET to $_REQUEST['order] and orderby
    public function print_column_headers( $with_id = true ) {
        list( $columns, $hidden, $sortable, $primary ) = $this->get_column_info();
     
        $request_uri =  isset($_REQUEST['_wp_http_referer']) ? $_REQUEST['_wp_http_referer'] : $_SERVER['REQUEST_URI'];

        $current_url = set_url_scheme( 'http://' . $_SERVER['HTTP_HOST'] . $request_uri );
        $current_url = remove_query_arg( 'paged', $current_url );
     
        if ( isset( $_REQUEST['orderby'] ) ) {
            $current_orderby = $_REQUEST['orderby'];
        } else {
            $current_orderby = '';
        }
     
        if ( isset( $_REQUEST['order'] ) && 'desc' === $_REQUEST['order'] ) {
            $current_order = 'desc';
        } else {
            $current_order = 'asc';
        }
     
        if ( ! empty( $columns['cb'] ) ) {
            static $cb_counter = 1;
            $columns['cb']     = '<label class="screen-reader-text" for="cb-select-all-' . $cb_counter . '">' . __( 'Select All' ) . '</label>'
                . '<input id="cb-select-all-' . $cb_counter . '" type="checkbox" />';
            $cb_counter++;
        }
     
        foreach ( $columns as $column_key => $column_display_name ) {
            $class = array( 'manage-column', "column-$column_key" );
     
            if ( in_array( $column_key, $hidden, true ) ) {
                $class[] = 'hidden';
            }
     
            if ( 'cb' === $column_key ) {
                $class[] = 'check-column';
            } elseif ( in_array( $column_key, array( 'posts', 'comments', 'links' ), true ) ) {
                $class[] = 'num';
            }
     
            if ( $column_key === $primary ) {
                $class[] = 'column-primary';
            }
     
            if ( isset( $sortable[ $column_key ] ) ) {
                list( $orderby, $desc_first ) = $sortable[ $column_key ];
     
                if ( $current_orderby === $orderby ) {
                    $order = 'asc' === $current_order ? 'desc' : 'asc';
     
                    $class[] = 'sorted';
                    $class[] = $current_order;
                } else {
                    $order = strtolower( $desc_first );
     
                    if ( ! in_array( $order, array( 'desc', 'asc' ), true ) ) {
                        $order = $desc_first ? 'desc' : 'asc';
                    }
     
                    $class[] = 'sortable';
                    $class[] = 'desc' === $order ? 'asc' : 'desc';
                }
     
                $column_display_name = sprintf(
                    '<a href="%s"><span>%s</span><span class="sorting-indicator"></span></a>',
                    esc_url( add_query_arg( compact( 'orderby', 'order' ), $current_url ) ),
                    $column_display_name
                );
            }
     
            $tag   = ( 'cb' === $column_key ) ? 'td' : 'th';
            $scope = ( 'th' === $tag ) ? 'scope="col"' : '';
            $id    = $with_id ? "id='$column_key'" : '';
     
            if ( ! empty( $class ) ) {
                $class = "class='" . implode( ' ', $class ) . "'";
            }
     
            echo "<$tag $scope $id $class>$column_display_name</$tag>";
        }
    }

    public function search_box( $text, $input_id ) {
        if ( empty( $_REQUEST['s'] ) && ! $this->has_items() ) {
            return;
        }
 
        $input_id = $input_id . '-search-input';
 
        if ( ! empty( $_REQUEST['post_mime_type'] ) ) {
            echo '<input type="hidden" name="post_mime_type" value="' . esc_attr( $_REQUEST['post_mime_type'] ) . '" />';
        }
        if ( ! empty( $_REQUEST['detached'] ) ) {
            echo '<input type="hidden" name="detached" value="' . esc_attr( $_REQUEST['detached'] ) . '" />';
        }
        ?>
        <p class="search-box">
            <label class="screen-reader-text" for="<?php echo esc_attr( $input_id ); ?>"><?php echo $text; ?>:</label>
            <input type="search" id="<?php echo esc_attr( $input_id ); ?>" name="s" value="<?php _admin_search_query(); ?>" />
                <?php submit_button( $text, '', '', false, array( 'id' => 'search-submit' ) ); ?>
        </p>
                <?php
    }
    
}
