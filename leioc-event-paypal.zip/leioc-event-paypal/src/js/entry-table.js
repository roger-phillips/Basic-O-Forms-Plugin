import formSubmit from './modules/formSubmit.js';
import modal from './modules/modal.js';
import modalButtons from './modules/modalButtons.js';

jQuery(document).ready(function ($) {

    $('.leioc-modal-open').on('click',function(){
        const modal = $( '#' + $(this).data('url') );
        modal.find('section, .prev, .field-msg, .success').hide();
        modal.find('section').eq(0).show();
        modal.modalButtons( modal.find('section:visible') );
        modal.find('.nxt').show();
    });

    $('.leioc-btn.nxt').on('click', function(){ leioc_next(1, $(this).closest('.leioc-modal').find('form')) });
    $('.leioc-btn.prev').on('click', function(){ leioc_next(-1, $(this).closest('.leioc-modal').find('form') ) });

    function leioc_next(i, form){
        const current_fs = form.find('section:visible'),
              section = (i == 1 ? current_fs.next('section') : current_fs.prev('section') );
        form.modalButtons(section);
    };

    //Resizes modal on screen change
    $( window ).resize(function(){
        const form = $('.leioc-modal-paypal');
        form.modalButtons( form.find('section:visible') );
    });
})