import formSubmit from './modules/formSubmit.js';
import entryFormSlide from './modules/entryFormSlide.js';