(function( $ ) {
 
    $.fn.formValidate = function(modal = false) {

		let data = $(this).serializeArray();
        let form = $(this);
        let check = true;

        // validate everything
        $.each(data, function(key, value) {
            let elm = $('[name="' + value.name +'"]'),
                val = value.value,
                err = form.find(elm).parent('div').find('.field-msg.error'),
                pattern = true;

            //Skips hidden inputs
            if( $(elm).css('display') == 'none' || $(elm).css("visibility") == "hidden" ) return true;

            if( !$(elm).prop('required') ) return true;

            if( val.match(/-- select/gi) ) val = '';

            //Checks input pattern matches
            if( $(elm).prop('pattern') ){
                let regex = new RegExp( $(elm).prop('pattern'), 'gi' );
                pattern = regex.test( String(val).toLowerCase() );
            }

            if( !val || pattern === false){
                err.show();
                if( modal === true) modalShow( err );
                check = false;
                return false;
            }
        });

        

        return check;
    }

    function modalShow(elem){
        const form = $(elem).closest('form');
        if (!form.parent().hasClass('leioc-modal-content')) return;
        form.modalButtons( form.find(elem).closest('section') );
        return;
    }

}( jQuery ));