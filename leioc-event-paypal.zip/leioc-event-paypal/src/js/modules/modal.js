jQuery(document).ready(function($){

	class TempScrollBox {
		constructor() {
		  this.scrollBarWidth = 0;
		  this.measureScrollbarWidth();
		}
		measureScrollbarWidth() {
		  // Add temporary box to wrapper
		  let scrollbox = document.createElement('div');
		  // Make box scrollable
		  scrollbox.style.overflow = 'scroll';
		  // Append box to document
		  document.body.appendChild(scrollbox);
		  // Measure inner width of box
		  this.scrollBarWidth = scrollbox.offsetWidth - scrollbox.clientWidth;
		  // Remove box
		  document.body.removeChild(scrollbox);
		}
		get width() {
		  return this.scrollBarWidth;
		}
	}

    //close pop-up when close button is clicked
	$('.leioc-modal').on('click', '.leioc-close', function() {
		fade(this);
	});

	$('.leioc-modal-open').on('click',function(e) {
		e.stopPropagation();
		modalOpen( $(this) );
	});

	const modalOpen = (e) => {
		let modal = '#' + $(e).data('url');
		$(modal).removeClass('fade').addClass('visible');
		$('body').css('overflow','hidden');

		//Checks if scrollbar is present
		if( document.body.scrollHeight > document.body.clientHeight ){
			let scrollbox = new TempScrollBox();
			$('body').css({'margin-right':scrollbox.width+'px'});
		}
	}
	
	const fade = (e) => {
		$(e).closest('.leioc-modal').removeClass('visible').addClass('fade');
		$('body').css({'margin-right':'0px'});
		$('body').css('overflow','scroll');
	}
});