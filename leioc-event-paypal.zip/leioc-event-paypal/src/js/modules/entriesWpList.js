import formValidate from './formValidate.js';

jQuery(document).ready(function($){

    entriesWpList();

    $('.leioc-entries-wrap').on('click','ul.leioc-nav-tabs > li', function(){
        $('.field-msg').hide();
    });

    function entriesWpList(){
        const wp_table = '#leioc-entries-list';

        $('#entries_event_id').on('change',function(){  
            $('.js-form-submission').show();
            //Clears Search box
            $('#leioc_search_entries_id-search-input').val('');

            ajaxWPList();
            //Adjusts Admin Entry Form on Change
            ajaxAdminEntry($(this));
        });

        $(wp_table).on('submit', function(e){
            e.preventDefault();
            ajaxWPList();
        });

        // Pagination links, sortable link
        $(wp_table).on('click', '.tablenav-pages a, .manage-column.sortable a, .manage-column.sorted a',function(e) {
            e.preventDefault();

            let str = this.search.substring( 1 ),
                order = query( str, 'order' ) || 'asc',
                orderby = query( str, 'orderby' ) || 'ent_course';

            $('input[name=order]').val( order );
            $('input[name=orderby]').val( orderby );

            addNum( $(this) );
            ajaxWPList();
        });

        //Publish & Draft links
        $(wp_table).on('click','li.publish a, li.draft a',function(e){
            e.preventDefault();

            let str = this.search.substring( 1 ),
                status = query( str, 'status' ) || 1;

            $('input[name=status]').val( status );

            addNum( $(this) );
            ajaxWPList();
        });

        $(wp_table).on('click','#search-submit', function(e){
            if( $(this).prev('input').val().length > 0 )
                $('#leioc-entries-list #current-page-selector').val(1);
        });
        //Individual Admin Entry Form
        $('#leioc-admin-entry').on('click', 'button[type="submit"]', function(e){
            e.preventDefault();
            ajaxEntryForm(this);
        });

        //Edit Entries 
        $(wp_table).on('click','button.edit',function(e){
            const id = $(this).val(),
                  form = '#' + $(this).closest('form').prop('id');
 
            let entry = getFormData(form) + '&edit_entry=' + id;

            $.ajax({
                type: "post",
                dataType: "json",
                url: $(form).data('url'),
                data: entry,
                success: function(response){
                    $(form + ' .field-msg').hide();
                    const data = response.data;

                    data['email'] = data['leioc_user_id'];
                    data['age'] = data['age_class'];
                    data['bof'] = data['bof_num'];
                    data['si'] = data['si_num'];

                    $.each(data, function(key,value){
                        $('input[name="' + key + '"').val(value);
                        $('select[name="' + key + '"').val(value);
                    });

                    $("ul.leioc-nav-tabs li.active").removeClass('active');
                    $(".tab-pane.active").removeClass('active');
                    $('a[href="#tab-2"]').parent('li').addClass('active');
                    $('#tab-2').addClass('active');
                    $('#tab-2').find('.field-msg').hide();
                },
                error: function(response){
                    resetMessages();
                }
            });
        });

        $('#leioc-admin-entry').on('click','.clear-form',function(e){
            resetForm(this);
        });

        //Download Entries as CSV File
        $(wp_table).on('click','#exportCSV',function(e){
            e.preventDefault();
            const form = '#' + $(this).closest('form').prop('id'),
                  event = $('#entries_event_id');

            let entry = getFormData(form) + '&csv_entry=' + event.val();

            $.ajax({
                type: "post",
                url: $(form).data('url'),
                data: entry,
                xhr: function () {
                    var xhr = new XMLHttpRequest();
                    xhr.onreadystatechange = function () {
                        if (xhr.readyState == 2) {
                            if (xhr.status == 200) {
                                xhr.responseType = "blob";
                            } else {
                                xhr.responseType = "text";
                            }
                        }
                    };
                    return xhr;
                },
                success: function(response){
                    resetMessages();

                    if (response === 0 || response.status === 'error') {
                        $('.leioc-entry-form .js-form-error').addClass('show');
                        return;
                    }
                    //Borrowed code from - https://www.aspsnippets.com/Articles/Download-File-in-AJAX-Response-Success-using-jQuery.aspx
                    //Convert the Byte Data to BLOB object.
                    var blob = new Blob([response], { type: "application/octetstream" });
                    let fileName = event.find(':selected').data('name') + '.csv';
                    let link = window.location.href; 

                    //Check the Browser type and download the File.
                    var isIE = false || !!document.documentMode;
                    if (isIE) {
                        window.navigator.msSaveBlob(blob, fileName);
                    } else {
                        var url = window.URL || window.webkitURL;
                        link = url.createObjectURL(blob);
                        var a = $("<a />");
                        a.attr("download", fileName);
                        a.attr("href", link);
                        $("body").append(a);
                        a[0].click();
                        $("body").remove(a);
                    }

                    $(form + ' .field-msg').hide();
                },
                error: function(response){
                    resetMessages();
                    $(form + ' .field-msg').hide();
                    $(form + ' .js-database-error').show();
                }
            });
        });
        //Upload CSV file
        $('#leioc-csv-form').on('submit',function(e){
            e.preventDefault();

            let file = $('#csv-file').val().trim(),
                form = $(this);
      
            if( file === '') return;
            
            form.find('.field-msg').hide();
            form.find('.js-database-submission').show();

            $.ajax({
                type: "post",
                url: $(this).data('url'),
                dataType: "json",
                data: new FormData(this),
                contentType: false,
                cache: false,
                processData:false,
                success: function(response){
                    form.find('.field-msg').hide();

                    if (response === 0 || response.status === 'error') {
                        form.find('.js-database-error').show();
                        return;
                    }
                    ajaxWPList();
                    form.trigger('reset');
                    form.find('.js-form-success').show();
                },
                error: function(response){
                    resetMessages();
                    form.find('.field-msg').hide();
                    form.find('.js-database-error').show();
                }
            });
        })

        //Ajax individual entry
        function ajaxEntryForm(ele){
            const form = $(ele).closest('form');
            
            form.find('.field-msg').hide();
		    if( !form.formValidate( true ) ) return;
            form.find('.js-form-submission').show();
  
            $.ajax({
                type: "post",
                dataType: "json",
                url: $(form).data('url'),
                data: $(form).serialize() + '&admin_entry=true',
                success: function(response){
                    form.find('.field-msg').hide();
                    //Resets error message
				    $('.js-form-error').text('There was a problem with the Entry Form, please try again!');

                    if (response === 0 || response.status === 'error') {
                        form.find('.js-form-error').show();
                        return;
                    }

                    if( response.status === 'error-time' ){
                        form.find('.js-form-error').text('Sorry, your choosen start time is not available!').show();
                        return;
                    }

                    ajaxWPList();
                    form.find('.js-form-success').show();
                    resetForm( form.find('[type="submit"]'), false );
                },
                error: function(response){
                    form.find('.field-msg').hide();
                    form.find('.js-form-error').show();
                }
            });
        };

        //Changes Entry Form to match WP_List_Table
        function ajaxAdminEntry(ele){
            const form = ele.closest('form');
            form.find('.field-msg').hide();

            $.ajax({
                type: "post",
                dataType: "json",
                url: $(form).data('url'),
                data: $(form).serialize(),
                success: function(response){
                    form.find('.field-msg').hide();
                    if(response.data.length) $('#leioc-admin-entry').html(response.data);
                },
                error: function(response){
                    form.find('.field-msg').hide();
                }
            });
        }

        //Gets WP_LIST_Table entries data
        function ajaxWPList(){
            const table = '#leioc-entries-list',
                  form = $(table);
            let wp_list = getFormData(table);

            $.ajax({
                type: "post",
                dataType: "json",
                url: form.data('url'),
                data: wp_list,
                success: function(response){
                    form.find('.field-msg').hide();
        
                    if (response === 0 || response.status === 'error') {
                        form.find('.js-database-error').show();
                        return;
                    }

                    // Add the requested rows
                    if ( response.data.rows.length )
                        form.find(' #the-list').html( response.data.rows );
                    // Update column headers for sorting
                    if ( response.data.column_headers.length )
                        form.find(' thead tr, tfoot tr').html( response.data.column_headers );
                    //Update pagination for navigation
                    if ( response.data.pagination.bottom.length )
                        form.find(' .tablenav.top .tablenav-pages').html( $(response.data.pagination.top).html() );
                    if ( response.data.pagination.top.length )
                        form.find(' .tablenav.bottom .tablenav-pages').html( $(response.data.pagination.bottom).html() );
                    //Sets pagination for one page
                    form.find(' .tablenav-pages').removeClass('one-page no-pages');
                    if ( response.data.one_page )
                        form.find(' .tablenav-pages').addClass(  response.data.one_page );
                    //Update Search box
                    form.find('.search-box').hide();
                    if ( response.data.count != 0 ){
                        if( !form.find('.search-box').length )
                            form.find('.subsubsub').after('<p class="search-box"></p>');
                        form.find('.search-box').show();
                        form.find('.search-box').replaceWith( response.data.search );
                    }
                    //Update bulk actions
                    form.find(' .alignleft.actions.bulkactions').hide();
                    if ( response.data.count != 0 ){
                        form.find('.tablenav.top .alignleft.actions.bulkactions').show();
                        if ( response.data.bulk_actions_top.length ){
                            let bulk = '<div class="alignleft actions bulkactions">' + response.data.bulk_actions_top + '</div>';
                            if( !form.find(' .alignleft.actions.bulkactions').length ){
                                form.find(' .tablenav.top').prepend(bulk);
                            } else {
                                form.find(' .tablenav.top .alignleft.actions.bulkactions').replaceWith(bulk);
                            }
                        }
                        if ( response.data.bulk_actions_bottom.length ){
                            let bulk = '<div class="alignleft actions bulkactions">' + response.data.bulk_actions_bottom + '</div>';
                            if( !form.find('.tablenav.bottom .alignleft.actions.bulkactions').length ){
                                form.find('.tablenav.bottom').prepend(bulk);
                            } else {
                                form.find('.tablenav.bottom .alignleft.actions.bulkactions').replaceWith(bulk);
                            }
                        }
                           
                    }
                    //Update Sub menu
                    if( response.data.sub_menu.length )
                        $('.subsubsub').replaceWith( response.data.sub_menu );
                },
                error: function(response){
                    form.find('.field-msg').hide();
                    form.find('.js-database-error').show();
                }
            });
        }

        function resetForm(e, msg = true){
            let hidden = ['id'];
            if(msg == true) $(e).closest('.tab-pane').find('.field-msg').hide();
            let form = $(e).closest('form');
            //Reset Hidden fields
            $.each(hidden, function(i, val){
                form.find('input[name="' + val + '"]').val('');
            })
            form.trigger('reset');  
        }

        function getFormData(form){
            const action = '&action=' + $(form + ' input[name=ajax_action').val();

            $(form + ' .field-msg').hide();
            $(form + ' .js-database-submission').show();
    
            let wp_list = $(form).serialize();
            let id = $('#entries_event_id').val();
            //Only required if bulk action is present
            let str = wp_list + "&action3=" + $('select[name=action]').val()  + '&entries_event_id=' + id;
            wp_list = (str.indexOf('&action') !== -1 ? str += action : str.replace(/&action=(.*?)&/gi,action+'&') );

            return wp_list;
        }

        //Corrects page number for Searches
        function addNum(e){
            let num = 1
            if($(e).prop('href').indexOf('paged=') != -1){
                const page = $(e).prop('href').split(/paged/gi)[1].replace(/[^0-9]/g,'');
                num = page;
            }
            $('#leioc-entries-list #current-page-selector').val(num);
            return;
        };

        function resetMessages() {
            document.querySelectorAll('.field-msg').forEach(f => f.classList.remove('show'));
        };

        //Gets query from URL
        function query( query, variable ) {
 
            var vars = query.split("&");
            for ( var i = 0; i <vars.length; i++ ) {
                var pair = vars[ i ].split("=");
                if ( pair[0] == variable )
                    return pair[1];
            }
            return false;
        }


    };
    
});


