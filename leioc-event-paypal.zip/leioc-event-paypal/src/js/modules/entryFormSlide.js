jQuery(document).ready(function ($) {

    let windowWidth = $(window).width(),
        slideCount = $('.leioc-o-form-slide').length;
	
    $('#leioc-next').on('click',function(e){
        var slideActive = $('.leioc-o-form-slide.active');
		var nextSlide = slideActive.next('.leioc-o-form-slide');

        slideActive.addClass('active').animate({
			'right' : windowWidth
		},500);

        if($('.leioc-o-form-slide').index(nextSlide) === -1){
            nextSlide = $('.leioc-o-form-slide').eq(0);
        }

        nextSlide.addClass('pre-active');		
    
        setTimeout(function(){
            slideActive.css({'right':'0px'});
            nextSlide.removeClass('pre-active');
            slideActive.removeClass('active');
            nextSlide.addClass('active');
        },510);
    });
	
});