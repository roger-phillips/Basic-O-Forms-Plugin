jQuery(document).ready(function($){

    $('.leioc-about-wrapper').on('click','#leioc_media_uploader',function(e){
        e.preventDefault();
        let image = wp.media({ 
            title: 'Upload Media',
            multiple: false
        }).open()
        .on('select', function(e){
            // This will return the selected image from the Media Uploader, the result is an object
            let uploaded_image = image.state().get('selection').first();
            // We convert uploaded_image to a JSON object to make accessing it easier
            let image_url = uploaded_image.toJSON().url;
            // Let's assign the url value to the input field
            $('#terms_url').val(image_url);
        });
    });

});