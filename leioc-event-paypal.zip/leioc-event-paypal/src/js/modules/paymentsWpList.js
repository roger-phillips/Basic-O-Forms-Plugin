import leiocWPListTable from './ajaxWPList.js';
import leiocModal from './modal-plugin.js';

jQuery(document).ready(function($){

    $('#leioc_payments_events').on('submit', function(e){
        e.preventDefault();
        if( $('select[name=action]').val() == 'invoice' || $('select[name=action2]').val() == 'invoice' ){
            $('input[name=invoice_event_id]').val( 
                $('#'+ $(this).prop('id') + ' input[name="post_cb[]"]:checked').map(function(e) {
                return $(this).val();
              }).get().join() 
            )
            $('#leioc-invoices-list').leiocWPListTable({
                form: '#leioc-invoices-list',
                orderby: 'event_id',
                submit: true,
            });
            $(this).leiocModal({
                modal: 'leioc-invoice-builder',
            });
            $('#leioc-invoice-builder').find('.tab-pane').removeClass('active');
            invoiceTab('#leioc-invoice-builder');
            return false;
        }
        return true;
    }).leiocWPListTable({
        form: '#leioc_payments_events',
        orderby: 'form_date',
    });

    //Saves email to be used with mail merge
    $('#leioc_invoice_email_builder').on('submit', function(e){
        e.preventDefault();

        let form = $(this);
        form.find('.field-msg').hide();
        form.find('.js-database-submission').show();
        
        $.ajax({
            type: "post",
            dataType: "json",
            url: form.data('url'),
            data: form.serialize(),
            success:function(result){
                form.find('.field-msg').hide();
                if( result.status == 'error'){
                    form.find('.js-database-error').show();
                } else {
                    form.find('.js-database-success').show();
                }
            },
            error:function(error){
                form.find('.field-msg').hide();
                form.find('.js-database-error').show();
            }
        });
    });
    //Adds Mail merge tags
    $('#leioc_invoice_email_builder #leioc-mail-merge-add-tags').on('click', function(){
        let txtToAdd = $('#leioc-mail-merge-tags').val();

        let $txt = $('textarea[name="email-message"]'),
            caretPos = $txt[0].selectionStart,
            textAreaTxt = $txt.val();

        $txt.val(textAreaTxt.substring(0, caretPos) + txtToAdd + textAreaTxt.substring(caretPos) );
    });

    //Ajax Mail Merge preview and email
    $('#leioc_invoice_email_merge').on('submit', function(e){
        e.preventDefault();
        let form = $(this),
            chk = [];
        $('#leioc-invoices-list').find('input:checked').each(function(){
            let val =  $(this).val();
            if( val == 'on' ) return;
            chk.push( val );
        });
        form.find('#entries-list').val( chk );

        form.find('.field-msg').hide();
        form.find('.js-database-submission').show();

        $('.leioc-invoices-sent, .leioc-invoices-not-sent').hide();

        let id = $(document.activeElement).prop('id'),
        emailMerge = (id == 'leioc-mail-merge-send' ? '&email=yes' : '');

        $.ajax({
            type: "post",
            dataType: "json",
            url: form.data('url'),
            data: form.serialize() + emailMerge,
            success:function(response){
                let display = '',
                    num = 1;
                form.find('.field-msg').hide();
                if( response.status == 'error'){
                    form.find('.js-database-error').show();
                } else {
                    $.each( response.data, function(key, value){
                        if( value.body == undefined ) return;
                        let address = '';
                        if( value.email != undefined ) address = value.email;
                        let email = '<div class="leioc-merge-email">Send to: ' + address + '</div>';
                        display += '<div class="leioc-merge-preview" data-num="'+ (num++) +'">' + email + value.body + '</div>';
                    });
                    $('.mail-merge-display').html( display );
                    $('.leioc-merge-preview:first, .leioc-invoice-count, .leioc-invoice-num').show();
                    $('.leioc-invoice-count span').text( response.data[0].count != undefined ? 0 : $(".mail-merge-display").children().length );
                    $('.leioc-invoice-num span').text( response.data[0].count != undefined ? 0 : 1);
                    if( emailMerge != ''){
                        $('.leioc-invoices-sent, .leioc-invoices-not-sent').show()
                        $('.leioc-invoices-sent span').text(response.data.sent);
                        $('.leioc-invoices-not-sent span').text(response.data.fail).show();
                    }
                }

            },
            error:function(response){
                $('.mail-merge-display').text('Sorry no data found.');
                form.find('.field-msg').hide();
                form.find('.js-database-error').show();
            }
        });
    });

    let index = 0;
    $('#leioc-mail-merge-prev, #leioc-mail-merge-nxt').on('click', function(e){ 
        let val = parseInt( $(this).val() ),
            divs = $(".mail-merge-display").children();
            index = (index + val) % divs.length;
            divs.eq(index).show().siblings().hide();
            $('.leioc-invoice-num span').text(index + 1);
    });

    //Shuffles tab-panes on invoice-builder
    $('.leioc-invoice-builder-nxt').on('click',function(e){
        invoiceTab(this);
    });

    const invoiceTab = (e) => {
        let modal = $(e).closest('.leioc-modal'),
            activeTab = modal.find('.tab-pane.active');
        if (activeTab.next('.tab-pane').length) {
            activeTab.removeClass('active').next('.tab-pane').addClass('active');
        } else {
            modal.find('.tab-pane').removeClass('active');
            modal.find('.tab-pane:first').addClass('active');
        }
    }

});