jQuery(document).ready(function($){

    eventsWpList();
    startBuilder();
    emailBuilder();
    feeBuilder();

    const fade = (e) => {
        $(e).closest('.leioc-modal').removeClass('visible').addClass('fade');
        $('body').css({'margin-right':'0px'});
        $('body').css('overflow','scroll');
    }

    $('.leioc-paypal-dashboard-wrap').on('click','ul.leioc-nav-tabs > li', function(){
        $('.field-msg').hide();
    });

    function emailBuilder()
    {
        $('#event_form_email_builder').on('click',function(){
            let subject = $('#event_form_subject').val(),
                message = $('#event_form_message').val(),
                from = $('#event_form_from').val(),
                reply= $('#event_form_reply').val();

            let type = 0;
            if( subject == 0 || message == 0 || subject == '' || message == '') {
                type = 1;
            } else{
                $('#leioc-subject').val( subject );
                $('textarea[name="email-message"]').val( message );
            };

            $('#leioc-from').val( from );
            $('#leioc-reply').val( reply );

            //Sets radio button to correct value
            $('input[name="email-type"][value="' + type + '"').prop('checked',true);
            changeBuildPane( '#'+ type +'-text', $('#leioc-email-builder') );
        });
        
        //Changes view on email builder
        $('input[name="email-type"]').on('change', function(){
            if ($(this).is(':checked'))
                changeBuildPane( '#'+$(this).data('id'), $(this).closest('.leioc-modal') );
        });
        //Saves Email Building settings
        $('#leioc-email-builder-save').on('click', function(){
            const type = $('input[name="email-type"]:checked').val();

            let subject = type == 1 ? 0 : $('#leioc-subject').val();
            let message = type == 1 ? 0 :$('textarea[name="email-message"]').val();

            $('#event_form_subject').val( subject );
            $('#event_form_message').val( message );
            $('#event_form_from').val( $('#leioc-from').val() );
            $('#event_form_reply').val( $('#leioc-reply').val() );
            fade( this );
        });

        $('#leioc-add-tags').on('click', function(){
            let txtToAdd = $('#leioc-mail-merge').val();

            let $txt = $('textarea[name="email-message"]'),
                caretPos = $txt[0].selectionStart,
                textAreaTxt = $txt.val();

            $txt.val(textAreaTxt.substring(0, caretPos) + txtToAdd + textAreaTxt.substring(caretPos) );
        });
    }

    function changeBuildPane(id, modal){
        //Changes Option Text
        modal.find('.leioc-start-text .leioc-text').removeClass('active');
        modal.find(id).addClass('active');
        //Changes Builder Pane
        modal.find('.builder-pane').removeClass('active');
        modal.find(id+'-builder').addClass('active');
    };

    function startBuilder(){
        $('#event_form_start_builder').on('click',function(){
            let data = $('#event_form_starts').val();
            
            data = data != '' ? JSON.parse( data.replace(/\\/gi, '') ) : '';
        
            if( data['type'] === undefined ) {
                data = {
                    'type':  0,
                    'times': '',
                }
            };
    
            //Sets radio button to correct value
            $('input[name="start-type"][value="' + data['type'] + '"').prop('checked',true);
            let pane = '#' + data['type'] + '-text-builder'
            $(pane + ' textarea').val( data['times'] );
    
            //Sets Time input boxes
            let arr = data['times'].split(','),
                last = arr[arr.length-1],
                num =  arr.length > 1 ? ( new Date("1970-1-1 "+  arr[1] ) - new Date("1970-1-1 "+ arr[0] ))/1000/60 : 1;
    
            $(pane + ' .start').val( $.trim(arr[0]) );
            $(pane + ' .end').val( (arr.length > 1 ? $.trim(last) : '') );
            $(pane + ' .num').val( $.trim(num) );
    
            changeBuildPane( '#'+data['type']+'-text', $('#leioc-start-times-builder') );
        });

        //Saves Start Builder Times form
        $('#leioc-start-builder-save').on('click',function(){
            const type = $('input[name="start-type"]:checked').val(),
                times = $('#'+type+'-text-builder').find('textarea[name="start-slots"]').val();

            let data = {
                type: type,
                times: $.trim(times),
            };

            $('#event_form_starts').val(JSON.stringify(data) );
            fade( this );
        });

        //Changes view on start builder
        $('input[name="start-type"]').on('change', function(){
            if ($(this).is(':checked'))
                changeBuildPane( '#'+$(this).data('id'), $(this).closest('.leioc-modal') );
        });

        //Adds start times to textarea
        $('#leioc-add-time').on('click', function(){
            let parent = $(this).closest('.leioc-add-time-bar'),
                start = parent.find('.start').val(),
                end = parent.find('.end').val(),
                num = parent.find('.num').val();

            let arr = [];

            if( start == '' || end == '' || num == '') {
                alert('These times are not valid!');
                return;
            };
            //Builds Times 
            while (start != end){
                arr.push( start);
                start = addMinutes(start, num);

                if( start > end ) break;
            }
            //Adds last time if less than num
            if( start <= end ) arr.push(end);

            parent.closest('.builder-pane').find('textarea').val( arr.join(', ') );

            function addMinutes(timeString, addMinutes) {
                if (!timeString.match(/^([0-9]|0[0-9]|1[0-9]|2[0-3]):[0-5][0-9]$/))
                    return null;
                var timeSplit = timeString.split(':');
                var hours = parseInt(timeSplit[0]);
                var minutes = parseInt(timeSplit[1]) + parseInt(addMinutes);
                hours += Math.floor(minutes / 60);
                while (hours >= 24) {
                    hours -= 24;
                }
                minutes = minutes % 60;
                return ('0' + hours).slice(-2) + ':' + ('0' +minutes).slice(-2);
            }
        });
    };

    function feeBuilder(){
        $('#event_form_fee_builder').on('click',function(){
            let data = $('#event_form_fee_details').val();
            const modal = $('#leioc-payapl-fee-builder');
            
            data = data != '' ? JSON.parse( data.replace(/\\/gi, '') ) : '';
        
            if( data['type'] === undefined ) {
                data = {
                    'type':  0,
                    'fee': 'Senior: 5.00, Junior: 3.50',
                    'si' : '',
                }
            };

            //Sets radio button to correct value
            $('input[name="fee-type"][value="' + data['type'] + '"').prop('checked',true);
            let pane = '#' + data['type'] + '-text-builder'
            $(modal).find('textarea[name="fee-slots"]').val( data['fee'] );
            $(modal).find('#si-hire-fee').val( data['si'] );

            changeBuildPane( '#'+ data['type'] +'-text', modal );
        });

        $('#leioc-paypal-fee-builder-save').on('click',function(e){
            const type = $('input[name="fee-type"]:checked').val(),
                  fee = $(this).closest('.leioc-modal').find('textarea[name="fee-slots"]').val(),
                  si = $(this).closest('.leioc-modal').find('#si-hire-fee').val();
                  
            let data = {
                type: type,
                fee: $.trim(fee),
                si: $.trim(si).replace(/[^0-9.]/g, ''),
            };

            $('#event_form_fee_details').val(JSON.stringify(data) );
            fade( this );
        });

        //Changes view on fee builder
        $('input[name="fee-type"]').on('change', function(){
            if ($(this).is(':checked'))
                changeBuildPane( '#'+$(this).data('id'), $(this).closest('.leioc-modal') );
        });
    }

    function eventsWpList(){
        const wp_table = '#leioc_search_event';

        //Event Form AJAX submit
        $('#leioc_paypal_event_settings').on('submit',function(e){
            e.preventDefault();
            const form = $(this);
            let elm = form.find(':invalid').first();
            form.find('.field-msg').hide();

            let check = true,
            data = $(form).serializeArray();

            // validate everything
            $.each(data, function(key, value) {
                let elm = $('[name="' + value.name +'"]');

                let hidden = ['event_form_starts', 'event_form_subject', 'event_form_message', 'event_form_fee_details']
                //Skips hidden inputs
                if( jQuery.inArray( value.name, hidden ) == -1 ) {
                    if( $(elm).css('display') == 'none' || $(elm).css("visibility") == "hidden" ) return true;
                }

                //Skip fields that are not required
                if( value.name == 'event_form_info') return true;
                //Corects error message to correct element
                if( value.name == 'event_form_starts') elm = $('#event_form_start_builder');
                if( value.name == 'event_form_subject' ||  value.name == 'event_form_message') elm = $('#event_form_email_builder');
                if( value.name == 'event_form_fee_details') elm = $('#event_form_fee_builder');

                if( ! value.value ){
                    let err = form.find(elm).closest('td').find('.field-msg.error');
                    err.show();
                    $('html, body').animate({ scrollTop: $(elm).offset().top - 50 }, 1000); 
                    check = false;
                    return false;
                }
            });

            if( check == false ) return;
            
            form.find('.js-form-submission').show();

            $.ajax({
                type: "post",
                dataType: "json",
                url: form.data('url'),
                data: $(form).serialize(),
                success: function(response){
                    form.find('.field-msg').hide();
                    
                    if (response === 0 || response.status === 'error') {
                        if( response.data.length ) form.find('.js-form-error').text( response.data );
                        form.find('.js-form-error').show();
                        return;
                    }

                    if( response.data.length ) form.find('.js-form-success').text( response.data );
                    form.find('.js-form-success').show();
                    ajaxWPList();
                    resetForm(form.find('[type="submit"]'), false);
                },
                error: function(response){
                    form.find('.js-form-success').text('There was a problem with the Event Form, please try again!');
                    form.find('.field-msg').hide();
                    form.find('.js-form-error').show();
                }
            });

        });

        //Sets published checkbox to Ajax
        $(wp_table).on('click','.publish',function(e){
            const id = $(this).data('publish-id');
            $('#publish_'+id).val( this.checked ? '1,'+id : '0,'+id );
            ajaxWPList();
        });

        //Ajax Edit Event data
        $(wp_table).on('click','button[name="edit_event[]"]',function(e){
            const id = $(this).val(),
                 form = $(wp_table),
                  entry = getFormData(wp_table) + '&edit_event=' + id;

                  $.ajax({
                    type: "post",
                    dataType: "json",
                    url: form.data('url'),
                    data: entry,
                    success: function(response){
                        $(wp_table + ' .field-msg').hide();
                        const data = response.data;
                        $.each(data, function(key,value){

                            //Sets Time & Date input values
                            let regexp = /([01][0-9]|[02][0-3]):[0-5][0-9]/;
                            if( regexp.test( value ) == true && key != 'form_starts'){
                                //Adds T to set Times
                                value = value.replace(' ','T');
                                //Removes time element for date 
                                if( key == 'form_date') value = value.split('T')[0];

                                $('input[name="event_' + key + '"').val( value )
                                return;
                            }
                            
                            $('input[name="event_' + key + '"').val(value);
                            $('select[name="event_' + key + '"').val(value);
                            $('textarea[name="event_' + key + '"').val(value);
                            
                            //Sets Checkboxs if database contains true or 1 value
                            if(value == false || value == true || value == 1 || value == 0){
                                value = ( value == true ? true : ( value == 1 ? true : false) );
                                $('input[name="event_' + key + '"').prop('checked', value);
                                return;
                            }
                        });
    
                        $("ul.leioc-nav-tabs li.active").removeClass('active');
                        $(".tab-pane.active").removeClass('active');
                        $('a[href="#tab-2"]').parent('li').addClass('active');
                        $('#tab-2').addClass('active');
                        $('.field-msg').hide();
                    },
                    error: function(response){
                        form.find('.field-msg').hide();
                        form.find('.js-database-error').show();
                    }
                });
        });

        //Ajax WP_list Table
        $(wp_table).on('submit', function(e){
            e.preventDefault();
            ajaxWPList();
        });

        // Pagination links, sortable link
        $(wp_table).on('click', '.tablenav-pages a, .manage-column.sortable a, .manage-column.sorted a',function(e) {
            // We don't want to actually follow these links
            e.preventDefault();

            let str = this.search.substring( 1 ),
                order = query( str, 'order' ) || 'desc',
                orderby = query( str, 'orderby' ) || 'form_date';

            $('input[name=order]').val( order );
            $('input[name=orderby]').val( orderby );

            addNum( $(this) );
            ajaxWPList();
        });

        //Publish & Draft links
        $(wp_table).on('click','li.publish a, li.draft a',function(e){
            e.preventDefault();

            let str = this.search.substring( 1 ),
                status = query( str, 'status' ) || 1;

            $('input[name=status]').val( status );

            addNum( $(this) );
            ajaxWPList();
        });

        $(wp_table).on('click','#search-submit', function(e){
            if( $(this).prev('input').val().length > 0 )
                $(wp_table + ' #current-page-selector').val(1);
        });

        //Gets WP_LIST_Table entries data
        function ajaxWPList(){
            const form = $(wp_table),
                  wp_list = getFormData(wp_table);

            $.ajax({
                type: "post",
                dataType: "json",
                url: form.data('url'),
                data: wp_list,
                success: function(response){
                    form.find('.field-msg').hide();
        
                    if (response === 0 || response.status === 'error') {
                        form.find('.js-database-error').show();
                        return;
                    }

                    // Add the requested rows
                    if ( response.data.rows.length )
                        form.find(' #the-list').html( response.data.rows );
                    // Update column headers for sorting
                    if ( response.data.column_headers.length )
                        form.find(' thead tr, tfoot tr').html( response.data.column_headers );
                    //Update pagination for navigation
                    if ( response.data.pagination.bottom.length )
                        form.find(' .tablenav.top .tablenav-pages').html( $(response.data.pagination.top).html() );
                    if ( response.data.pagination.top.length )
                        form.find(' .tablenav.bottom .tablenav-pages').html( $(response.data.pagination.bottom).html() );
                    //Sets pagination for one page
                    form.find(' .tablenav-pages').removeClass('one-page no-pages');
                    if ( response.data.one_page.length )
                        form.find(' .tablenav-pages').addClass( response.data.one_page );
                    //Update Search box
                    form.find('.search-box').hide();
                    if ( response.data.count != 0 ){
                        if( !form.find('.search-box').length )
                            form.find('.subsubsub').after('<p class="search-box"></p>');
                        form.find('.search-box').show();
                        form.find('.search-box').replaceWith( response.data.search );
                    }
                    //Update bulk actions
                    form.find(' .alignleft.actions.bulkactions').hide();
                    if ( response.data.count != 0 ){
                        form.find('.tablenav.top .alignleft.actions.bulkactions').show();
                        if ( response.data.bulk_actions_top.length ){
                            let bulk = '<div class="alignleft actions bulkactions">' + response.data.bulk_actions_top + '</div>';
                            if( !form.find(' .alignleft.actions.bulkactions').length ){
                                form.find(' .tablenav.top').prepend(bulk);
                            } else {
                                form.find(' .tablenav.top .alignleft.actions.bulkactions').replaceWith(bulk);
                            }
                        }
                        if ( response.data.bulk_actions_bottom.length ){
                            let bulk = '<div class="alignleft actions bulkactions">' + response.data.bulk_actions_bottom + '</div>';
                            if( !form.find('.tablenav.bottom .alignleft.actions.bulkactions').length ){
                                form.find('.tablenav.bottom').prepend(bulk);
                            } else {
                                form.find('.tablenav.bottom .alignleft.actions.bulkactions').replaceWith(bulk);
                            }
                        }
                           
                    }
                    //Update Sub menu
                    if( response.data.sub_menu.length )
                        $('.subsubsub').replaceWith( response.data.sub_menu );  
                },
                error: function(response){
                    form.find('.field-msg').hide();
                    form.find('.js-database-error').show();
                }
            });
        };

        $('#reset_event').on('click',function(e){
            resetForm(this);    
        });

        function resetForm(e, msg = true){
            let hidden = ['event_id', 'event_form_trash', 'event_form_starts', 'event_form_subject', 'event_form_message', 'event_form_from', 'event_form_reply','event_form_fee_details'];
            if( msg == true ) $(e).closest('.tab-pane').find('.field-msg').hide();
            let form = $(e).closest('form');
            //Reset Hidden fields
            $.each(hidden, function(i, val){
                form.find('input[name="' + val + '"]').val('');
            })
            form.trigger('reset');  
        }

        function getFormData(form){
            const action = '&action=' + $(form + ' input[name=ajax_action').val();

            $(form + ' .field-msg').hide();
            $(form + ' .js-database-submission').show();
    
            let wp_list = $(form).serialize();
            let str = wp_list + "&action3=" + $('select[name=action]').val();
            wp_list = (str.indexOf('&action') !== -1 ? str += action : str.replace(/&action=(.*?)&/gi,action+'&') );

            return wp_list;
        }

        //Corrects page number for Searches
        function addNum(e){
            let num = 1
            if($(e).prop('href').indexOf('paged=') != -1){
                const page = $(e).prop('href').split(/paged/gi)[1].replace(/[^0-9]/g,'');
                num = page;
            }
            $('#leioc_search_event #current-page-selector').val(num);
            return;
        };

        //Gets query from URL
        function query( query, variable ) {
 
            var vars = query.split("&");
            for ( var i = 0; i <vars.length; i++ ) {
                var pair = vars[ i ].split("=");
                if ( pair[0] == variable )
                    return pair[1];
            }
            return false;
        }
    }

});
