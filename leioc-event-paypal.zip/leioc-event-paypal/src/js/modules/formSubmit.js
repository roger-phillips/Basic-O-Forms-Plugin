import modalButtons from './modalButtons.js';
import formValidate from './formValidate.js';

jQuery(document).ready(function ($) {

	$('.leioc-entry-form').each(function(e){
		//Prevents Event Listerner being added twice
		if (typeof $(this).data('leioc-submit') === 'undefined') {
			$(this).data('leioc-submit', 'event_listner');
			$(this).on('click', 'button[type="submit"]',function(e) {
				e.preventDefault();
				submitForm(this);
			});
		  }
	});

	function submitForm(elem){
		const form = $(elem).closest('form'),
			  id = form.find('[name="event_id"]').val(),
			  entryTable = $('#leioc-' + id);

		form.find('.field-msg').hide();
		if( !form.formValidate( true ) ) return;
        form.find('.js-form-submission').show();

        $.ajax({
            type: "post",
            dataType: "json",
            url: form.data('url'),
            data: $(form).serialize(),
            success: function(response){
				form.find('.field-msg').hide();
				//Resets error message
				$('.js-form-error').text('There was a problem with the Entry Form, please try again!');

                if (response === 0 || response.status === 'error') {
                    form.find('.js-form-error').show();
                    return;
				}

				if( response.status === 'error-time' ){
					form.find('.js-form-error').text('Sorry, your choosen start time is no longer available!').show();
                    return;
				}

				if( response.status === 'error-max' ){
					form.find('.js-form-error').text('Sorry, the maximum number of competitors has been reached!').show();
                    return;
				}

				//Sets Entry Table
				entryTable.html( '<thead>' + response.data.header + '</thead>' + response.data.body );
				if( response.data.count ) entryTable.closest('.leioc-shortcode-table-wrapper').find('.leioc-count').text( 'Number of entries (' + response.data.count +')' );

				let starts = $('input[value="'+id+'"]');
				if( response.data.start ){
					$.each( starts, function(i, value){
						$(value).closest('form').find('.leioc-form-start').html( response.data.start );
					});
				}
				
				form.find('.js-form-success').show();
				form.trigger('reset');
            },
            error: function(response){
                    form.find('.field-msg').hide();
                    form.find('.js-form-error').show();
            }
        });
	
	}

	function modalShow(elem){
		const form = $(elem).closest('form');
		if (!form.parent().hasClass('leioc-modal-content')) return;
		form.modalButtons( form.find(elem).closest('section') );
		return;
	}
});