(function( $ ) {
 
    $.fn.modalButtons = function(section) {
        const modal = this.closest('.leioc-modal'),
              current_fs = modal.find('section:visible'),
              sections = modal.find('section');

        if(section.length != 0){
            current_fs.hide();
            section.show();
            section.closest('.leioc-modal-warpper').outerHeight( section.outerHeight() );
        }

        sections.each(function(i){
            if($(this).is(':visible') ) {
                modal.find('.prev, .nxt').show();
        
                modal.find('button[type=submit]').hide();
                if(i === 0) modal.find('.prev').hide();
        
                if( i === (sections.length - 1) ) {
                    modal.find('.nxt').hide();
                    modal.find('button[type=submit]').show();
                };
            }
        });

        return this;
    }

}( jQuery ));