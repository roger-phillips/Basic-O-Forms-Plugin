=== Basic Orienteering Entry Form ===
Contributors: Roger Phillips
Tags: Orienteering, Entry Form
Requires at least: 5.6.1
Tested up to: 5.7
Stable tag: 0.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.en.html

This plugin provides a basic orienteering entry form.

== Frequently Asked Questions ==
Entry Form Only
Add a basic entry form to any page. Use the shortcode leioc-entry-form with your form id.

[leioc-entry-form id="1234"]
The entry form has the option of setting a title via the shortcode. The title option will replace the title set on the plugin event dashboard.

[leioc-entry-form id="1234" title="Orienteering Event"]
Entry Form with Entry Table
Add a basic entry form to any page with an entry table. Use the shortcode leioc-entry-table with your form id.

[leioc-entry-table id="1234"]
The entry form with table has the option of setting a title via the shortcode. The title option will replace the title set on the plugin event dashboard.

[leioc-entry-table id="1234" title="Orienteering Event"]


Version 0.0.4
Subscribers roles can see Events and Entries Page
Administrator only can see settings page
