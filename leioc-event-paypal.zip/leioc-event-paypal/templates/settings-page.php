<div class="leioc-about-wrapper">

  <h1>Settings Page</h1>
  <?php settings_errors(); ?>

  <ul class="nav leioc-nav-tabs">
	<li class="active"><a href="#tab-1">Help</a></li>
	<li><a href="#tab-2">Settings</a></li>
  </ul>

  <div class="leioc-tab-content">

    <div id="tab-1" class="tab-pane active">

        <div>
          <h3>Entry Form Only</h3>
          <p>Add a basic entry form to any page. Use the shortcode leioc-entry-form with your form id.</p>
          <code class="leioc-shortcode">[leioc-entry-form id="1234"]</code>
          <p>The entry form has the option of setting a title via the shortcode. The title option will replace the title set on the plugin event dashboard.</p>
          <code class="leioc-shortcode">[leioc-entry-form id="1234" title="Orienteering Event"]</code>
        </div>

        <div>
          <h3>Entry Form with Entry Table</h3>
          <p>Add a basic entry form to any page with an entry table. Use the shortcode leioc-entry-table with your form id.</p>
          <code class="leioc-shortcode">[leioc-entry-table id="1234"]</code>
          <p>The entry form with table has the option of setting a title via the shortcode. The title option will replace the title set on the plugin event dashboard.</p>
          <code class="leioc-shortcode">[leioc-entry-table id="1234" title="Orienteering Event"]</code>
        </div>

    </div>
      
    <div id="tab-2" class="tab-pane">

        <form method="post" action="options.php" id="leioc_plugin_about_settings">
          <?php
            settings_fields( 'leioc_plugin_about_settings' );
            do_settings_sections( 'leioc_settings' );
            submit_button('Save Settings','primary','save_settings');
          ?>
        </form>

    </div>

  </div>

</div>