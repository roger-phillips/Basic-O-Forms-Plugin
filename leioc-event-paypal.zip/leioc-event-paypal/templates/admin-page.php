<?php
use LEIOCPaypal\Base\EventWPListTable;
$eventTable = new EventWPListTable;
?>
<div class="leioc-paypal-dashboard-wrap">

    <h1>Event Manager Dashboard</h1>
    <?php settings_errors(); ?>
    
    <ul class="nav leioc-nav-tabs">
		<li class="active"><a href="#tab-1">Manage Forms</a></li>
		<li><a href="#tab-2">Add Entry Form</a></li>
		<li><a href="#tab-3">Default Settings</a></li>
    </ul>
    
    <div class="leioc-tab-content">
		<div id="tab-1" class="tab-pane active">
            <h3>Entry Forms</h3>
            <div id="leioc-event-table">
                <?php $eventTable->show_table();?>
            </div>
        </div>

		<div id="tab-2" class="tab-pane">
            <form method="post" action="#" id="leioc_paypal_event_settings" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
                <?php 
                    do_settings_sections( 'leioc_paypal_form_settings' );
                ?>
                <div class="leioc-btn-group">
                    <div class="leioc-submit"></div><button type="submit" name="save_event" id="save_event" class="button button-primary">Save Event</button>
                    <button type="button" value="reset" id="reset_event" class="button button-secondary">Reset Form</button>
                    <span class="field-msg js-form-submission">Submission in process, please wait&hellip;</span>
                    <span class="field-msg success js-form-success">Event successfully submitted, thank you!</span>
                    <span class="field-msg error js-form-error">There was a problem with the Event Form, please try again!</span>
                    <input type="hidden" name="action" value="leioc_dashboard_form_submit">
                    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce("leioc-dashboard-form-nonce") ?>">
                </div>
            </form>
        </div>

		<div id="tab-3" class="tab-pane">
            <form method="post" action="options.php" id="leioc_paypal_default_settings">
                <?php 
                    settings_fields( 'leioc_paypal_ent_form_settings' );
                    do_settings_sections( 'leioc_paypal_default_form_settings' );
                    submit_button('','primary','save_default');
                ?>
            </form>
        </div>

    </div>
    
    <?php require_once($this->plugin_path.'templates/start-builder.php'); ?>
    <?php require_once($this->plugin_path.'templates/email-builder.php'); ?>
    <?php require_once($this->plugin_path.'templates/fee-builder.php'); ?>

</div>
