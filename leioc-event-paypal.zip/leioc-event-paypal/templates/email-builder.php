<?php 
use LEIOCPaypal\Base\FormController;
$form = new FormController;
?>

<div class="leioc-modal" id="leioc-email-builder">

    <div class="leioc-modal-dialog">
        <div class="leioc-modal-content">

            <div class="leioc-modal-header">
                <h3>Email Builder</h3>
                <button type="button" class="leioc-close" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>

            <div class="leioc-modal-body">

                <div id="leioc-email-options">

                    <div class="leioc-form-check">
                        <input type="radio" id="0-email" name="email-type" value="0" data-id="0-text" checked aria-label="Send email">
                        <label for="0-email">Send Email</label><br>
                    </div>
                    <div class="leioc-form-check">
                        <input type="radio" id="1-email" name="email-type" value="1" data-id="1-text" aria-label="No email sent">
                        <label for="1-email">No Email Sent</label><br>
                    </div>

                    <div class="leioc-start-text">
                        <div class="leioc-text active" id="0-text">Email will be sent automatically on a successfull entry.</div>
                        <div class="leioc-text" id="1-text">No email will be sent automatically.</div>
                    </div>

                    <div id="leioc-start-builder">

                        <div class="builder-pane active" id="0-text-builder">

                            <div class="leioc-form-group">
                                <label for="leioc-subject">Email Subject</label>
                                <input type="text" id="leioc-subject" name="subject" aria-label="subject">
                            </div>

                            <hr>

                            <div class="leioc-add-tag-bar">
                                <div class="leioc-form-group">
                                    <label for="leioc-mail-merge">Add Mail Merge Tag</label>
                                    <select id="leioc-mail-merge" name="mail-merge" aria-label="Mail merge tag add">
                                        <?php echo $form->set_merge_tags(); ?>
                                    </select>
                                </div>
                                <button type="button" class="button button-secondary" id="leioc-add-tags">Add</button>
                            </div>

                            <hr>

                            <div class="leioc-textarea">
                                <label>Email Message</label>
                                <textarea name="email-message">Thank you for entering this event.</textarea>
                            </div>
                            <div class="leioc-note">Use the mail merge tags to personalise your email.</div>

                            <hr>

                            <div class="leioc-add-attachment">
                                <div class="leioc-form-group">
                                    <label for="leioc-mail-attach-files">Attach File</label>
                                    <input type="text" id="leioc-mail-attach-files" name="files" aria-label="attach file to email">
                                </div>
                                <button type="button" class="button button-secondary" id="leioc-add-email-files">Attach</button>
                            </div>
                            <div class="leioc-note">Choose a file to send on entry to the event.</div>

                            <hr>

                            <div class="leioc-form-group">
                                <label for="leioc-from">Email From</label>
                                <input type="text" id="leioc-from" placeholder="e.g. Joe Bloggs" name="from" aria-label="from">
                            </div>

                            <div class="leioc-form-group">
                                <label for="leioc-reply">Reply Email Address</label>
                                <input type="text" id="leioc-reply" placeholder="e.g. reply@site.co.uk" name="reply" aria-label="reply">
                            </div>

                        </div>

                        <div class="builder-pane leioc-center" id="1-text-builder">No Emails to Send</div>

                    </div>

                </div>
                    
            </div>

            <div class="leioc-modal-footer">
                <div>
                    <button type="button" id="leioc-email-builder-save" class="button button-primary">Save Email</button>
                </div>
            </div>

        </div>
    </div>

</div>