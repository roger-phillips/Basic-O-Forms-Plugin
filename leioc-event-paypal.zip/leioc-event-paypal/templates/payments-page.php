<?php
use LEIOCPaypal\Base\PaymentsWPListTable;
use LEIOCPaypal\Base\InvoicesWPListTable;

$paymentTable = new PaymentsWPListTable;
$invoiceTable = new InvoicesWPListTable;

//Sets Email options
$options = get_option('leioc_paypal_invoice_email');
$email = isset($options['email-message']) ? $options['email-message']: 'Please pay the event fee listed below

*|invoice|*';
$from = isset($options['from']) ? $options['from'] : '';
$reply = isset($options['reply']) ? $options['reply'] : '';
$subject = isset($options['subject']) ? $options['subject'] : '';
?>
<div class="leioc-payments-wrapper">
    <h1>Payments Dashboard</h1>
    <ul class="nav leioc-nav-tabs">
		<li class="active"><a href="#tab-1">Events</a></li>
        <li><a href="#tab-2">Email Settings</a></li>
    </ul>

    <div class="leioc-tab-content">
        <div id="tab-1" class="tab-pane active">
            <?php $paymentTable->show_table() ; ?>
        </div>

        <div id="tab-2" class="tab-pane">
            <?php settings_errors(); ?>
            <form method="post" id="leioc_invoice_email_builder" name="leioc_invoice_email_builder" data-url="<?php echo admin_url('admin-ajax.php') ?>" action="#">
                <h3>Invoice Email Settings</h3>
                <div class="leioc-form-group">
                    <label for="leioc-subject">Email Subject</label>
                    <input type="text" id="leioc-subject" name="subject" aria-label="subject" value="<?php echo $subject; ?> ">
                </div>

                <hr>
                <div class="leioc-add-tag-bar">
                    <div class="leioc-form-group">
                        <label for="leioc-mail-merge-tags">Add Mail Merge Tag</label>
                        <select id="leioc-mail-merge-tags" aria-label="add mail merge tag to email body">
                            <?php echo $invoiceTable->set_tags(); ?>
                        </select>
                    </div>
                    <button type="button" class="button button-secondary" id="leioc-mail-merge-add-tags">Add</button>
                </div>

                <hr>
                <div class="leioc-textarea leioc-form-group">
                    <label>Email Message</label>
                    <textarea name="email-message"><?php echo $email; ?></textarea>
                </div>
                <div class="leioc-note">Use the mail merge tags to personalise your email.</div>

                <hr>
                <div class="leioc-form-group">
                    <label for="leioc-from">Email From</label>
                    <input type="text" id="leioc-from" placeholder="e.g. Joe Bloggs" name="from" aria-label="from" value="<?php echo $from; ?>">
                </div>

                <div class="leioc-form-group">
                    <label for="leioc-reply">Reply Email Address</label>
                    <input type="text" id="leioc-reply" placeholder="e.g. reply@site.co.uk" name="reply" aria-label="reply" value="<?php echo $reply; ?>">
                </div>
                
                <input type="hidden" name="action" value="leioc_email_invoices_settings">
                
                <?php wp_nonce_field( 'leioc-payments-wp-nonce', 'nonce' ); ?>
                <?php submit_button('Save Settings','primary','save_default'); ?>

                <div class="leioc-msg">
                    <span class="field-msg js-database-submission">Accessing database, please wait&hellip;</span>
                    <span class="field-msg error js-database-error">There was a problem connecting with the database, please try again!</span>
                    <span class="field-msg success js-database-success">Email settings successfully saved</span>
                </div>
            </form>
        </div>
    </div>

    <?php require_once($this->plugin_path.'templates/invoice-builder.php'); ?>
</div>