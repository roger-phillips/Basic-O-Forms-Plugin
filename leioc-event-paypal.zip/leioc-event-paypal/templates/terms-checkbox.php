<?php
    $option = get_option( 'leioc_paypal_delete_data');

    $text = isset($option['terms_text']) ? trim($option['terms_text']) : '';
    $text =  !empty($text)? $text : 'I agree to the terms and conditions of entry';

    $note = isset($option['terms_note']) ? trim($option['terms_note']) : '';
    $note = !empty($note)? $note :'Terms and conditions.';

    $link = isset($option['terms_url']) ? trim($option['terms_url']) : '';
    $link = !empty($link)? $link : site_url();

    $terms = isset($option['terms']) ?: '';
?>
<?php if( !empty($terms)): ?>
<section>
    <div class="leioc-form-row">
        <div class="leioc-form-check">
            <div>
                <input type="checkbox" value="Yes" id="leioc-terms-conditions" name="terms_checked" aria-label="Accept terms and conditions" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
                <label class="required" for="leioc-terms-conditions"><?php echo esc_attr__($text); ?></label>
                <div id="termsHelpBlock" class="leioc-form-text"><a href="<?php echo esc_url($link); ?>" target="_blank"><?php echo esc_attr__($note); ?></a></div>
                <span class="field-msg error" data-error="invalidTerm">Please select the checkbox</span>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>