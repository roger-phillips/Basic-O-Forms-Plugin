<div class="leioc-shortcode-table-wrapper">
    <div class="leioc-title-bar">
        <h3><?php echo $title; ?></h3>
        <div><?php echo $date; ?></div>
    </div>

    <div>
        <?php echo isset($closed) ? '<p class="leioc-important">' . $closed . '</p>' : ''?>
    </div>

    <div class="<?php echo isset($closed) ? 'leioc-hidden' : ''?>">
        <div class="leioc-modal-open" data-target="leioc-modal-<?php echo $eventID; ?>">
            <span><?php echo $link?></span>
            <button type="button" class="leioc-modal-open leioc-btn-enter" data-url="leioc-modal-<?php echo $eventID; ?>">Enter</button>
        </div>
    </div>

    <?php if( isset($info) ):?>
        <div class="leioc-about-event"><div class="leioc-form-row"><p>
        <?php echo $info; ?>
        </p></div></div>
    <?php endif; ?>

    <div class="leioc-count">Number of entries (<?php echo $count; ?>)</div>

    <div class="leioc-table-responsive">
        <table class="leioc-paypal-table" id="leioc-<?php echo $eventID; ?>">
            <thead>
                <?php echo $headers; ?>
            </thead>
                <?php echo $tableRows; ?>
        </table>
    </div>

    <div class="leioc-modal-paypal leioc-modal" id="leioc-modal-<?php echo $eventID; ?>">
        <div class="leioc-modal-dialog">
            <div class="leioc-modal-content">
                <div class="leioc-modal-header">
                    <h4><?php echo isset($title) ? $title :''; ?></h4>
                    <button type="button" class="leioc-close" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>

                <form class="leioc-entry-form" action="#" method="post" data-url="<?php echo admin_url('admin-ajax.php') ?>">
                <div class="leioc-modal-body">
                    <?php if( isset($info) ):?>
                        <div class="leioc-about-event"><div class="leioc-form-row"><p>
                        <?php echo $info; ?>
                        </p></div></div>
                    <?php endif; ?>
                    <?php require($this->plugin_path.'templates/form.php'); ?>
                </div>

                <div class="leioc-modal-footer">
                    <div class="leioc-msg">
                        <span class="field-msg js-form-submission">Submission in process, please wait&hellip;</span>
                        <span class="field-msg success js-form-success">Entry successfully submitted, thank you!</span>
                        <span class="field-msg error js-form-error">There was a problem with the Entry Form, please try again!</span>
                    </div>
                    <div class="leioc-btn-group">
                        <button type="button" class="leioc-btn prev" <?php echo isset($disabled) ? 'disabled': ''; ?>>Previous</button>
                        <button type="button" class="leioc-btn nxt" <?php echo isset($disabled) ? 'disabled': ''; ?>>Next</button>
                        <button type="submit" class="button-primary leioc-btn success" <?php echo isset($disabled) ? 'disabled': ''; ?>>Submit</button>
                    </div>
                </div>

                </form>
            </div>
        </div>
    </div>
</div>