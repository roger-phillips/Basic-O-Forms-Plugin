<div class="leioc-modal" id="leioc-start-times-builder">
    <div class="leioc-modal-dialog">
        <div class="leioc-modal-content">

            <div class="leioc-modal-header">
                <h3>Start Time Builder</h3>
                <button type="button" class="leioc-close" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>

            <div class="leioc-modal-body">

                <div id="leioc-start-options">

                    <div class="leioc-form-check">
                        <input type="radio" id="0-start" name="start-type" value="0" data-id="0-text" checked aria-label="No starts">
                        <label for="0-start">No Starts</label><br>
                    </div>

                    <div class="leioc-form-check">
                        <input type="radio" id="1-start" name="start-type" value="1" data-id="1-text" aria-label="1 start only">
                        <label for="1-start">1 Start Only</label><br>
                    </div>

                    <div class="leioc-form-check">
                        <input type="radio" id="2-start" name="start-type" value="2" data-id="2-text" aria-label="Start block preference">
                        <label for="1-start">Start Block Preference</label><br>
                    </div>

                    <div class="leioc-start-text">
                        
                        <div class="leioc-text active" id="0-text">
                            No start times available for competitor to select.
                        </div>
                        <div class="leioc-text" id="1-text">
                            1 start time available for each competitor.
                        </div>
                        <div class="leioc-text" id="2-text">
                            Competitor's choose their start block preference.
                        </div>

                    </div>

                    <div id="leioc-start-builder">

                        <div class="builder-pane leioc-center active" id="0-text-builder">
                            No Options Avialable
                        </div>

                        <div class="builder-pane" id="1-text-builder">

                            <div class="leioc-add-time-bar">
                                <div>
                                    <input id="start" class="start" type="time" id="1-start-time" value="10:30" aria-label="Starts begining times">
                                    <label for="start" >to</label>
                                    <input class="end" type="time" aria-label="Starts end time">
                                </div>
                                <div>
                                    <input id="num" class="num" type="number" min="1" max="15" value="1" aria-label="Minute intervals">
                                    <label for="num">minute interval</label>
                                    <button type="button" class="button button-secondary" id="leioc-add-time">Add</button>
                                </div>
                            </div>

                            <div class="leioc-textarea">
                                <label for="start-slots-times">Start Times Available</label>
                                <textarea id="start-slots-times" name="start-slots" aria-label="Start times avialable"></textarea>
                            </div>
                            <div class="leioc-note">
                                Add all avaialble start times should be seperated by a comma. e.g. 10:30, 10:31, 10:32
                            </div>
                        </div>

                        <div class="builder-pane" id="2-text-builder">
                            <div class="leioc-textarea">
                                <label for="start-slots-blocks">Available Blocks</label>
                                <textarea id="start-slots-blocks" name="start-slots" aria-label="Available start blocks">Very Early, Early, Middle, Late, Very Late</textarea>
                            </div>
                            <div class="leioc-note">
                                Add all avaialble start blocks should be seperated by a coma. e.g. Early, Middle, Late
                            </div>
                        </div>

                    </div>
                    
                </div>
                    
            </div>

            <div class="leioc-modal-footer">
                <div>
                    <button type="button" id="leioc-start-builder-save" class="button button-primary">Save Times</button>
                </div>
            </div>

        </div>
    </div>

</div>