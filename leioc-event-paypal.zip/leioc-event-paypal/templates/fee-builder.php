<div class="leioc-modal" id="leioc-paypal-fee-builder">

    <div class="leioc-modal-dialog">
        <div class="leioc-modal-content">

            <div class="leioc-modal-header">
                <h3>Event Fee Builder</h3>
                <button type="button" class="leioc-close" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>

            <div class="leioc-modal-body">

                <div id="leioc-fee-options">

                    <div class="leioc-form-check">
                        <input type="radio" id="0-fee" name="fee-type" value="0" data-id="0-text" checked aria-label="No Fees">
                        <label for="0-start">No Fees</label><br>
                    </div>
                    <div class="leioc-form-check">
                        <input type="radio" id="1-fee" name="fee-type" value="1" data-id="1-text" aria-label="Event Fees">
                        <label for="1-start">Event Fees</label><br>
                    </div>

                    <div class="leioc-start-text">
                        <div class="leioc-text active" id="0-text">
                            No fees available for competitor to select.
                        </div>
                        <div class="leioc-text" id="1-text">
                            Fees available for each competitor.
                        </div>
                    </div>

                    <div id="leioc-start-builder">

                        <div class="builder-pane leioc-center active" id="0-text-builder">
                            No Options Avialable
                        </div>

                        <div class="builder-pane" id="1-text-builder">

                            <div class="leioc-textarea">
                                <label for="event-fees-options">Fee Options Available</label>
                                <textarea name="fee-slots" id="event-fees-options" aria-label="Event Fees">Senior: 5.00, Junior: 3.50</textarea>
                            </div>
                            <div class="leioc-note">
                                Add a fee type and price, seperated by colon(:). Use a comma when starting a new fee type.
                                e.g. Senior: 5.00, Junior: 3.50
                            </div>

                            <hr>

                            <div class="leioc-form-group">
                                <label for="si-hire-fee">Si Hire Fee</label>
                                <input type="text" id="si-hire-fee" aria-label="Si hire fee">
                            </div>
                            <div class="leioc-note">
                                Leave blank if Si hire fee is free.
                            </div>
                        </div>

                </div>
                    
            </div>

            <div class="leioc-modal-footer">
                <div>
                    <button type="button" id="leioc-paypal-fee-builder-save" class="button button-primary">Save Fees</button>
                </div>
            </div>

        </div>
    </div>

</div>