<?php

use \LEIOCPaypal\Base\FormController;
use LEIOCPaypal\Base\EntriesWPListTable;

$entriesTable = new EntriesWPListTable;
$form = new FormController;

?>
<div class="leioc-entries-wrap">
	<h1> Entries Dashboard </h1>
	<?php settings_errors(); ?>

	<ul class="nav leioc-nav-tabs">
		<li class="active"><a href="#tab-1">Manage Entries</a></li>
		<li><a href="#tab-2">Manage Entry</a></li>
		<li><a href="#tab-3">Upload</a></li>
    </ul>

	<div class="leioc-tab-content">
		<div id="tab-1" class="tab-pane active">
			<div class="leioc-dashboard">
				<form method="post" action="#" id="leioc_entries_selection" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
					<?php 
						do_settings_sections( 'leioc_entries' );
					?>
					<input type="hidden" name="action" value="leioc_admin_entry_submit">
					<input type="hidden" name="nonce" value="<?php echo wp_create_nonce("leioc-entries-wp-nonce") ?>">
				</form>
				<?php $entriesTable->show_table(); ?>
			</div>
        </div>

		<div id="tab-2" class="tab-pane">
			<h3>Manage Individual Entry</h3>
			<br>
			<div class="leioc-dashboard">
				<form id="leioc-admin-entry" class="leioc-entry-form" action="#" method="post" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
					<?php echo $form->get_admin_form(); ?>
				</form>
			</div>
		</div>
		
		<div id="tab-3" class="tab-pane">
			<h3>Upload CSV File</h3>
			<br>
			<div class="leioc-dashboard">
				<form id="leioc-csv-form" action="#" method="post" data-url="<?php echo admin_url('admin-ajax.php'); ?>">
					<div>	
						<div class="leioc-msg">
							<label for="csv-file">CSV File Upload</label>
							<input type="file" id="csv-file" name="csv_file">
							<small class="field-msg js-database-submission">Uploading file, please wait&hellip;</small>
							<small class="field-msg success js-form-success">File successfully uploaded, thank you!</small>
							<small class="field-msg error js-database-error">There was a problem uploading the file, please try again!</small>
						
						</div>

						<div class="leioc-msg">
							<button type="submit" class="button button-primary">Upload</button>
						</div>
					</div>

					<input type="hidden" name="action" value="leioc_entry_form_submit">
					<input type="hidden" name="nonce" value="<?php echo wp_create_nonce("leioc-entry-form-nonce") ?>">
					<h4><bold>Tips for a successful upload</bold></h4>

					<ul class="leioc-note">
						<li>Each entry must have a valid id.</li>
						<li>Files must be in a valid CSV format.</li>
					</ul>

				</form>
			</div>
        </div>

	</div>

</div>