<?php
use LEIOCPaypal\Base\InvoicesWPListTable;
$invoiceTable = new InvoicesWPListTable;
?>
<div class="leioc-modal" id="leioc-invoice-builder">
    <div class="leioc-modal-dialog">
        <div class="leioc-modal-content">
            <div class="leioc-modal-header">
                <h3>Invoice Builder</h3>
                <button type="button" class="leioc-close" aria-label="Close"><span aria-hidden="true">×</span></button>
            </div>

            <div class="leioc-modal-body">
                <div class="leioc-invoice-btn-bar">
                    <button type="button" class="button button-secondary leioc-invoice-builder-nxt">Next</button>
                </div>

                <div class="leioc-tab-content">
                    <div class="tab-pane active">
                        <?php $invoiceTable->show_table() ; ?>
                    </div>

                    <div class="tab-pane">
                        <div class="leioc-invoice-mail-merge">
                            <form method="post" id="leioc_invoice_email_merge" name="leioc_invoice_email_merge" data-url="<?php echo admin_url('admin-ajax.php') ?>" action="#">
                                <div class="button-bar">
                                    <input type="hidden" id="entries-list" name="entries-list">
                                    <input type="hidden" name="action" value="leioc_invoices_mail_merge">
                                    <?php wp_nonce_field( 'leioc-invoice-entries-wp-nonce', 'nonce' ); ?>
                                    <input type="submit" id="mail-merge" class="button button-secondary" value="Mail Merge Preview" aria-label="mail merge">
                                    <button type="button" id="leioc-mail-merge-prev" class="button button-secondary" value="-1" aria-label="previous mail merge preview"><<</button>
                                    <button type="button" id="leioc-mail-merge-nxt" class="button button-secondary" value="1" aria-label="next mail merge next">>></button>
                                    <input type="submit" id="leioc-mail-merge-send" class="button button-primary" value="Merge & Send Email" aria-label="mail merge and send email">
                                    <div class="leioc-group-by-btn">
                                        <input type="radio" id="email-group" checked name="group-by" value="email" aria-label="select email group">
                                        <label for="email-grouo">Group by email address</label>
                                        <input type="radio" id="person-group" name="group-by" value="person" aria-label="group by person">
                                        <label for="person-grouo">Group by person</label>
                                    </div>
                                </div>
                                <div class="leioc-msg">
                                    <span class="field-msg js-database-submission">Accessing database, please wait&hellip;</span>
                                    <span class="field-msg error js-database-error">There was a problem connecting with the database, please try again!</span>
                                </div>
                            </form>

                            <hr>
                            <div class="leioc-invoice-num-bar">
                                <div class="leioc-invoice-count">Total number of invoices: <span>0</span></div>
                                <div class="leioc-invoice-num">Invoice number: <span>0</span></div>
                            </div>
                            <div class="leioc-invoices-sent-bar">
                                <div class="leioc-invoices-sent">Number of emails sent: <span></span></div>
                                <div class="leioc-invoices-not-sent">Emails not sent to: <span></span></div>
                            </div>
                            <div class="mail-merge-display">
                                <div class="leioc-merge-preview" style="display: block; font-weight:bold;">No invoices selected.</div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

            <div class="leioc-modal-footer">
                <div>
                    <button type="button" class="button button-secondary leioc-invoice-builder-nxt">Next</button>
                </div>
            </div>

        </div>
    </div>

</div>