<?php if( isset($disabled) ):?>
    <p class="leioc-important">Sorry, all available start slots have been taken!</p>
<?php endif; ?>

<div class="leioc-modal-warpper">
    <section>
        <div class="leioc-contact-details">
            <div class="leioc-form-row">
                <div class="leioc-form-group">
                    <label for="leioc-contact-email" class="required">Email address</label>
                    <div>
                        <input type="email" id="leioc-contact-email" placeholder="name@example.com" name="email" pattern="[a-zA-Z0-9.!#$%&amp;’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+" aria-label="email" <?php echo isset($disabled) ? 'disabled': ''; ?> aria-describedby="emailHelpBlock" required>
                        <div id="emailHelpBlock" class="leioc-form-text">A valid email address is required to enter this event.</div>
                        <span class="field-msg error" data-error="invalidEmail">The email address is not valid</span>
                    </div>
                </div>
                <?php if( $use_phone != 0 ): ?>
                    <div class="leioc-form-group">
                        <label for="leioc-contact-phone" class="required">Phone</label>
                        <div>
                            <input type="tel" id="leioc-contact-phone" placeholder="e.g. 0123456789" name="phone" pattern="^[0-9]*$" aria-label="phone"<?php echo isset($disabled) ? 'disabled': ''; ?> aria-describedby="phoneHelpBlock" required>
                            <div id="phoneHelpBlock" class="leioc-form-text">
                                <?php echo isset($phone_note) ? $phone_note : 'Please enter a mobile phone number if possible.'; ?>
                            </div>
                            <span class="field-msg error" data-error="invalidEmail">The phone number is not valid</span>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section>
        <div class="leioc-contact-comp">
            <div class="leioc-form-row">
                <div class="leioc-form-group">
                    <label for="leioc-contact-name" class="required">Name</label>
                    <div>
                        <input type="text" id="leioc-contact-name" placeholder="Name" name="name" aria-label="name" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
                        <span class="field-msg error" data-error="invalidName">Your Name is Required</span>
                    </div>
                </div>
                <div class="leioc-form-group">
                    <label for="leioc-contact-age" class="required">Age Class</label>
                    <div>
                        <select id="leioc-contact-age" name="age" aria-label="age" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
                            <?php echo $ageClass; ?>
                        </select>
                        <span class="field-msg error" data-error="invalidAge">Please select an Age Class</span>
                    </div>
                </div>
            </div>
            <div class="leioc-form-row">
                <div class="leioc-form-group">
                    <label for="leioc-contact-bof" class="required">BOF Number</label>
                    <div>
                        <input type="text" id="leioc-contact-bof" name="bof" pattern="(^[0-9]*$|IND)" aria-label="bof" <?php echo isset($disabled) ? 'disabled': ''; ?> aria-describedby="bofHelpBlock" required>
                        <div id="bofHelpBlock" class="leioc-form-text">Enter IND, if you do not have a BOF number.</div>
                        <span class="field-msg error" data-error="invalidBof">A BOF number is required</span>
                    </div>
                </div>
                <div class="leioc-form-group">
                    <label for="leioc-contact-club" class="required">Club</label>
                    <div>
                        <input type="text" id="leioc-contact-club" name="club" aria-label="club" <?php echo isset($disabled) ? 'disabled': ''; ?> aria-describedby="clubHelpBlock" required>
                        <div id="clubHelpBlock" class="leioc-form-text">Enter IND, if you do not have a club.</div>
                        <span class="field-msg error" data-error="invalidBof">A club is required</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="leioc-contact-course">
            <div class="leioc-form-row">
                <div class="leioc-form-group">
                    <label for="leioc-contact-si" class="required">Si Dibber Number</label>
                    <div>
                        <input type="text" id="leioc-contact-si" name="si" pattern="(^[0-9]*$|HIRE)" aria-label="si" <?php echo isset($disabled) ? 'disabled': ''; ?> aria-describedby="siHelpBlock" required>
                        <div id="siHelpBlock" class="leioc-form-text">Enter HIRE, if you wish to hire a dibber.</div>
                        <span class="field-msg error" data-error="invalidSi">A Si Dibber number is required</span>
                    </div>
                </div>
                <div class="leioc-form-group">
                    <label for="leioc-contact-course" class="required">Course</label>
                    <div>
                        <select id="leioc-contact-course" name="course" aria-label="course" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
                            <?php echo isset($course) ? $course : ''; ?>
                        </select>
                        <span class="field-msg error" data-error="invalidCourse">Please select a course</span>
                    </div>
                </div>
                <div class="leioc-form-group <?php echo isset($show) ?  ($show == true ? '' : 'leioc-hidden'):''; ?>">
                    <label for="leioc-contact-start" class="required">Start Time</label>
                    <div>
                        <?php if( isset($admin) ): ?>
                            <input type="text" id="leioc-contact-start" name="start_time" aria-label="start time">
                        <?php else: ?>
                            <select class="leioc-form-start" id="leioc-contact-start" name="start_time" aria-label="start time" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
                                <?php echo isset($starts) ? $starts : ''; ?>
                            </select>
                        <?php endif; ?>
                        <span class="field-msg error" data-error="invalidStart">Please select a Start Time</span>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php if( isset($fees) ): ?>
        <?php if( !empty($fees['fee']) || !empty($fees['si'])): ?>
        <section>
            <div class="leioc-event-fee">
                <div class="leioc-form-row">
                    <?php if( !empty($fees['fee']) ): ?>
                    <div class="leioc-form-group">
                        <label for="leioc-event-fee" class="required">Fee</label>
                            <div>
                                <select id="leioc-event-fee" name="fee" aria-label="fee" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
                                    <?php echo $fees['fee']; ?>
                                </select>
                                <span class="field-msg error" data-error="invalidFee">Please select an fee category</span>
                            </div>
                    </div>
                    <?php endif; ?>
                    <?php if( !empty($fees['si']) ): ?>
                    <div class="leioc-form-group">
                        <label for="leioc-si-hire" class="required">Si Hire Fee</label>
                            <div>
                                <select id="leioc-si-hire" name="si_hire" aria-label="Si hire fee" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
                                    <?php echo $fees['si']; ?>
                                </select>
                                <span class="field-msg error" data-error="invalidFee">Please select an Si Hire charge</span>
                            </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>
        <?php endif; ?>
    <?php endif; ?>
    <?php if( isset($modal ) ): ?>
        <?php require($this->plugin_path.'templates/terms-checkbox.php'); ?>
    <?php endif; ?>
</div>
<?php if( isset($admin) ): ?>
    <div class="leioc-form-group">
        <label>Send email on update</label>
        <div class="leioc-ui-toggle not-div">
            <input type="checkbox" id="admin-email-send" name="admin-email-send" value="1">
            <label for="admin-email-send"><div class="not-div"></div></label>
        </div>
    </div>
<?php endif; ?>
<?php if( ! isset($modal ) ): ?>
    <div class="leioc-form-terms">
        <?php if( ! isset($admin ) ): ?>
            <?php require($this->plugin_path.'templates/terms-checkbox.php'); ?>
        <?php else: //Adds hidden terms to admin page to admin page?> 
            <input type="hidden" id="leioc-terms-conditions" name="terms_checked" aria-label="Accept terms and conditions" <?php echo isset($disabled) ? 'disabled': ''; ?> required>
        <?php endif; ?>
        <div class="leioc-btn-group">
            <div class="leioc-submit"></div><button type="submit" id="leioc-submit" class="button-primary leioc-btn success" <?php echo isset($disabled) ? 'disabled': ''; ?>
        >Submit</button>
        <?php if( isset($admin) ): ?>
            <button type="button" class="button button-secondary clear-form">Reset Form</button>
        <?php endif; ?>
        <span class="field-msg js-form-submission">Submission in process, please wait&hellip;</span>
        <span class="field-msg success js-form-success">Entry successfully submitted, thank you!</span>
        <span class="field-msg error js-form-error">There was a problem with the Entry Form, please try again!</span></div>
    </div>
<?php endif; ?>
<div class="leioc-modal-hidden-fields">
    <input type="hidden" name="id">
    <input type="hidden" name="event_id" value="<?php echo $eventID; ?>">
    <input type="hidden" name="action" value="leioc_entry_form_submit">
    <input type="hidden" name="nonce" value="<?php echo wp_create_nonce("leioc-entry-form-nonce") ?>">
</div>
