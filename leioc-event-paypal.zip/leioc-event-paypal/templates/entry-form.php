<div class="leioc-title-bar">
    <h3><?php echo $title; ?></h3>
    <div><?php echo $date; ?></div>
</div>
<div><?php echo isset($closed) ? '<p class="leioc-important">' . $closed . '</p>' : ''?></div>
<?php if( !empty($info) ):?>
    <div class="leioc-about-event">
        <div class="leioc-form-row"><p><?php echo $info; ?></p></div>
    </div>
<?php endif; ?>
<div class="<?php echo isset($closed) ? 'leioc-hidden' : ''?>">
    <?php isset($closed) ? '' : require($this->plugin_path.'templates/form.php'); ?>
</div>
