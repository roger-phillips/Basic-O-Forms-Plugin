<?php
 /**
  *
  *@package leioc-event-paypal
  *
  *
  *Plugin Name: Basic Orienteering Entry Form 
  *Description: This plugin adds a basic orienteering events entry system.
  *Version: 0.0.4
  *Author: Roger Phillips
  *License: GPLv2 or later
  *Text Domain: leioc-event-paypal
  *
*/

/* 
Copyright (C) 2021  Roger Phillips

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

// Exit if accessed directly.
defined( 'ABSPATH' ) || exit;

//Require once the Composer Autoload
if ( file_exists( dirname( __FILE__ ) . '/vendor/autoload.php') ) {
    require_once dirname( __FILE__ ) . '/vendor/autoload.php' ;
}

// WP_List_Table is not loaded automatically so we need to load it in our application
if( ! class_exists( 'WP_List_Table' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

/** 
 * The code that runs during plugin activation
*/
function activate_leioc_events_paypal_plugin(){
    LEIOCPaypal\Base\Activate::activate();
}
register_activation_hook( __FILE__ , 'activate_leioc_events_paypal_plugin' );

/** 
 * The code that runs during plugin deactivation
*/
function deactivate_leioc_events_paypal_plugin(){
    LEIOCPaypal\Base\Deactivate::deactivate();
}
register_deactivation_hook( __FILE__ , 'deactivate_leioc_events_paypal_plugin' );

/** 
 * The code register database tables
*/
function register_leioc_paypal_database_tables(){
    LEIOCPaypal\Base\dbTableController::register();
}
register_activation_hook( __FILE__, 'register_leioc_paypal_database_tables' );


if ( class_exists( 'LEIOCPaypal\\Init') ){
    LEIOCPaypal\Init::register_services();
}